// TestCxStaticDlg.h : header file
//

#if !defined(AFX_TESTCXSTATICDLG_H__53964EB8_7397_4E7E_804D_38B03D1920BD__INCLUDED_)
#define AFX_TESTCXSTATICDLG_H__53964EB8_7397_4E7E_804D_38B03D1920BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "cxstatic/cxstatic.h"
#include "afxwin.h"



/////////////////////////////////////////////////////////////////////////////
// CTestCxStaticDlg dialog

class CTestCxStaticDlg : public CDialog
{
// Construction
public:
	CTestCxStaticDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestCxStaticDlg)
	enum { IDD = IDD_TESTCXSTATIC_DIALOG };
	
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestCxStaticDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON		m_hIcon;
	CxStatic	m_staFont3D;
	CxStatic	m_staTransparent;
	CxStatic	m_staBitmap;
	CxStatic	m_staText;
	CEdit		m_edbText;
	CComboBox	m_cboGradient;
	CxStatic	m_staGradient;
	CStatic		m_staDef;
	CxStatic	m_staResizeMe;
	CxStatic	m_staDragNDrop;


	void OnOK();
	void OnCancel();

	// Generated message map functions
	//{{AFX_MSG(CTestCxStaticDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeGradientCombo();
	afx_msg void OnChangeEditText();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTCXSTATICDLG_H__53964EB8_7397_4E7E_804D_38B03D1920BD__INCLUDED_)
