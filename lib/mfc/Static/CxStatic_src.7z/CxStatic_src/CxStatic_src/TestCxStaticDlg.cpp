// TestCxStaticDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestCxStatic.h"
#include "TestCxStaticDlg.h"
#include "RgbColor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestCxStaticDlg dialog

CTestCxStaticDlg::CTestCxStaticDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestCxStaticDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestCxStaticDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestCxStaticDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestCxStaticDlg)
	DDX_Control(pDX, IDC_STAFONT3D, m_staFont3D);
	DDX_Control(pDX, IDC_STA_TRANSPARENT, m_staTransparent);
	DDX_Control(pDX, IDC_STA_BITMAP, m_staBitmap);
	DDX_Control(pDX, IDC_TEXT, m_staText);
	DDX_Control(pDX, IDC_EDIT1, m_edbText);
	DDX_Control(pDX, IDC_COMBO1, m_cboGradient);
	DDX_Control(pDX, IDC_GRADIENT, m_staGradient);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_DEF_STATIC, m_staDef);
	DDX_Control(pDX, IDC_RESIZEME, m_staResizeMe);
	DDX_Control(pDX, IDC_DRAGNDROP, m_staDragNDrop);
}

BEGIN_MESSAGE_MAP(CTestCxStaticDlg, CDialog)
	//{{AFX_MSG_MAP(CTestCxStaticDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeGradientCombo)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEditText)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestCxStaticDlg message handlers

BOOL CTestCxStaticDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	

	m_cboGradient.AddString("Horizontal Gradient");
	m_cboGradient.AddString("Vertical Gradient");	
	m_cboGradient.SetCurSel(0);

	m_staGradient.SetTextColor( WHITE );
	m_staGradient.SetFont("Arial", 20, FW_BOLD);
	m_staGradient.Format("Gradient");
	m_staGradient.SetBkColor( RGB(255,240,150), RGB(124,0,0), CxStatic::HGradient );

	
	m_staText.SetFont("Arial", 16, FW_NORMAL);
	m_staText.SetWindowText("a\r\nb");
	
	m_staBitmap.SetBitmap(IDB_BITMAP2, CxStatic::OriginalSize);
	m_staBitmap.SetTextColor( RGB(165,47,0) );
	m_staBitmap.SetFont("Arial", 16, FW_BOLD);
	

	
	m_staTransparent.SetTransparent(TRUE);
	m_staTransparent.SetTextColor( RGB(165,47,0) );
	m_staTransparent.SetFont("Arial", 16, FW_BOLD);

	m_staFont3D.SetFont("Arial", 16, FW_NORMAL);
	m_staFont3D.SetFont3D(TRUE, CxStatic::Raised);
	

	//One standard method to change font - Works with default CStatic
	static const HFONT fArial16 = CreateFont(16,	//height
		0, // width
		0, // escapement
		0, // orientation
		FW_NORMAL, // font width
		0, // italic
		0, // underline
		0, 0, 0, 0, 0, 0,"Arial");
	m_staDef.SendMessage(WM_SETFONT,(WPARAM)fArial16, TRUE);

	// Show resizing at run-time
	m_staResizeMe.SetBkColor( WHITE );
	m_staResizeMe.SetTextColor ( RGB(200,60,12) );
	m_staResizeMe.SetMoveable();
	m_staResizeMe.SetFont("Arial", 18, FW_BOLD);

	// Show Drag & Drop Support (only for bmp by now)
	m_staDragNDrop.SetBkColor( RGB(255,255,255));
	m_staDragNDrop.SetTextColor( RGB(60,200, 12) );
	m_staDragNDrop.SetFont("Arial", 18, FW_BOLD);
	m_staDragNDrop.SetWindowText( _T("Drag a bmp file on me") );

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}



void CTestCxStaticDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestCxStaticDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



void CTestCxStaticDlg::OnSelchangeGradientCombo() 
{
	if (m_cboGradient.GetCurSel() == 0)
		m_staGradient.SetBkColor( RGB(255,240,150), RGB(124,0,0), CxStatic::HGradient );
	else
		m_staGradient.SetBkColor( RGB(255,240,150), RGB(124,0,0), CxStatic::VGradient );
	
}

void CTestCxStaticDlg::OnChangeEditText() 
{

	CString csTmp;
	m_edbText.GetWindowText(csTmp);
	m_staText.SetWindowText(csTmp);
	m_staBitmap.SetWindowText(csTmp);
	m_staTransparent.SetWindowText(csTmp);
	m_staDef.SetWindowText(csTmp);
}

void CTestCxStaticDlg::OnOK()
{

}

void CTestCxStaticDlg::OnCancel()
{
	CDialog::OnCancel();
}