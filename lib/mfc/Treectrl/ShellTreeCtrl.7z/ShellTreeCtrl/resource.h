//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DEMOTYPE                    129
#define IDR_HOURGLASS                   130
#define IDR_TESTMENU                    130
#define ID_TEST_SETITEMASROOT           32771
#define ID_TEST_SETITEMASROOTWITHFILES  32772
#define ID_TEST_ADDITEMTOROOT           32773
#define ID_TEST_ADDITEMTOROOTWITHFILES  32774
#define ID_TESTITEM1                    32775
#define ID_TESTITEM2                    32776
#define ID_SHELLMENU                    32777
#define ID_TESTITEM3                    32778
#define ID_TESTITEM4                    32779
#define ID_TEST_REFRESHITEM             32781
#define ID_TEST_TEXTCALLBACK            32782
#define ID_TEST_IMAGECALLBACK           32783
#define ID_TEST_CHILDRENCALLBACK        32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
