// CDirTreeDlgDlg.h : Header-Datei
//

#if !defined(AFX_CDIRTREEDLGDLG_H__DFD30AD4_B521_11D2_9560_204C4F4F5020__INCLUDED_)
#define AFX_CDIRTREEDLGDLG_H__DFD30AD4_B521_11D2_9560_204C4F4F5020__INCLUDED_

#include "DirTreeCtrl.h"	// Hinzugef�gt von ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CCDirTreeDlgDlg Dialogfeld

class CCDirTreeDlgDlg : public CDialog
{
// Konstruktion
public:
	CCDirTreeDlgDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CCDirTreeDlgDlg)
	enum { IDD = IDD_CDIRTREEDLG_DIALOG };
	CString	m_strSelection;
	CString	m_strPathName;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CCDirTreeDlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	CDirTreeCtrl m_DirTree;
	HICON m_hIcon;

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CCDirTreeDlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelect();
	afx_msg void OnSelchangedDirtree(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnSelok();
	afx_msg void OnFilenames();
	afx_msg void OnFolders();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // !defined(AFX_CDIRTREEDLGDLG_H__DFD30AD4_B521_11D2_9560_204C4F4F5020__INCLUDED_)
