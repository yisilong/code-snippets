// TransListBoxSample6Dlg.h : header file
//

#if !defined(AFX_TRANSLISTBOXSAMPLE6DLG_H__E4872A7B_C428_4160_B5FB_3BBC4D22BF15__INCLUDED_)
#define AFX_TRANSLISTBOXSAMPLE6DLG_H__E4872A7B_C428_4160_B5FB_3BBC4D22BF15__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "TransparentListBox.h"

/////////////////////////////////////////////////////////////////////////////
// CTransListBoxSample6Dlg dialog

class CTransListBoxSample6Dlg : public CDialog
{
// Construction
public:
	CTransListBoxSample6Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTransListBoxSample6Dlg)
	enum { IDD = IDD_TRANSLISTBOXSAMPLE6_DIALOG };
	CTransparentListBox	m_TransListBox;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransListBoxSample6Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTransListBoxSample6Dlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSLISTBOXSAMPLE6DLG_H__E4872A7B_C428_4160_B5FB_3BBC4D22BF15__INCLUDED_)
