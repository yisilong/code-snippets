// CatListBoxDemo.cpp : Defines the class behaviors for the application.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CatListBoxDemo.h"
#include "CatListBoxDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Message mapping.
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CCatListBoxDemoApp, CWinApp)
   //{{AFX_MSG_MAP(CCatListBoxDemoApp)
   // NOTE - the ClassWizard will add and remove mapping macros here.
   //    DO NOT EDIT what you see in these blocks of generated code!
   //}}AFX_MSG
   ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// The application instance.
/////////////////////////////////////////////////////////////////////////////

CCatListBoxDemoApp theApp;


/////////////////////////////////////////////////////////////////////////////
// Constructor.
/////////////////////////////////////////////////////////////////////////////

CCatListBoxDemoApp::CCatListBoxDemoApp()
{
}


/////////////////////////////////////////////////////////////////////////////
// CCatListBoxDemoApp initialization
/////////////////////////////////////////////////////////////////////////////

// Start of the application.
BOOL CCatListBoxDemoApp::InitInstance()
{
   AfxEnableControlContainer();
#ifdef _AFXDLL
   Enable3dControls();        // Call this when using MFC in a shared DLL
#else
   Enable3dControlsStatic();  // Call this when linking to MFC statically
#endif

   // Display dialog.
   CCatListBoxDemoDlg   dlgDemo;
   m_pMainWnd = &dlgDemo;
   dlgDemo.DoModal();
   return FALSE;
}
