// CatListBoxDemoDlg.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CatListBoxDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCatListBoxDemoDlg::CCatListBoxDemoDlg( CWnd* pParent /*=NULL*/ )
   : CDialog( CCatListBoxDemoDlg::IDD, pParent )
{
   //{{AFX_DATA_INIT(CCatListBoxDemoDlg)
   //}}AFX_DATA_INIT
}


//////////////////////////////////////////////////////////////////////
// Dialog mapping.
//////////////////////////////////////////////////////////////////////

void CCatListBoxDemoDlg::DoDataExchange( CDataExchange* pDX )
{
   CDialog::DoDataExchange( pDX );
   //{{AFX_DATA_MAP(CCatListBoxDemoDlg)
   DDX_Control(pDX, IDC_LST_DEMO, m_lstDemo);
   //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCatListBoxDemoDlg, CDialog)
   //{{AFX_MSG_MAP(CCatListBoxDemoDlg)
   ON_BN_CLICKED(IDC_CHK_SHOW_CHECKS, OnChkShowChecks)
   ON_BN_CLICKED(IDC_CMD_DELETE, OnCmdDelete)
   ON_BN_CLICKED(IDC_CMD_INSERT, OnCmdInsert)
   ON_BN_CLICKED(IDC_CMD_OPEN_CLOSE_ALL, OnCmdOpenCloseAll)
   ON_BN_CLICKED(IDC_CMD_TOGGLE_CHECKS, OnCmdToggleChecks)
   ON_LBN_SELCHANGE(IDC_LST_DEMO, OnSelchangeLstDemo)
   //}}AFX_MSG_MAP
END_MESSAGE_MAP()


//////////////////////////////////////////////////////////////////////
// Initialization functions.
//////////////////////////////////////////////////////////////////////

// Initializes dialog's controls.
BOOL CCatListBoxDemoDlg::OnInitDialog()
{
   int      iItemIndex;
   HRESULT  hr;

   // Must call base class's OnInitDialog() function first to enable DoDataExchange variables.
   CDialog::OnInitDialog();

   ///////////////////////////////////////////////////////////////
   // Add items to category listbox...

   // You can add a category first and then add items to it.
   hr = m_lstDemo.AddCategory( _T("Category 1") );
   m_lstDemo.AddCategoryItem( _T("Category 1"), _T("Item 1") );
   m_lstDemo.AddCategoryItem( _T("Category 1"), _T("Item 2") );
   m_lstDemo.AddCategoryItem( _T("Category 1"), _T("Item 3") );

   // You don't have to create a category first.
   // Calling AddCategoryItem() will create the category for you if it doesn't exist.
   m_lstDemo.AddCategoryItem( _T("Category 2"), _T("Item 1") );
   m_lstDemo.AddCategoryItem( _T("Category 2"), _T("Item 2") );
   m_lstDemo.AddCategoryItem( _T("Category 2"), _T("Item 3") );

   // Note that this control allows duplicate item names under the same category.
   m_lstDemo.AddCategoryItem( _T("Category 2"), _T("Item 2") );

   // Also note that category names must be unique. The following function will fail.
   hr = m_lstDemo.AddCategory( _T("Category 2") );    // hr = E_INVALIDARG.

   // You can add a checkbox to an item by setting its state as follows.
   // State 0: Shows an unchecked checkbox.
   // State 1: Shows a checked checkbox.
   // State 2: Does not show a checkbox. (This is the default.)
   // Note that you must call ShowCategoryItemStates( true ) to view the checkboxes.
   m_lstDemo.AddCategoryItem( _T("Category 3"), _T("Item 1"), 0 );   // Unchecked.
   m_lstDemo.AddCategoryItem( _T("Category 3"), _T("Item 2"), 1 );   // Checked.
   m_lstDemo.AddCategoryItem( _T("Category 3"), _T("Item 3"), 2 );   // No checkbox.
   m_lstDemo.AddCategoryItem( _T("Category 3"), _T("Item 4") );      // No checkbox.

   // You can add DWORD data to items as follows.
   iItemIndex = m_lstDemo.AddCategoryItem( _T("Category 4"), _T("Item 1") );
   hr = m_lstDemo.SetCategoryItemData( _T("Category 4"), iItemIndex, 123 );
   iItemIndex = m_lstDemo.AddCategoryItem( _T("Category 4"), _T("Item 2") );
   hr = m_lstDemo.SetCategoryItemData( _T("Category 4"), iItemIndex, 456 );
   iItemIndex = m_lstDemo.AddCategoryItem( _T("Category 4"), _T("Item 3") );
   hr = m_lstDemo.SetCategoryItemData( _T("Category 4"), iItemIndex, 789 );

   // The category listbox can sort its categories/items if LBS_SORT is set.
   // The sort is NOT case sensitive.
   m_lstDemo.AddCategoryItem( _T("Category 5"), _T("Item 3") );
   m_lstDemo.AddCategoryItem( _T("Category 5"), _T("Item 2") );
   m_lstDemo.AddCategoryItem( _T("Category 5"), _T("item 3") );
   m_lstDemo.AddCategoryItem( _T("Category 5"), _T("Item 1") );


   // Highlight first item in list.
   m_lstDemo.SetCurSel( 0 );
   OnSelchangeLstDemo();

   return TRUE;
}


//////////////////////////////////////////////////////////////////////
// Message/event handlers.
//////////////////////////////////////////////////////////////////////

// Inserts a new category/item into the category listbox.
void CCatListBoxDemoDlg::OnCmdInsert()
{
   CWnd*    pWnd;
   CString  sBuf;
   CString  sCategory;
   CString  sItem;
   DWORD    dwValue;
   int      iItemIndex;

   // Get category string.
   if (pWnd = GetDlgItem( IDC_TXT_ADD_CATEGORY ))
      pWnd->GetWindowText( sCategory );
   if (sCategory.IsEmpty()) {
      AfxMessageBox( _T("Category field cannot be empty!"), MB_OK | MB_ICONEXCLAMATION, NULL );
      return;
   }

   // Get item string.
   if (pWnd = GetDlgItem( IDC_TXT_ADD_ITEM ))
      pWnd->GetWindowText( sItem );
   if (sItem.IsEmpty()) {
      AfxMessageBox( _T("Item field cannot be empty!"), MB_OK | MB_ICONEXCLAMATION, NULL );
      return;
   }

   // Get DWORD value.
   if (pWnd = GetDlgItem( IDC_TXT_ADD_DWORD ))
      pWnd->GetWindowText( sBuf );
   dwValue = (DWORD)_ttoi( (LPCTSTR)sBuf );

   // Add above info to category listbox.
   // If the category does not exist, then the category is created and the item is put under it.
   // If the category does exist, then the item is inserted under the existing category.
   iItemIndex = m_lstDemo.AddCategoryItem( (LPCTSTR)sCategory, (LPCTSTR)sItem );
   m_lstDemo.SetCategoryItemData( (LPCTSTR)sCategory, iItemIndex, dwValue );

   // Highlight the new item.
   m_lstDemo.SetCurSel( (LPCTSTR)sCategory, iItemIndex );
   OnSelchangeLstDemo();
}

// Show info on the currently selected item in the category listbox.
void CCatListBoxDemoDlg::OnSelchangeLstDemo()
{
   CWnd*    pWnd;
   CString  sBuf;
   CString  sCategory;
   CString  sItem;
   int      iListIndex;    // Listbox control's index.
   int      iItemIndex;    // Index of item in category's list.
   DWORD    dwValue = 0;

   // Get indexes.
   iListIndex = m_lstDemo.GetCurSel();
   iItemIndex = m_lstDemo.GetCategoryItemIndex( iListIndex );

   // Get selected item's info.
   if (LB_ERR != iListIndex) {
      // Get category name.
      sCategory = m_lstDemo.GetCategoryName( iListIndex );

      // Get item's string and DWORD.
      // Don't fetch if a category was selected. Categories do not store DWORDs.
      if (!m_lstDemo.IsCategory( iListIndex )) {
         sItem   = m_lstDemo.GetCategoryItemName( (LPCTSTR)sCategory, iItemIndex );
         dwValue = m_lstDemo.GetCategoryItemData( (LPCTSTR)sCategory, iItemIndex );
      }
   }

   // Output selected info.
   if (pWnd = GetDlgItem( IDC_TXT_SEL_CATEGORY ))
      pWnd->SetWindowText( (LPCTSTR)sCategory );
   if (pWnd = GetDlgItem( IDC_TXT_SEL_ITEM ))
      pWnd->SetWindowText( (LPCTSTR)sItem );
   if (pWnd = GetDlgItem( IDC_TXT_SEL_DWORD )) {
      sBuf.Format( _T("%d"), dwValue );
      pWnd->SetWindowText( (LPCTSTR)sBuf );
   }
}

// Deletes the selected category/item in the category listbox.
void CCatListBoxDemoDlg::OnCmdDelete()
{
   int      iListIndex = m_lstDemo.GetCurSel();

   // If a category was selected, then that category and all of its items will be deleted.
   // If only an item was selected, then just that item will be deleted.
   m_lstDemo.Delete( iListIndex );

   // Highlight next item in listbox.
   if (LB_ERR == m_lstDemo.SetCurSel( iListIndex ))
      m_lstDemo.SetCurSel( iListIndex - 1 );
   OnSelchangeLstDemo();
}

// Hides/shows all checkboxes in category listbox.
void CCatListBoxDemoDlg::OnChkShowChecks()
{
   CButton*    pButton;
   bool        bShow = true;

   if (pButton = (CButton*)GetDlgItem( IDC_CHK_SHOW_CHECKS ))
      bShow = pButton->GetCheck() ? true : false;
   m_lstDemo.ShowCategoryItemStates( bShow );
}

// Opens/closes all categories in category listbox.
void CCatListBoxDemoDlg::OnCmdOpenCloseAll()
{
   LPCTSTR     pCategory;
   int         iCatIndex;
   static bool bOpen;

   // Open/close all categories.
   for (iCatIndex = 0; iCatIndex < m_lstDemo.GetCategoryCount(); iCatIndex++) {
      pCategory = m_lstDemo.GetCategoryName( iCatIndex, false );
      m_lstDemo.SetCategoryState( pCategory, bOpen );
   }
   bOpen = !bOpen;      // Toggles it to be opened or closed next time button is clicked.

   // Highlight first item in listbox.
   m_lstDemo.SetCurSel( 0 );
   OnSelchangeLstDemo();
}

// Toggles all checkbox states for all items in category listbox.
// Toggles from state: 0 (unchecked) -> 1 (checked) -> 2 (no checkbox) -> 0 ->...
void CCatListBoxDemoDlg::OnCmdToggleChecks()
{
   LPCTSTR  pCategory;
   int      iState;
   int      iCatIndex;
   int      iItemIndex;

   for (iCatIndex = 0; iCatIndex < m_lstDemo.GetCategoryCount(); iCatIndex++) {
      pCategory = m_lstDemo.GetCategoryName( iCatIndex, false );
      for (iItemIndex = 0; iItemIndex < m_lstDemo.GetCategoryItemCount( pCategory ); iItemIndex++) {
         iState = m_lstDemo.GetCategoryItemState( pCategory, iItemIndex );
         m_lstDemo.SetCategoryItemState( pCategory, iItemIndex, (iState + 1) % 3 );
      }
   }
}
