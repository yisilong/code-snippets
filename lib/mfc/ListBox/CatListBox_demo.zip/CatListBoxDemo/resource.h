//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CatListBoxDemo.rc
//
#define IDD_CATLISTBOXDEMO_DIALOG       102
#define IDD_DLG_DEMO                    102
#define IDR_MAINFRAME                   128
#define IDC_LST_DEMO                    1000
#define IDC_CMD_OPEN_CLOSE_ALL          1001
#define IDC_CMD_TOGGLE_CHECKS           1002
#define IDC_FRA_INSERT_TEST             1003
#define IDC_LBL_ADD_CATEGORY            1004
#define IDC_TXT_ADD_CATEGORY            1005
#define IDC_LBL_ADD_ITEM                1006
#define IDC_TXT_ADD_ITEM                1007
#define IDC_CMD_INSERT                  1008
#define IDC_CMD_DELETE                  1009
#define IDC_LBL_ADD_DWORD               1010
#define IDC_TXT_ADD_DWORD               1011
#define IDC_CHK_SHOW_CHECKS             1012
#define IDC_FRA_SELECT_TEST             1013
#define IDC_LBL_SEL_CATEGORY            1014
#define IDC_TXT_SEL_CATEGORY            1015
#define IDC_LBL_SEL_ITEM                1016
#define IDC_TXT_SEL_ITEM                1017
#define IDC_LBL_SEL_DWORD               1018
#define IDC_TXT_SEL_DWORD               1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
