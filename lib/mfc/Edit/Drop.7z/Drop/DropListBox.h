#include "OleDropTargetEx.h"

#if !defined(AFX_DROPLISTBOX_H__9841B963_A828_11D5_A514_F83E4916FF18__INCLUDED_)
#define AFX_DROPLISTBOX_H__9841B963_A828_11D5_A514_F83E4916FF18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DropListBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDropListBox window
//��ʾ�ɽ����϶����б��ؼ�

class CDropListBox : public CListBox
{
// Construction
public:
	CDropListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDropListBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual BOOL Register();
	virtual ~CDropListBox();

	// Generated message map functions
protected:
	COleDropTargetEx m_dropEx;
//����OnDropEx��Ϣ�Ǳ���ģ�����OnDrop�������ᱻִ��
//��ȻҲ������OnDropEx�����д�������
	virtual BOOL OnDrop(WPARAM pDropInfoClass, LPARAM lParm);
	virtual DROPEFFECT OnDropEx(WPARAM pDropInfoClass, LPARAM lParm);
	virtual DROPEFFECT OnDragOver(WPARAM pDropInfoClass,LPARAM lParm);

	//{{AFX_MSG(CDropListBox)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DROPLISTBOX_H__9841B963_A828_11D5_A514_F83E4916FF18__INCLUDED_)
