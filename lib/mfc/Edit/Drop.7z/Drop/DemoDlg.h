// DemoDlg.h : header file
//
#include "DropEdit.h"
#include "DropButton.h"
#include "DropListBox.h"

#if !defined(AFX_DEMODLG_H__)
#define AFX_DEMODLG_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDropExDemoDlg dialog

class CDropExDemoDlg : public CDialog
{
// Construction
public:
	CDropExDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDropExDemoDlg)
	enum { IDD = IDD_DROPEXDEMO_DIALOG };
	CDropListBox	m_DropListBox;
	CDropButton	m_DropButton;
	CDropEdit	m_dropEdit;
	CDropEdit	m_dropEdit2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDropExDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDropExDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMODLG_H__)
