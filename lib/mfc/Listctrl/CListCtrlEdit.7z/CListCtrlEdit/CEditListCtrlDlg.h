// CEditListCtrlDlg.h : header file
//

#if !defined(AFX_CEDITLISTCTRLDLG_H__A5E573D8_FA1F_4CC6_B5E9_F8DCCBBC6721__INCLUDED_)
#define AFX_CEDITLISTCTRLDLG_H__A5E573D8_FA1F_4CC6_B5E9_F8DCCBBC6721__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ListCtrlDateEdit.h"
#include "ListCtrlEdit.h"
#include "ListCtrlComboBox.H"
#include "ListCtrlMaskEdit.H"
#include "ListCtrlCurrencyEdit.H"
/////////////////////////////////////////////////////////////////////////////
// CCEditListCtrlDlg dialog

class CCEditListCtrlDlg : public CDialog
{
// Construction
public:
	CCEditListCtrlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCEditListCtrlDlg)
	enum { IDD = IDD_CEDITLISTCTRL_DIALOG };
//	CEditListCtrl	m_list;
	CListCtrl	m_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCEditListCtrlDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
    CListCtrlCurrencyEdit m_ListCurrencyEdit;
    CListCtrlMaskEdit m_ListMaskEdit;
    CListCtrlDateEdit m_ListDateEdit;
    CListCtrlEdit m_ListEdit;
    CListCtrlComboBox m_ListComboBox;
	// Generated message map functions
	//{{AFX_MSG(CCEditListCtrlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnClickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CEDITLISTCTRLDLG_H__A5E573D8_FA1F_4CC6_B5E9_F8DCCBBC6721__INCLUDED_)
