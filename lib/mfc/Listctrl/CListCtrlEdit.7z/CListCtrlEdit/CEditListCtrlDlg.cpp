// CEditListCtrlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CEditListCtrl.h"
#include "CEditListCtrlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCEditListCtrlDlg dialog

CCEditListCtrlDlg::CCEditListCtrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCEditListCtrlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCEditListCtrlDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCEditListCtrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCEditListCtrlDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCEditListCtrlDlg, CDialog)
	//{{AFX_MSG_MAP(CCEditListCtrlDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCEditListCtrlDlg message handlers

BOOL CCEditListCtrlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.
    m_ListCurrencyEdit.CreateEx(this, &m_list);
    m_ListMaskEdit.CreateEx(this, &m_list);
    m_ListDateEdit.CreateEx(this, &m_list);
    m_ListEdit.CreateEx(this, &m_list);
    m_ListComboBox.CreateEx(this, &m_list);

	m_ListComboBox.AddString("AAA");
	m_ListComboBox.AddString("BBB");
	m_ListComboBox.AddString("CCC");
	m_ListDateEdit.Insert(0);
	m_ListDateEdit.SetClassType("DateEdit");
	m_ListCurrencyEdit.Insert(1);
	m_ListMaskEdit.Insert(2);
	m_ListMaskEdit.SetMask("999");
	m_ListEdit.Insert(3);

	m_ListComboBox.Insert(4);
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_list.InsertColumn(0,_T("1"),LVCFMT_LEFT,100);
	m_list.InsertColumn(1,_T("2"),LVCFMT_LEFT,100);
	m_list.InsertColumn(2,_T("3"),LVCFMT_LEFT,100);
	m_list.InsertColumn(3,_T("4"),LVCFMT_LEFT,100);
	m_list.InsertColumn(4,_T("5"),LVCFMT_LEFT,100);
	m_list.InsertColumn(5,_T("6"),LVCFMT_LEFT,100);
	
	m_list.InsertItem(0,_T("2005-01-02"));
	m_list.SetItemText(0,1,_T("1"));
	m_list.SetItemText(0,2,_T("d"));
	m_list.SetItemText(0,3,_T("e"));
	m_list.SetItemText(0,4,_T(""));
	m_list.SetItemText(0,5,_T("��ֹ�༭"));

	m_list.InsertItem(1,_T("456"));
	m_list.SetItemText(1,1,_T("2"));
	m_list.SetItemText(1,2,_T("g"));
	m_list.SetItemText(1,3,_T("h"));
	m_list.SetItemText(1,4,_T(""));
	m_list.SetItemText(1,5,_T("��ֹ�༭"));

	m_list.InsertItem(2,_T("789"));
	m_list.SetItemText(2,1,_T("3"));
	m_list.SetItemText(2,2,_T("j"));
	m_list.SetItemText(2,3,_T("k"));
	m_list.SetItemText(2,4,_T(""));
	m_list.SetItemText(2,5,_T("��ֹ�༭"));

//    m_list.SetExtendedStyle(LVS_EX_GRIDLINES );
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCEditListCtrlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCEditListCtrlDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCEditListCtrlDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



void CCEditListCtrlDlg::OnOK() 
{
	// TODO: Add extra validation here
	return;
	CDialog::OnOK();
}

void CCEditListCtrlDlg::OnCancel() 
{
	// TODO: Add extra cleanup here

	CDialog::OnCancel();
}

BOOL CCEditListCtrlDlg::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN)
	{
		if(pMsg->wParam == VK_ESCAPE)
		{
			return TRUE;
		}
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}






//ָ����4��COMBOX���Ե����򿪱༭����
void CCEditListCtrlDlg::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int nItem, nSubItem;
    if (CListCtrlEditBase::HitTestEx(&m_list, pNMHDR, nItem, nSubItem) &&
	    nSubItem == 4)
	{
	   m_ListComboBox.ShowEdit(nItem, nSubItem);
	}
	*pResult = 0;
}
//˫���򿪱༭����
void CCEditListCtrlDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
//�Զ����в��򿪱༭����
    CListCtrlEditBase::OnOpen(&m_list, pNMHDR);
	*pResult = 0;
}
