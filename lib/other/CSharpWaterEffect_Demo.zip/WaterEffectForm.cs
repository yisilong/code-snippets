using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WaterEffectDemo
{
	/// <summary>
	/// Summary description for WaterEffectForm.
	/// </summary>
	public class WaterEffectForm : System.Windows.Forms.Form
	{
		//private System.Windows.Forms.PictureBox waterControl;
		private WaterEffectControl waterControl;
		

		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public WaterEffectForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WaterEffectForm));
			this.waterControl = new WaterEffectDemo.WaterEffectControl();
			this.SuspendLayout();
			// 
			// waterControl
			// 
			this.waterControl.BackColor = System.Drawing.Color.White;
			this.waterControl.ImageBitmap = ((System.Drawing.Bitmap)(resources.GetObject("waterControl.ImageBitmap")));
			this.waterControl.Location = new System.Drawing.Point(32, 16);
			this.waterControl.Name = "waterControl";			
			this.waterControl.Size = new System.Drawing.Size(450, 144);
			this.waterControl.TabIndex = 0;
			// 
			// WaterEffectForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 181);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.waterControl});
			this.Name = "WaterEffectForm";
			this.Text = "Water Effect";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new WaterEffectForm());
		}
	}
}
