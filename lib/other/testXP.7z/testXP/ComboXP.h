// ComboXP.h: interface for the CComboXP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMBOXP_H__C4A6C1A6_9865_49DA_B910_D76F3825B1F6__INCLUDED_)
#define AFX_COMBOXP_H__C4A6C1A6_9865_49DA_B910_D76F3825B1F6__INCLUDED_
#include "ClassXP.H"
LRESULT ComboWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);

#endif // !defined(AFX_COMBOXP_H__C4A6C1A6_9865_49DA_B910_D76F3825B1F6__INCLUDED_)
