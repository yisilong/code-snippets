// SkinSelectDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "SkinSelectDlg.h"
#include "RTXmlFile.h"
#include "RTText.h"

// CSkinSelectDlg �Ի���

IMPLEMENT_DYNAMIC(CSkinSelectDlg, CRTDialog)

CSkinSelectDlg::CSkinSelectDlg(CWnd* pParent)
	: CRTDialog(CSkinSelectDlg::IDD, pParent)
{
}

CSkinSelectDlg::~CSkinSelectDlg()
{
}

void CSkinSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CRTDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_SkinList);
	DDX_Control(pDX, IDOK, m_ButtonOK);
	DDX_Control(pDX, IDC_SkinGroup, m_SkinGroup);
	DDX_Control(pDX, IDC_CtrlGroup, m_ControlGroup);
	
	DDX_Control(pDX, IDC_chkSDIBorder, m_chkSDIBorder);
	DDX_Control(pDX, IDC_chkSDITitleBar, m_chkSDITitleBar);
	DDX_Control(pDX, IDC_chkDlgBack, m_chkDlgBack);
	DDX_Control(pDX, IDC_chkDlgBorder, m_chkDlgBorder);
	DDX_Control(pDX, IDC_chkDlgTitleBar, m_chkDlgTitleBar);
	DDX_Control(pDX, IDC_chkMenuBar, m_chkMenuBar);
	DDX_Control(pDX, IDCANCEL, m_ButtonCancel);
}


BEGIN_MESSAGE_MAP(CSkinSelectDlg, CRTDialog)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, OnLvnItemchangedList1)
	ON_BN_CLICKED(IDC_chkDlgBack, OnBnClickedchkdlgback)
	ON_BN_CLICKED(IDC_chkDlgBorder, OnBnClickedchkdlgborder)
	ON_BN_CLICKED(IDC_chkDlgTitleBar, OnBnClickedchkdlgtitlebar)
	ON_BN_CLICKED(IDC_chkMenuBar, OnBnClickedchkmenubar)
	ON_BN_CLICKED(IDC_chkSDIBorder, OnBnClickedchksdiborder)
	ON_BN_CLICKED(IDC_chkSDITitleBar, OnBnClickedchksdititlebar)
END_MESSAGE_MAP()


// CSkinSelectDlg ��Ϣ��������

BOOL CSkinSelectDlg::OnInitDialog()
{
	CRTDialog::OnInitDialog();

	m_ImgList.Create(16,16,ILC_COLOR,0,0);
	DWORD exStyle = m_SkinList.GetExStyle();
	exStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES;
	exStyle &= ~LVS_EX_CHECKBOXES;
	m_SkinList.SetExtendedStyle(exStyle);
	
	m_SkinList.SetImageList(&m_ImgList,LVSIL_STATE);
	m_SkinList.InsertColumn(0,"",LVCFMT_LEFT,0);
	m_SkinList.InsertColumn(1,"����",LVCFMT_LEFT,260);
	m_SkinList.InsertColumn(2,"�ļ�·��",LVCFMT_LEFT,0);

	int i = 0;
	int items = 0;
	items = m_SkinList.InsertItem(i++,"");
	m_SkinList.SetItemText(items,1,"Windowsȱʡ");
	m_SkinList.SetItemText(items,2,"...");
	m_SkinList.SetItemData(items,(DWORD_PTR)FALSE);

	char AppPath[MAX_PATH];
	int nLen = GetModuleFileName(NULL,AppPath,MAX_PATH) - 1;
	while(nLen >= 0)
	{
		if(AppPath[nLen] == '\\')
		{
			AppPath[nLen] = NULL;
			break;
		}
		nLen --;
	}

	char SkinPath[MAX_PATH];
	ZeroMemory(SkinPath,MAX_PATH);
	strcpy(SkinPath,AppPath);
	strcat(SkinPath,"\\Skin");

	char SkinFind[MAX_PATH];
	ZeroMemory(SkinFind,MAX_PATH);
	strcpy(SkinFind,SkinPath);
	strcat(SkinFind,"\\*.*");

	WIN32_FIND_DATA wfd;
	HANDLE hFind = FindFirstFile(SkinFind,&wfd);

	if(hFind == NULL)return TRUE;

	BOOL bSkinFind = FALSE;
	m_SkinFile = m_SkinFile.Trim();

	do{
		if((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{
			if(wfd.cFileName[0] == '.')continue;

			char SkinFile[MAX_PATH];
			ZeroMemory(SkinFile,MAX_PATH);
			strcpy(SkinFile,SkinPath);
			strcat(SkinFile,"\\");
			strcat(SkinFile,wfd.cFileName);
			strcat(SkinFile,"\\skin.ini");
			CRTXmlFile xmlFile;
			if(!xmlFile.Open(SkinFile))continue;

			CRTXmlItem *pItem = xmlFile.GetItem("Skin");
			if(pItem == NULL)continue;
			LPCTSTR lpName = pItem->GetKeyValue("Name");
			if(lpName == NULL)continue;

			items = m_SkinList.InsertItem(i,"");
			m_SkinList.SetItemText(items,1,lpName);
			m_SkinList.SetItemText(items,2,SkinFile);
			m_SkinList.SetItemData(items,(DWORD_PTR)TRUE);
			if(bEnableSkin && CRTText::Compare(m_SkinFile,SkinFile))
			{
				bSkinFind = TRUE;
				m_SkinList.SetItemState(items,LVIS_SELECTED,LVIS_SELECTED);
			}
            i++;
		}
	}while(FindNextFile(hFind,&wfd));

	FindClose(hFind);

	if(!bSkinFind)m_SkinList.SetItemState(0,LVIS_SELECTED,LVIS_SELECTED);

	if(EnableSDIBorder)m_chkSDIBorder.SetCheck(BST_CHECKED);
	if(EnableSDITitleBar)m_chkSDITitleBar.SetCheck(BST_CHECKED);
	if(EnableDLGBorder)m_chkDlgBorder.SetCheck(BST_CHECKED);
	if(EnableDlgBack)m_chkDlgBack.SetCheck(BST_CHECKED);
	if(EnableDLGTitleBar)m_chkDlgTitleBar.SetCheck(BST_CHECKED);
	if(EnableMenuBar)m_chkMenuBar.SetCheck(BST_CHECKED);

	return TRUE; 
}

void CSkinSelectDlg::OnLvnItemchangedList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	if(pNMLV->uChanged == LVIF_STATE && pNMLV->uNewState)
	{
		BOOL bEnable = (BOOL)m_SkinList.GetItemData(pNMLV->iItem);
		char SkinFile[MAX_PATH];
		int nLen = m_SkinList.GetItemText(pNMLV->iItem,2,SkinFile,MAX_PATH);
		SkinFile[nLen] = NULL;

		GetParent()->SendMessage(WM_SETSKIN,(WPARAM)bEnable,(LPARAM)SkinFile);

		Invalidate();
		SendMessage(WM_NCPAINT,1,0);
		if(!bEnable)
		{
			m_chkMenuBar.SetCheck(BST_UNCHECKED);
			OnBnClickedchkmenubar();
		}
		else
		{
			m_chkMenuBar.SetCheck(BST_CHECKED);
			OnBnClickedchkmenubar();
		}
	}

	*pResult = 0;
}

void CSkinSelectDlg::OnBnClickedchkdlgback()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkDlgBack.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkDlgBack,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

void CSkinSelectDlg::OnBnClickedchkdlgborder()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkDlgBorder.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkDlgBorder,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

void CSkinSelectDlg::OnBnClickedchkdlgtitlebar()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkDlgTitleBar.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkDlgTitleBar,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

void CSkinSelectDlg::OnBnClickedchkmenubar()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkMenuBar.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkMenuBar,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

void CSkinSelectDlg::OnBnClickedchksdiborder()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkSDIBorder.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkSDIBorder,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

void CSkinSelectDlg::OnBnClickedchksdititlebar()
{
	BOOL bEnable = FALSE;
	if(BST_CHECKED == m_chkSDITitleBar.GetCheck())
		bEnable = TRUE;

	GetParent()->SendMessage(WM_SKINENABLE,IDC_chkSDITitleBar,bEnable);

	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
}

