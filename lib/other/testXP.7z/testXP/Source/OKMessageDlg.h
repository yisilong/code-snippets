#pragma once


// COKMessageDlg �Ի���
#include "RTDialog.h"
#include "rtstatic.h"
#include "rtbutton.h"

class COKMessageDlg : public CRTDialog
{
	DECLARE_DYNAMIC(COKMessageDlg)

public:
	COKMessageDlg(CWnd* pParent,LPCTSTR lpCaption,LPCTSTR lpMessage);   // ��׼���캯��
	virtual ~COKMessageDlg();

// �Ի�������
	enum { IDD = IDD_MessageOKDlg };

protected:
	CString m_Cpation;
	CString m_Message;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CRTStatic m_s_Message;
	CRTButton m_b_OK;
	CRTButton m_b_Cancel;
	virtual BOOL OnInitDialog();
};
