//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WebGet.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_SP_FILEDOWN                  101
#define IDD_LEFTFORM                    102
#define ID_SP_WEBDOWN                   102
#define ID_SP_WEBMGR                    103
#define ID_SP_MAIN                      104
#define ID_SP_FILEDOWNINFO              105
#define IDR_MAINFRAME                   128
#define IDR_TOOLBARFILEDOWN             128
#define IDR_WebGetTYPE                  129
#define IDD_RIGHTFORM                   130
#define ID_SkinSetting                  131
#define IDD_FileDownList                131
#define ID_SystemSetting                132
#define IDD_FileDownInfo                132
#define ID_WebSetting                   133
#define ID_Menu                         134
#define IDR_TOOLBARWEBMGR               135
#define IDR_TOOLBARWEBDOWN              137
#define IDR_MenuFileDown                139
#define ID_140                          140
#define ID_NewFileDownTask              141
#define ID_NewWebDownTask               141
#define ID_142                          142
#define ID_NewFileDownType              143
#define ID_NewWebDownType               143
#define ID_DeleteFileDownType           144
#define ID_DeleteWebDownType            144
#define ID_FileDownTypeProperty         145
#define ID_WebDownTypeProperty          145
#define ID_MoveFileDownType             146
#define ID_MoveWebDownType              146
#define IDR_MenuPopWebDown              147
#define IDD_AddFileDownTask             148
#define IDD_MessageOKDlg                149
#define ID_150                          150
#define IDD_DIALOG1                     151
#define IDD_SKINSELECTDLG               152
#define IDB_SP_VER_CUR                  155
#define IDB_SP_VER_MASK                 156
#define IDB_SP_HOR_CUR                  157
#define IDB_SP_HOR_MASK                 158
#define ID__                            159
#define ID__160                         160
#define ID__161                         161
#define ID__162                         162
#define ID__163                         163
#define ID__164                         164
#define ID__165                         165
#define ID_Menu166                      166
#define ID_167                          167
#define ID__168                         168
#define ID__169                         169
#define IDC_TabTaskMgr                  1000
#define IDC_TreeWebDown                 1001
#define IDC_TreeWebMgr                  1002
#define IDC_TreeFileDown                1003
#define IDC_TabRight                    1005
#define IDC_ListFileDown                1006
#define IDC_ListWebMgr                  1007
#define IDC_ListWebDown                 1008
#define IDC_ListDownFile                1009
#define IDC_ListWebMgrInfo              1010
#define IDC_ListWebDownInfo             1014
#define IDC_TreeFileDownInfo            1015
#define IDC_LIST1                       1017
#define IDC_E_TypeName                  1019
#define IDC_E_SavePath                  1020
#define IDC_E_FileFilter                1021
#define IDC_B_Browser                   1022
#define IDC_S_TypeName                  1025
#define IDC_S_SavePath                  1026
#define IDC_S_FileFilter                1027
#define IDC_S_ParentType                1028
#define IDC_S_ParentTypeName            1029
#define IDC_S_MESSAGE                   1030
#define IDC_PROGRESS1                   1032
#define IDC_SkinGroup                   1034
#define IDC_CtrlGroup                   1035
#define IDC_chkDlgTitleBar              1038
#define IDC_chkSDIBorder                1045
#define IDC_chkDlgBorder                1046
#define IDC_chkDlgBack                  1047
#define IDC_chkMenuBar                  1048
#define IDC_AppMark                     1054
#define IDC_AppInfo                     1055
#define IDC_chkSDITitleBar              1063
#define ID_BUTTON32771                  32771
#define ID_BUTTON32772                  32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        170
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
