#pragma once
#include "RTTabCtrl.h"
#include "RTListCtrl.h"
#include "RTTreeCtrl.h"
#include "RTSplitterWnd.h"
#include "FileDownInfo.h"

// CRightForm �Ի���
class CLeftForm;

class CRightForm : public CPropertyPage
{
	DECLARE_DYNAMIC(CRightForm)

public:
	CRightForm();
	virtual ~CRightForm();

	typedef struct _RTDownItemInfo
	{
		char SaveFile[MAX_PATH];
		__time64_t DownLoadTime;
		char URL[1024];
		BOOL IsContent;//�̴�
		char Ref[1024];//����ҳ
		int  FileSize;

		__time64_t tmpUseTime;//����ʱ��
		__time64_t tmpRetTime;//ʣ��ʱ��

		int        tmpDownByte;
		int        tmpSpeed;
        
	}RTDownItemInfo;


// �Ի�������
	enum { IDD = IDD_RIGHTFORM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CLeftForm *m_LeftForm;
	CRTTabCtrl m_TabRight;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	CRTListCtrl m_ListDwonFile;
	CRTListCtrl m_ListWebDown;
	CRTListCtrl m_ListWebMgr;
	CRTListCtrl m_ListWebMgrInfo;
	CRTListCtrl m_ListWebDownInfo;
	CRTTreeCtrl m_TreeFileDownInfo;
	CRTSplitterWnd m_SplitterFileDown;
	CRTSplitterWnd m_SplitterWebDown;
	CRTSplitterWnd m_SplitterWebMgr;
	CRTSplitterWnd m_SplitterFileDownInfo;
	CFileDownInfo m_FileDownInfo;
	virtual BOOL OnInitDialog();
	void SetCurSel(int sel);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};
