// RTTreeCtrl.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RTTreeCtrl.h"
#include "RTDraw.h"

// CRTTreeCtrl

IMPLEMENT_DYNAMIC(CRTTreeCtrl, CTreeCtrl)
CRTTreeCtrl::CRTTreeCtrl()
{
}

CRTTreeCtrl::~CRTTreeCtrl()
{
}

CBitmap* CRTTreeCtrl::m_BackBitmap[4] = {NULL,NULL,NULL,NULL};
UINT     CRTTreeCtrl::m_BackBitmapDrawMode[4] = {0,0,0,0};
BOOL     CRTTreeCtrl::m_IsEnableSkin = TRUE;


BEGIN_MESSAGE_MAP(CRTTreeCtrl, CTreeCtrl)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDING, OnTvnItemexpanding)
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDED, OnTvnItemexpanded)
END_MESSAGE_MAP()



// CRTTreeCtrl ��Ϣ��������
void CRTTreeCtrl::SetBackBitmap(CBitmap *pBack[],UINT DrawMode[])
{
	for(int i = 0; i < 4; i++)
	{
		m_BackBitmap[i] = pBack[i];
		m_BackBitmapDrawMode[i] = DrawMode[i];
	}
}

void CRTTreeCtrl::EnableSkin(BOOL IsEnable)
{
	m_IsEnableSkin = IsEnable;
}

BOOL CRTTreeCtrl::OnEraseBkgnd(CDC* pDC)
{
	if(!m_IsEnableSkin)
		return CTreeCtrl::OnEraseBkgnd(pDC);
	return TRUE;
}

void CRTTreeCtrl::OnPaint()
{
	int max = 0;
	int pos = 0;
	max = GetScrollLimit(SBS_VERT);
	pos = GetScrollPos(SBS_VERT);
	m_Container.SetVerRange(0,max);
	m_Container.SetVerPos(pos);

	max = GetScrollLimit(SBS_HORZ);
	pos = GetScrollPos(SBS_HORZ);
	m_Container.SetHorRange(0,max);
	m_Container.SetHorPos(pos);

	if(!m_IsEnableSkin)return CTreeCtrl::OnPaint();
  

	CRect rcWnd;
	GetClientRect(&rcWnd);
	CClientDC ptDC(this);

	CDC defDC;
	CMemDC memDC(&ptDC,rcWnd);

	defDC.CreateCompatibleDC(&ptDC);

	CBitmap  defBmp;
	CBitmap* defOld;
	
	defBmp.CreateCompatibleBitmap(&ptDC,rcWnd.Width(),rcWnd.Height());
	defOld = defDC.SelectObject(&defBmp);
	
	DefWindowProc(WM_ERASEBKGND, (WPARAM)defDC.m_hDC , 0);
	DefWindowProc(WM_PAINT, (WPARAM)defDC.m_hDC , 0);

	CRTDraw::RTDrawBitmap(&memDC,&rcWnd,m_BackBitmap[BMP_BACK],m_BackBitmapDrawMode[BMP_BACK]);

	memDC.TransparentBlt(rcWnd.left,rcWnd.top,rcWnd.Width(),rcWnd.Height(),&defDC,rcWnd.left,rcWnd.top,rcWnd.Width(),rcWnd.Height(),GetSysColor(COLOR_WINDOW));
	CPaintDC dc(this);
	defDC.SelectObject(defOld);
}


CScrollBar* CRTTreeCtrl::GetScrollBarCtrl(int nBar) const
{
	// TODO: �ڴ�����ר�ô����/����û���
	return NULL;
	//return CTreeCtrl::GetScrollBarCtrl(nBar);
}

void CRTTreeCtrl::PreSubclassWindow()
{
	m_Container.Create(this);
	CTreeCtrl::PreSubclassWindow();
}

int CRTTreeCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CTreeCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	m_Container.Create(this);
	return 0;
}

void CRTTreeCtrl::OnTvnItemexpanding(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	SetRedraw(FALSE);
	*pResult = 0;
}

void CRTTreeCtrl::OnTvnItemexpanded(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	SetRedraw(TRUE);
	*pResult = 0;
}

LRESULT CRTTreeCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	return CTreeCtrl::WindowProc(message, wParam, lParam);
}
