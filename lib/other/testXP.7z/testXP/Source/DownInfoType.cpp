#include "StdAfx.h"
#include "downinfotype.h"
#include "RTXmlFile.h"
#include "RTFolder.h"
CDownInfoType::CDownInfoType(void)
{
}

CDownInfoType::~CDownInfoType(void)
{
}

void CDownInfoType::LoadTreeTypeInfo(CTreeCtrl& TreeCtrl, HTREEITEM hParent,UINT Type)
{
	DownTypeInfo *pDTI = (DownTypeInfo *)TreeCtrl.GetItemData(hParent);
	if(pDTI == NULL)return;

	HTREEITEM hChildItem = TreeCtrl.GetChildItem(hParent);
	while(hChildItem != NULL)
	{
		ClearTreeTypeInfoData(TreeCtrl,hChildItem);
		TreeCtrl.DeleteItem(hChildItem);
		hChildItem = TreeCtrl.GetChildItem(hParent);
	}

	int layer = pDTI->Layer + 1;
	HTREEITEM hItem;
	char BaseTypePath[MAX_PATH];
	char BaseSavePath[MAX_PATH];
	char TypeFile[MAX_PATH];
	char find[MAX_PATH];
	strcpy(BaseSavePath,pDTI->SavePath);
	strcpy(BaseTypePath,pDTI->TypePath);

	ZeroMemory(find,MAX_PATH);
	strcpy(find,BaseTypePath);
	strcat(find,"\\*.*");

	WIN32_FIND_DATA wfd;
	HANDLE hFind = FindFirstFile(find,&wfd);
	if(INVALID_HANDLE_VALUE == hFind)return;

	do
	{
		if((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{
			if(wfd.cFileName[0] == '.')continue;
			
			ZeroMemory(TypeFile,MAX_PATH);
			strcpy(TypeFile,BaseTypePath);
			strcat(TypeFile,"\\");
			strcat(TypeFile,wfd.cFileName);

			pDTI = new DownTypeInfo;
			pDTI->Layer = layer;
			pDTI->Type = TYPE_DELETE | TYPE_EDIT | TYPE_ADD | Type;
			ZeroMemory(pDTI->SavePath,MAX_PATH);
			strcpy(pDTI->SavePath,BaseSavePath);
			strcat(pDTI->SavePath,"\\");
			strcat(pDTI->SavePath,wfd.cFileName);
			strcpy(pDTI->FileFilter,"*");
			strcpy(pDTI->TypePath,TypeFile);
		
			LoadTypeInfo(TypeFile,pDTI);
			hItem = TreeCtrl.InsertItem(wfd.cFileName,1,2,hParent);
			TreeCtrl.SetItemData(hItem,(DWORD_PTR)pDTI);
			LoadTreeTypeInfo(TreeCtrl,hItem);
		}
	}
	while(FindNextFile(hFind,&wfd));
	FindClose(hFind);
}

void CDownInfoType::LoadTypeInfo(LPCTSTR lpTypePath,DownTypeInfo* pDTI)
{
	char TypeFile[MAX_PATH];
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,lpTypePath);
	strcat(TypeFile,"\\");
	strcat(TypeFile,"type.ini");

	CRTXmlFile cfgFile;
	BOOL bNeedSave = FALSE;
	BOOL rtOpen = cfgFile.Open(TypeFile);
	CRTXmlItem *pItem = cfgFile.GetItem("TypeInfo");
	if(!rtOpen || pItem == NULL)
	{
		bNeedSave = TRUE;
		pItem = new CRTXmlItem("TypeInfo");
		pItem->SetKeyValue("SavePath",pDTI->SavePath);
		pItem->SetKeyValue("FileFilter",pDTI->FileFilter);
		cfgFile.AddItem(pItem);
	}
	else
	{
		LPCTSTR lpSavePath = pItem->GetKeyValue("SavePath");
		if(lpSavePath == NULL)
		{
			pItem->SetKeyValue("SavePath",pDTI->SavePath);
			bNeedSave = TRUE;
		}
		else
		{
			strcpy(pDTI->SavePath,lpSavePath);
		}

		LPCTSTR lpFileFilter = pItem->GetKeyValue("FileFilter");
		if(lpFileFilter == NULL)
		{
			pItem->SetKeyValue("FileFilter",pDTI->FileFilter);
			bNeedSave = TRUE;
		}
		else
		{
			strcpy(pDTI->FileFilter,lpFileFilter);
		}
	}

	if(bNeedSave)
	{
		cfgFile.Save();
	}
}


BOOL CDownInfoType::GetTreeTypePath(CTreeCtrl& TreeCtrl,HTREEITEM hItem, char lpBuf[])
{
	DownTypeInfo *pDTI = (DownTypeInfo *)TreeCtrl.GetItemData(hItem);
	if(pDTI == NULL)return FALSE;
	strcpy(lpBuf,pDTI->TypePath);
	return TRUE;
}

BOOL CDownInfoType::MoveTreeTypeInfoTo(CTreeCtrl& TreeCtrl, HTREEITEM hSrcItem, HTREEITEM hDestItem,UINT Type)
{
	char SrcPath[MAX_PATH];
	char DestPath[MAX_PATH];
	if(!GetTreeTypePath(TreeCtrl,hSrcItem,SrcPath))return FALSE;
	if(!GetTreeTypePath(TreeCtrl,hDestItem,DestPath))return FALSE;

	if(!CRTFolder::MoveTo(SrcPath,DestPath))return FALSE;
	TreeCtrl.DeleteItem(hSrcItem);
	LoadTreeTypeInfo(TreeCtrl,hDestItem,Type);
	return TRUE;
}

BOOL CDownInfoType::DeleteTreeTypeInfo(CTreeCtrl& TreeCtrl, HTREEITEM hDeleteItem)
{
	char TypePath[MAX_PATH];
	if(!GetTreeTypePath(TreeCtrl,hDeleteItem,TypePath))return FALSE;

	if(!CRTFolder::DeleteFolder(TypePath))return FALSE;
	ClearTreeTypeInfoData(TreeCtrl,hDeleteItem);
	TreeCtrl.DeleteItem(hDeleteItem);
	return TRUE;
}

void CDownInfoType::ClearTreeTypeInfoData(CTreeCtrl& TreeCtrl, HTREEITEM hItem)
{
	if(hItem == NULL)
	{
		hItem = TreeCtrl.GetRootItem();
	}
	if(hItem == NULL)return;

	DownTypeInfo *pDTI = (DownTypeInfo *)TreeCtrl.GetItemData(hItem);
	if(pDTI != NULL)delete pDTI;
	
	hItem = TreeCtrl.GetChildItem(hItem);
	while(hItem != NULL)
	{
		ClearTreeTypeInfoData(TreeCtrl,hItem);
		hItem = TreeCtrl.GetNextItem(hItem,TVGN_NEXT);
	}
}

BOOL CDownInfoType::SaveTypeInfo(CTreeCtrl& TreeCtrl,HTREEITEM hItem)
{
	char TypePath[MAX_PATH];
	if(!GetTreeTypePath(TreeCtrl,hItem,TypePath))
		return FALSE;

	DownTypeInfo *pDTI = (DownTypeInfo*)TreeCtrl.GetItemData(hItem);
	if(pDTI == NULL)return FALSE;
	return SaveTypeInfo(TypePath,pDTI);
}

BOOL CDownInfoType::SaveTypeInfo(LPCTSTR lpTypePath,DownTypeInfo* pDTI)
{
	if(pDTI == NULL)return TRUE;

	char TypeFile[MAX_PATH];
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,lpTypePath);
	strcat(TypeFile,"\\");
	strcat(TypeFile,"type.ini");

	CRTXmlFile cfgFile;
	BOOL bNeedSave = TRUE;
	BOOL rtOpen = cfgFile.Open(TypeFile);
	CRTXmlItem *pItem = cfgFile.GetItem("TypeInfo");
	if(!rtOpen || pItem == NULL)
	{
		pItem = new CRTXmlItem("TypeInfo");
		pItem->SetKeyValue("SavePath",pDTI->SavePath);
		pItem->SetKeyValue("FileFilter",pDTI->FileFilter);
		cfgFile.AddItem(pItem);
	}
	else
	{
		pItem->SetKeyValue("SavePath",pDTI->SavePath);
		pItem->SetKeyValue("FileFilter",pDTI->FileFilter);
	}

	if(bNeedSave)
	{
		cfgFile.Save();
	}
	return TRUE;
}

UINT CDownInfoType::GetDownInfoType(CTreeCtrl& TreeCtrl, HTREEITEM hItem)
{
	DownTypeInfo *pDownInfo = (DownTypeInfo*)TreeCtrl.GetItemData(hItem);
	if(pDownInfo == NULL)return 0;

	return pDownInfo->Type;
}
