#pragma once

#include "RTDialog.h"
#include "rtlistctrl.h"
#include "rtbutton.h"
#include "rtstatic.h"
#include "rtcheckbox.h"
// CSkinSelectDlg �Ի���

class CSkinSelectDlg : public CRTDialog
{
	DECLARE_DYNAMIC(CSkinSelectDlg)

public:
	CSkinSelectDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSkinSelectDlg();

// �Ի�������
	enum { IDD = IDD_SKINSELECTDLG };

protected:
	CImageList m_ImgList;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
protected:
	CRTListCtrl m_SkinList;
	CRTButton m_ButtonOK;
	CRTButton m_ButtonCancel;
	CRTStatic m_SkinGroup;
	CRTStatic m_ControlGroup;

	CRTCheckBox m_chkSDITitleBar;
	CRTCheckBox m_chkSDIBorder;
	CRTCheckBox m_chkMenuBar;
	CRTCheckBox m_chkDlgTitleBar;
	CRTCheckBox m_chkDlgBack;
	CRTCheckBox m_chkDlgBorder;

public:
	BOOL EnableSDITitleBar;
	BOOL EnableSDIBorder;
	BOOL EnableDLGTitleBar;
	BOOL EnableDLGBorder;
	BOOL EnableDlgBack;
	BOOL EnableMenuBar;
	BOOL bEnableSkin;
	CString m_SkinFile;

	virtual BOOL OnInitDialog();
	afx_msg void OnLvnItemchangedList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedchkdlgback();
	afx_msg void OnBnClickedchkdlgborder();
	afx_msg void OnBnClickedchkdlgtitlebar();
	afx_msg void OnBnClickedchkmenubar();
	afx_msg void OnBnClickedchksdiborder();
	afx_msg void OnBnClickedchksdititlebar();
};
