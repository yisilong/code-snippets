#pragma once

class CRTWnd
{
public:
	CRTWnd(void);
	~CRTWnd(void);

	typedef enum _tagDrawState
	{
		StateNormal = 0,
		StateDown = 1,
		StateFocus = 2,
		StateDisable = 3
	}DrawState;

	typedef enum _tagMouseState
	{
		MouseStateNormal = 0,
		MouseStateDown =1,
		MouseStateUp = 2
	}MouseState;

	typedef enum _tagTitleButtons
	{
		ExitButton = 0,
		MaximizeButton = 1,
		MinimizeButton = 2,
		NoneButton = -1
	}TitleButtons;


protected:
	static COLORREF    m_BorderColor[4];
	static CBitmap*    m_TitleBarBitmap[5];
	static CBitmap*    m_MenuBarBitmap[5];
	static CBitmap*    m_MaximizeButtonBitmap[5];
	static CBitmap*    m_MinimizeButtonBitmap[5];
	static CBitmap*    m_RestoreButtonBitmap[5];
	static CBitmap*    m_ExitButtonBitmap[5];

	static UINT        m_TitleBarBitmapDrawMode[5];
	static UINT        m_MenuBarBitmapDrawMode[5];
	static UINT        m_MaximizeButtonBitmapDrawMode[5];
	static UINT        m_MinimizeButtonBitmapDrawMode[5];
	static UINT        m_RestoreButtonBitmapDrawMode[5];
	static UINT        m_ExitButtonBitmapDrawMode[5];
	static BOOL        m_bUseRTStyle;
	static BOOL        m_bUsedDefTitleBar;

	BOOL        m_bActive;
	int         m_ExitButtonState;
	int         m_MaximizeButtonState;
	int         m_MinimizeButtonState;
	MouseState  m_NcMouseState;
	TitleButtons m_SelTitleButton;

public:
		static BOOL EnableRTStyle(BOOL bEnable = TRUE);

	BOOL RTDrawFrameBorder(CDC *pDC,HRGN hRgn,HWND hWnd);
	BOOL RTDrawMenuBar(CDC *pDC,HRGN hRgn,LPARAM lParam,HWND hWnd);
	BOOL RTDrawTitleBar(CDC* pDC,HRGN hRgn,BOOL bActive,HWND hWnd);
	BOOL RTDrawTitleBarButtons(CDC* pDC,HRGN hRgn,HWND hWnd);
	BOOL RTDrawDefaultMenu(LPARAM lParam,HRGN hRgn,HWND hWnd);

	static BOOL SetBorderColor(COLORREF ColorArray[]);
	static BOOL SetMaximizeButtonBitmap(CBitmap *MaximizeButtonBitmap[],UINT DrawMode[]);
	static BOOL SetMinimizeButtonBitmap(CBitmap *MinimizeButtonBitmap[],UINT DrawMode[]);
	static BOOL SetExitButtonBitmap(CBitmap *ExitButtonBitmap[],UINT DrawMode[]);
	static BOOL SetRestoreButtonBitmap(CBitmap* RestoreButtonBitmap[],UINT DrawMode[]);
	static BOOL SetTitleBarBitmap(CBitmap* TitleBarBitmap[],UINT DrawMode[]);
	static BOOL SetMenuBarBitmap(CBitmap* MenuBarBitmap[],UINT DrawMode[]);

	BOOL OnRTNcPaint(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNcActive(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTActive(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNodify(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTActiveApp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTSetIcon(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNcMouseMove(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNcLMouseDown(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNcLMouseUp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTMouseMove(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTLButtonUp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTNcHitTest(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTSetText(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTSetCursor(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTSysCommand(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL OnRTInitMenuPop(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
	BOOL RTWindowProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult);
};
