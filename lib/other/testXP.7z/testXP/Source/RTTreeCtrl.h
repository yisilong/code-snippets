#pragma once

#include "RTScrollControlContainer.h"
// CRTTreeCtrl

class CRTTreeCtrl : public CTreeCtrl
{
	DECLARE_DYNAMIC(CRTTreeCtrl)

public:
	CRTTreeCtrl();
	virtual ~CRTTreeCtrl();
	CRTScrollControlContainer m_Container;
protected:
	static CBitmap* m_BackBitmap[4];
	static UINT     m_BackBitmapDrawMode[4];
	static BOOL     m_IsEnableSkin;
	
protected:
	DECLARE_MESSAGE_MAP()
public:
	static void SetBackBitmap(CBitmap* pBack[],UINT DrawMode[]);
	static void EnableSkin(BOOL IsEanble = TRUE);


	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	virtual CScrollBar* GetScrollBarCtrl(int nBar) const;
protected:
	virtual void PreSubclassWindow();
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTvnItemexpanding(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnItemexpanded(NMHDR *pNMHDR, LRESULT *pResult);
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};


