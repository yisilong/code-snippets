#pragma once
#include "RTTabCtrl.h"
#include "RTTreeCtrl.h"
#include "RTMenu.h"

// CLeftForm �Ի���
class CRightForm;

class CLeftForm : public CPropertyPage
{
	DECLARE_DYNAMIC(CLeftForm)

public:
	CLeftForm();
	virtual ~CLeftForm();

// �Ի�������
	enum { IDD = IDD_LEFTFORM };

protected:
	HTREEITEM m_FileDownSelectIem;
	HTREEITEM m_FileDownCompleteItem;
	HTREEITEM m_FileDownUnCompleteItem;
	HTREEITEM m_FileDownRecycledItem;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	DECLARE_MENUXP()
public:

	CRightForm *m_RightForm;
	CRTTabCtrl m_TabTaskMgr;
	CRTTreeCtrl m_TreeFileDown;
	CRTTreeCtrl m_TreeWebMgr;
	CRTTreeCtrl m_TreeWebDown;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnInitDialog();

	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTcnSelchangeTabtaskmgr(NMHDR *pNMHDR, LRESULT *pResult);
	void InitFileDown(void);
	void InitWebDown();
	void InitWebMgr();
	afx_msg void OnNMRclickTreefiledown(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRclickTreewebdown(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNewfiledowntype();
	afx_msg void OnDeletefiledowntype();
	afx_msg void OnClose();
	afx_msg void OnFiledowntypeproperty();
};
