#pragma once


// CRTComboBox

class CRTComboBox : public CComboBox
{
	DECLARE_DYNAMIC(CRTComboBox)

public:
	CRTComboBox();
	virtual ~CRTComboBox();

protected:
	DECLARE_MESSAGE_MAP()
};


