#pragma once
#include "RTListCtrl.h"


// CFileDownInfo �Ի���

class CFileDownInfo : public CPropertyPage
{
	DECLARE_DYNAMIC(CFileDownInfo)

public:
	CFileDownInfo();
	virtual ~CFileDownInfo();

// �Ի�������
	enum { IDD = IDD_FileDownInfo };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CRTListCtrl m_ListFileDownInfo;
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
