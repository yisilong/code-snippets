// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "WebGet.h"
#include "RTMenu.h"
#include "MainFrm.h"
#include "RTSplitterWnd.h"
#include "SkinSelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CRTFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CRTFrameWnd)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_MENUXP_MESSAGES()
	ON_NOTIFY(TCN_SELCHANGE,IDC_TabTaskMgr,OnTabTaskMgrSelChange)
	ON_COMMAND(ID_SkinSetting, OnShowSelectSkinDlg)
	ON_MESSAGE(WM_SETSKIN,OnSelectedSkin)
	ON_MESSAGE(WM_SKINENABLE,OnEnableSkin)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR      // ״̬��ָʾ��
};


// CMainFrame ����/����

CMainFrame::CMainFrame()
{
	EnableSkin = FALSE;
	EnableSDITitleBar = TRUE;
	EnableSDIBorder = TRUE;
	EnableDLGTitleBar = TRUE;
	EnableDLGBorder = TRUE;
	EnableDlgBack = TRUE;
	EnableMenuBar = TRUE;
}

CMainFrame::~CMainFrame()
{
	if(m_hVerCursor != NULL)DestroyCursor(m_hVerCursor);
	if(m_hHorCursor != NULL)DestroyCursor(m_hHorCursor);
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CRTFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	//LoadCursor for class CRTSplitterWnd
	ICONINFO ii;
	ii.fIcon = FALSE;
	ii.hbmMask = LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_SP_VER_MASK));
	ii.hbmColor= LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_SP_VER_CUR));
	ii.xHotspot = 9;
	ii.yHotspot = 8;
	m_hVerCursor = (HCURSOR)CreateIconIndirect(&ii);
	DeleteObject(ii.hbmColor);
	DeleteObject(ii.hbmMask);

	ii.fIcon = FALSE;
	ii.hbmMask = LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_SP_HOR_MASK));
	ii.hbmColor= LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_SP_HOR_CUR));
	ii.xHotspot = 8;
	ii.yHotspot = 8;
	m_hHorCursor = (HCURSOR)CreateIconIndirect(&ii);
	DeleteObject(ii.hbmColor);
	DeleteObject(ii.hbmMask);

	CRTSplitterWnd::RTSetCursor(m_hVerCursor,m_hHorCursor);

	//load skin setting
	LoadSkin();
	UseSkin(EnableSkin);

	if (!m_ToolBarFileDown.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | CBRS_TOP
		 | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		 !m_ToolBarFileDown.LoadToolBar(IDR_TOOLBARFILEDOWN))
	{
		TRACE0("δ�ܴ���������1\n");
		return -1;      // δ�ܴ���
	}

	if (!m_ToolBarWebDown.CreateEx(this, TBSTYLE_FLAT, WS_CHILD  | CBRS_TOP
		 | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		 !m_ToolBarWebDown.LoadToolBar(IDR_TOOLBARWEBDOWN))
	{
		TRACE0("δ�ܴ���������2\n");
		return -1;      // δ�ܴ���
	}

	if (!m_ToolBarWebMgr.CreateEx(this, TBSTYLE_FLAT, WS_CHILD |CBRS_TOP
		 | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		 !m_ToolBarWebMgr.LoadToolBar(IDR_TOOLBARWEBMGR))
	{
		TRACE0("δ�ܴ���������3\n");
		return -1;      // δ�ܴ���
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}



	CRTMenu::SetXPLookNFeel(this);
	CRTMenu::SetXPLookNFeel(this,::GetSystemMenu(m_hWnd,FALSE));

	m_Splitter.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),this,AFX_IDW_PANE_FIRST);
	m_LeftForm.Create(CLeftForm::IDD,&m_Splitter);
	m_RightForm.Create(CRightForm::IDD,&m_Splitter);
	m_LeftForm.m_RightForm = &m_RightForm;
	m_RightForm.m_LeftForm = &m_LeftForm;
	m_Splitter.SetVertical(&m_LeftForm,&m_RightForm);
	
	m_ToolBarFileDown.ShowWindow(SW_SHOW);

	m_bAutoMenuEnable = FALSE;


	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CRTFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸� CREATESTRUCT cs ���޸Ĵ������
	// ��ʽ

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}


// CMainFrame ���

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame ��Ϣ��������

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{

	// ����ִ��Ĭ�ϴ���
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::UseSkin(BOOL IsEnable)
{
	m_Skin.UseSkin(IsEnable);
	EnableSkin = IsEnable;
	CRTFrameWnd::EnableSkin(IsEnable,EnableSDIBorder,EnableSDITitleBar);
	CRTDialog::EnableSkin(IsEnable,EnableDLGBorder,EnableDlgBack,EnableDLGTitleBar);
	CRTMenu::EnableSkin(EnableMenuBar);
}

BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle , CWnd* pParentWnd , CCreateContext* pContext)
{
	if(!CRTFrameWnd::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
		return FALSE;

	CRTMenu::UpdateMenuBar(this);
	return TRUE;
}

void CMainFrame::OnUpdateFrameMenu(HMENU hMenuAlt)
{
	CRTFrameWnd::OnUpdateFrameMenu(hMenuAlt);
	CRTMenu::UpdateMenuBar(this);
}

BOOL CMainFrame::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	return CRTFrameWnd::OnNotify(wParam, lParam, pResult);
}

afx_msg void CMainFrame::OnTabTaskMgrSelChange(NMHDR *pNMHDR, LRESULT *pResult)
{
	int sel = TabCtrl_GetCurSel(pNMHDR->hwndFrom);
	if(sel == 0)
	{
		m_ToolBarFileDown.ShowWindow(SW_SHOW);
		m_ToolBarWebDown.ShowWindow(SW_HIDE);
		m_ToolBarWebMgr.ShowWindow(SW_HIDE);
	}
	else if(sel == 1)
	{
		m_ToolBarFileDown.ShowWindow(SW_HIDE);
		m_ToolBarWebDown.ShowWindow(SW_SHOW);
		m_ToolBarWebMgr.ShowWindow(SW_HIDE);
	}
	else
	{
		m_ToolBarFileDown.ShowWindow(SW_HIDE);
		m_ToolBarWebDown.ShowWindow(SW_HIDE);
		m_ToolBarWebMgr.ShowWindow(SW_SHOW);
	}
	RecalcLayout();
}
void CMainFrame::OnShowSelectSkinDlg()
{
	CSkinSelectDlg dlgSkin(this);

	dlgSkin.EnableSDIBorder = EnableSDIBorder;
	dlgSkin.EnableSDITitleBar = EnableSDITitleBar;
	dlgSkin.EnableDLGBorder = EnableDLGBorder;
	dlgSkin.EnableDlgBack = EnableDlgBack;
	dlgSkin.EnableDLGTitleBar = EnableDLGTitleBar;
	dlgSkin.EnableMenuBar = EnableMenuBar;
	dlgSkin.m_SkinFile = SkinFile;
	dlgSkin.bEnableSkin = EnableSkin;

	if(IDOK == dlgSkin.DoModal())
	{
		strcpy(SkinFile,dlgSkin.m_SkinFile);
		SaveSkin();
	}
	else
	{
		LoadSkin();
		Invalidate();
		SendMessage(WM_NCPAINT,1,0);
	}
}

LRESULT CMainFrame::OnSelectedSkin(WPARAM wParam,LPARAM lParam)
{
	UseSkin((BOOL)wParam);

	if(((BOOL)wParam))
	{
		LPCTSTR lpSkinFile = (LPCTSTR)lParam;
		strcpy(SkinFile,lpSkinFile);
		m_Skin.Load(lpSkinFile);
	}
	else
	{
		strcpy(SkinFile,"...");
	}
	
	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
	return 0;
}
void CMainFrame::LoadSkin(void)
{
	//Load skin.ini
	char path[MAX_PATH];
	ZeroMemory(path,MAX_PATH);
	char AppPath[MAX_PATH];
	ZeroMemory(AppPath,MAX_PATH);
	int nlen = GetModuleFileName(NULL,AppPath,MAX_PATH);
	while(nlen > 0)
	{
		if(AppPath[nlen] == '\\')
		{
			AppPath[nlen] = NULL;
			break;
		}
		else
		{
			AppPath[nlen] = NULL;
		}
		nlen --;
	}

	ZeroMemory(path,MAX_PATH);
	strcpy(path,AppPath);
	strcat(path,"\\skin.ini");
	m_SkinFile.Open(path);

	//sin setting
	CRTXmlItem* pItem = m_SkinFile.GetItem("Skin");

    if(pItem != NULL)
	{
		EnableSkin = pItem->GetKeyValueBool("UseSkin");
		LPCTSTR lpSkinFile = pItem->GetKeyValue("SkinFile");
		if(lpSkinFile != NULL)
		{
			m_Skin.Load(lpSkinFile);
			strcpy(SkinFile,lpSkinFile);
		}
	}
	else
	{
		pItem = new CRTXmlItem("Skin");
		m_SkinFile.AddItem(pItem);
	}

	pItem = m_SkinFile.GetItem("SDI");
	if(pItem != NULL)
	{
		EnableSDIBorder = pItem->GetKeyValueBool("Border");
		EnableSDITitleBar=pItem->GetKeyValueBool("TitleBar");
	}
	else
	{
		pItem = new CRTXmlItem("SDI");
		m_SkinFile.AddItem(pItem);
	}

	pItem = m_SkinFile.GetItem("Dialog");

	if(pItem != NULL)
	{
		EnableDLGBorder = pItem->GetKeyValueBool("Border");
		EnableDLGTitleBar=pItem->GetKeyValueBool("TitleBar");
		EnableDlgBack   = pItem->GetKeyValueBool("Back");
	}
	else
	{
		pItem = new CRTXmlItem("Dialog");
		m_SkinFile.AddItem(pItem);
	}

	pItem = m_SkinFile.GetItem("Menu");
	if(pItem != NULL)
	{
		EnableMenuBar = pItem->GetKeyValueBool("Enable");
	}
	else
	{
		pItem = new CRTXmlItem("Menu");
		m_SkinFile.AddItem(pItem);
	}

	//set skin
	UseSkin(EnableSkin);
}

void CMainFrame::SaveSkin(void)
{
	CRTXmlItem* pItem = m_SkinFile.GetItem("Skin");
    if(pItem != NULL)
	{
		pItem->SetKeyValue("UseSkin",(DWORD)EnableSkin);
		pItem->SetKeyValue("SkinFile",SkinFile);
	}
	

	pItem = m_SkinFile.GetItem("SDI");
	if(pItem != NULL)
	{
		pItem->SetKeyValue("Border",(BOOL)EnableSDIBorder);
		pItem->SetKeyValue("TitleBar",(BOOL)EnableSDITitleBar);
	}
	
	pItem = m_SkinFile.GetItem("Dialog");
	if(pItem != NULL)
	{
		pItem->SetKeyValue("Border",(BOOL)EnableDLGBorder);
		pItem->SetKeyValue("TitleBar",(BOOL)EnableDLGTitleBar);
		pItem->SetKeyValue("Back",(BOOL)EnableDlgBack);
	}

	pItem = m_SkinFile.GetItem("Menu");
	if(pItem != NULL)
	{
		pItem->SetKeyValue("Enable",(BOOL)EnableMenuBar);
	}

	m_SkinFile.Save();
}

LRESULT CMainFrame::OnEnableSkin(WPARAM wParam,LPARAM lParam)
{
	switch(wParam)
	{
	case IDC_chkDlgBack:
		EnableDlgBack = (BOOL)lParam;
		break;
	case IDC_chkDlgBorder:
		EnableDLGBorder = (BOOL)lParam;
		break;
	case IDC_chkDlgTitleBar:
		EnableDLGTitleBar = (BOOL)lParam;
		break;
	case IDC_chkSDIBorder:
		EnableSDIBorder = (BOOL)lParam;
		break;
	case IDC_chkSDITitleBar:
		EnableSDITitleBar = (BOOL)lParam;
		break;
	case IDC_chkMenuBar:
		EnableMenuBar = (BOOL)lParam;
		break;
	}
	UseSkin(EnableSkin);
	Invalidate();
	SendMessage(WM_NCPAINT,1,0);
	return 0;
}
