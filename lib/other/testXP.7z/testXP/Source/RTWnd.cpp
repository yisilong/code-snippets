#include "StdAfx.h"
#include "rtwnd.h"
#include "RTDraw.h"

CRTWnd::CRTWnd(void)
{
	m_bActive = FALSE;

	m_ExitButtonState = StateNormal;
	m_MinimizeButtonState = StateNormal;
	m_MaximizeButtonState = StateNormal;
	m_NcMouseState = MouseStateNormal;
	m_SelTitleButton = NoneButton;
}

CRTWnd::~CRTWnd(void)
{
}

COLORREF CRTWnd::m_BorderColor[4] = {0xAD9E9C,0xCEBEB5,0xCEBEB5,0xDED3CE};
BOOL     CRTWnd::m_bUseRTStyle = TRUE;
BOOL     CRTWnd::m_bUsedDefTitleBar = TRUE;
CBitmap* CRTWnd::m_TitleBarBitmap[5] = {NULL,NULL,NULL,NULL,NULL};
CBitmap* CRTWnd::m_MenuBarBitmap[5] = {NULL,NULL,NULL,NULL,NULL};
CBitmap* CRTWnd::m_MaximizeButtonBitmap[5] = {NULL,NULL,NULL,NULL,NULL};
CBitmap* CRTWnd::m_MinimizeButtonBitmap[5] = {NULL,NULL,NULL,NULL,NULL};
CBitmap* CRTWnd::m_RestoreButtonBitmap[5] = {NULL,NULL,NULL,NULL,NULL};
CBitmap* CRTWnd::m_ExitButtonBitmap[5] = {NULL,NULL,NULL,NULL,NULL};

UINT     CRTWnd::m_TitleBarBitmapDrawMode[5] = {0,0,0,0,0};
UINT     CRTWnd::m_MenuBarBitmapDrawMode[5] = {0,0,0,0,0};
UINT     CRTWnd::m_MaximizeButtonBitmapDrawMode[5] = {0,0,0,0,0};
UINT     CRTWnd::m_MinimizeButtonBitmapDrawMode[5] = {0,0,0,0,0};
UINT     CRTWnd::m_ExitButtonBitmapDrawMode[5] = {0,0,0,0,0};
UINT     CRTWnd::m_RestoreButtonBitmapDrawMode[5] = {0,0,0,0,0};

BOOL CRTWnd::RTDrawFrameBorder(CDC *pDC,HRGN hRgn,HWND hWnd)
{
	
	//�����
	int Frame_BorderWidth = 0;
	int Frame_BorderHeight = 0;

	DWORD style = GetWindowLong(hWnd,GWL_STYLE);
	if( (style & WS_DLGFRAME) == WS_DLGFRAME)
	{
		int Frame_BorderWidth = GetSystemMetrics(SM_CXDLGFRAME);
		int Frame_BorderHeight = GetSystemMetrics(SM_CYDLGFRAME);
	}
	else if((style & WS_THICKFRAME) == WS_THICKFRAME)
	{
		int Frame_BorderWidth = GetSystemMetrics(SM_CXFRAME);
		int Frame_BorderHeight = GetSystemMetrics(SM_CYFRAME);
	}

	//������߿�
	CRect rtWnd,rtBorder;
	GetWindowRect(hWnd,&rtWnd);
	rtBorder.SetRect(0,0,rtWnd.Width(),rtWnd.Height());

	if(m_bUsedDefTitleBar)
	{
		DefWindowProc(hWnd,WM_NCPAINT,1,0);
		return TRUE;
	}

	for(int i = 0; i < Frame_BorderWidth ; i ++)
	{
		if(i < 4)
		{
			pDC->Draw3dRect(i,i,rtWnd.Width() - 2*i,rtWnd.Height() - 2*i,m_BorderColor[i],m_BorderColor[i]);
		}
		else
		{
			pDC->Draw3dRect(i,i,rtWnd.Width() - 2*i,rtWnd.Height() - 2*i,m_BorderColor[3],m_BorderColor[3]);
		}
	}
	return TRUE;
}


BOOL CRTWnd::RTDrawMenuBar(CDC *pDC,HRGN hRgn,LPARAM lParam,HWND hWnd)
{
	HMENU hMenu = GetMenu(hWnd);
	if(hMenu == NULL)return TRUE;

	if(m_MenuBarBitmap[0] == NULL)return FALSE;

	CRect rtMenu;
	CRect rtWnd;
	
	GetWindowRect(hWnd,&rtWnd);
	rtMenu.left = GetSystemMetrics(SM_CXFRAME);
	rtMenu.top = GetSystemMetrics(SM_CYSIZE) + GetSystemMetrics(SM_CXFRAME) + 1;
	rtMenu.right = rtWnd.Width() - GetSystemMetrics(SM_CXFRAME);
	rtMenu.bottom = rtMenu.top +  GetSystemMetrics(SM_CYMENU);

	UINT ItemCount = GetMenuItemCount(hMenu);

	int PrevTop = rtMenu.top;
	int PrevLeft = rtMenu.left;
	int MenuItemHeight = GetSystemMetrics(SM_CYMENU);
	CRect rtMenuItem;
	
	//���˵��ϲ���
	CBrush brMenu(GetSysColor(COLOR_MENU));
	CBrush* pOldBrush = pDC->SelectObject(&brMenu);
	pDC->PatBlt(rtMenu.left,rtMenu.top - 1,rtMenu.Width(),1, PATCOPY);
	
		pDC->PatBlt(rtMenu.left,rtMenu.top - 1,rtMenu.Width(),1, PATCOPY);
	
	for(UINT items = 0; items < ItemCount; items++)
	{
		GetMenuItemRect(hWnd,hMenu,items,&rtMenuItem);
		int MenuTop = rtMenuItem.top - rtWnd.top;
		MenuItemHeight = rtMenuItem.Height();
		if(MenuTop != PrevTop)
		{
			CRect rtDraw(PrevLeft,PrevTop,rtMenu.right,PrevTop + MenuItemHeight);
			CRTDraw::RTDrawBitmap(pDC,&rtDraw,m_MenuBarBitmap[BMP_BACK],m_MenuBarBitmapDrawMode[BMP_BACK]);

			PrevTop = MenuTop;
			PrevLeft = rtMenu.left + rtMenuItem.Width();
		}
		else
		{
			PrevLeft += rtMenuItem.Width();
		}
	}

	CRect rtDraw(PrevLeft,PrevTop,rtMenu.right,PrevTop + MenuItemHeight);
	CRTDraw::RTDrawBitmap(pDC,&rtDraw,m_MenuBarBitmap[BMP_BACK],m_MenuBarBitmapDrawMode[BMP_BACK]);
	//���˵��ϲ���
	pDC->PatBlt(rtMenu.left,PrevTop + MenuItemHeight,rtMenu.Width(),1, PATCOPY);
	pDC->SelectObject(pOldBrush);
	return TRUE;
}

BOOL CRTWnd::SetMinimizeButtonBitmap(CBitmap *MinimizeButtonBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_MinimizeButtonBitmap[i] = MinimizeButtonBitmap[i];
		m_MinimizeButtonBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}

BOOL CRTWnd::SetTitleBarBitmap(CBitmap *TitleBarBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_TitleBarBitmap[i] = TitleBarBitmap[i];
		m_TitleBarBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}

BOOL CRTWnd::SetMenuBarBitmap(CBitmap* MenuBarBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_MenuBarBitmap[i] = MenuBarBitmap[i];
		m_MenuBarBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}

BOOL CRTWnd::SetMaximizeButtonBitmap(CBitmap* MaximizeButtonBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_MaximizeButtonBitmap[i] =  MaximizeButtonBitmap[i];
		m_MinimizeButtonBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}

BOOL CRTWnd::SetBorderColor(COLORREF ColorArray[])
{
	for(int i = 0; i < 5 ; i++)
		m_BorderColor[i] = ColorArray[i];
	return TRUE;
}

BOOL CRTWnd::RTDrawTitleBar(CDC* pDC,HRGN hRgn,BOOL bActive,HWND hWnd)
{
	//ȡ�ñ�������λ��
	CRect rtWnd;
	CRect rtTitle;
	GetWindowRect(hWnd,&rtWnd);

	if(m_bUsedDefTitleBar)
	{
		rtTitle.left = rtWnd.left + GetSystemMetrics(SM_CXFRAME);
		rtTitle.top =  rtWnd.top + GetSystemMetrics(SM_CYFRAME);
		rtTitle.right = rtWnd.right - rtWnd.left - GetSystemMetrics(SM_CXFRAME);
		rtTitle.bottom = rtTitle.top + GetSystemMetrics(SM_CYSIZE);

		return TRUE;
	}


	rtTitle.left = GetSystemMetrics(SM_CXFRAME);
	rtTitle.top = GetSystemMetrics(SM_CYFRAME);
	rtTitle.right = rtWnd.right - rtWnd.left - GetSystemMetrics(SM_CXFRAME);
	rtTitle.bottom = rtTitle.top + GetSystemMetrics(SM_CYSIZE);

	CBitmap*  BackBitmap;
	COLORREF TitleTextColor;
	UINT     DrawMode;

	if(bActive)
	{
		BackBitmap = m_TitleBarBitmap[BMP_ACTIVE];
		DrawMode = m_TitleBarBitmapDrawMode[BMP_ACTIVE];
		TitleTextColor = GetSysColor(COLOR_CAPTIONTEXT);
	}
	else
	{
		BackBitmap = m_TitleBarBitmap[BMP_INACTIVE];
		DrawMode = m_TitleBarBitmapDrawMode[BMP_INACTIVE];
		TitleTextColor = GetSysColor(COLOR_INACTIVECAPTIONTEXT);
	}

	if(BackBitmap == NULL)return FALSE;
	
	//��λͼ��������
	CRTDraw::RTDrawBitmap(pDC,&rtTitle,BackBitmap,DrawMode);

	//��������ͼ��
	HICON hIcon =  (HICON)DefWindowProc(hWnd,WM_GETICON,ICON_SMALL,0);
	if(hIcon != NULL)
	{
		DrawIconEx(pDC->m_hDC,rtTitle.left+1,rtTitle.top+1,hIcon,rtTitle.Height() - 2,rtTitle.Height() - 2,0,NULL,DI_NORMAL);
	}

	//������������
	CFont TitleFont;
	NONCLIENTMETRICS nif;
	nif.cbSize = sizeof(nif);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS,sizeof(NONCLIENTMETRICS),&nif,0);
	TitleFont.CreateFontIndirect(&nif.lfCaptionFont);
	CFont *pOldFont = pDC->SelectObject(&TitleFont);

	char bufText[1024];
	int nText = GetWindowText(hWnd,bufText,1024);
	bufText[nText] = NULL;
	CString titleText = bufText; 
	CRect rtTitleText;
	rtTitleText.SetRect(rtTitle.left + rtTitle.Height(),rtTitle.top,rtTitle.right - 60,rtTitle.bottom);
	int oldBkMode = pDC->SetBkMode(TRANSPARENT);
	int oldTextColor = pDC->SetTextColor(TitleTextColor);

	TEXTMETRIC Metrics;
	pDC->GetTextMetrics(&Metrics);
	rtTitleText.top = rtTitle.top + (rtTitle.Height() - Metrics.tmHeight)/2;
	
	pDC->DrawText(titleText,&rtTitleText,DT_LEFT | DT_SINGLELINE);
	pDC->SetBkMode(oldBkMode);
	pDC->SetTextColor(oldTextColor);
	pDC->SelectObject(&pOldFont);

	//����������Ť
	RTDrawTitleBarButtons(pDC,hWnd);
	return TRUE;
}

BOOL CRTWnd::OnRTNcPaint(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	//���Ʒǿͻ���
	HDC hDC = GetWindowDC(hWnd);
	if(hDC != NULL)
	{
		CDC *pDC = CDC::FromHandle(hDC);

		HRGN hrgn = NULL;
		CRect rtWnd;
		GetWindowRect(hWnd,&rtWnd);
		if(wParam != 1)
		{
			//����CLIPBOX
			hrgn = (HRGN)wParam;
			::SelectClipRgn(pDC->m_hDC,hrgn);
			::OffsetClipRgn(pDC->m_hDC,0 - rtWnd.left,0 - rtWnd.top);
			
		}
		else if(wParam == 1)
		{
			hrgn = CreateRectRgn(rtWnd.left,rtWnd.top,rtWnd.right,rtWnd.bottom);
			::SelectClipRgn(pDC->m_hDC,hrgn);
			::OffsetClipRgn(pDC->m_hDC,0 - rtWnd.left,0 - rtWnd.top);
		}
		RTDrawFrameBorder(pDC,hrgn,hWnd);
		RTDrawTitleBar(pDC,hrgn,m_bActive,hWnd);
		RTDrawMenuBar(pDC,hrgn,lParam,hWnd);
		RTDrawDefaultMenu(lParam,hrgn,hWnd,hrgn);
		::SelectClipRgn(pDC->m_hDC,hrgn,NULL);
		DeleteObject(hrgn);

		if(hrgn != NULL)DeleteObject(hrgn);
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
	}
	return TRUE;
}

BOOL CRTWnd::EnableRTStyle(BOOL bEnable)
{
	m_bUseRTStyle = bEnable;
	return bEnable;
}

BOOL CRTWnd::OnRTNcActive(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	return FALSE;
}

BOOL CRTWnd::OnRTActive(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);

	if(!IsWindow(hWnd))return FALSE;
	
	if(wParam == WA_INACTIVE)
	{
		m_bActive = FALSE;
	}
	else
	{
		m_bActive = TRUE;
	}
	LRESULT lResult;
	OnRTNcPaint(hWnd,uMsg,1,0,&lResult);
	return TRUE;
}

BOOL CRTWnd::OnRTNodify(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);
	
	HDC hDC = GetWindowDC(hWnd);
	if(hDC != NULL)
	{
		CDC *pDC = CDC::FromHandle(hDC);
		RTDrawTitleBar(pDC,m_bActive,hWnd);
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
	}
	return TRUE;
}

BOOL CRTWnd::OnRTActiveApp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);
	
	m_bActive = (BOOL)wParam;
	return TRUE;
}

BOOL CRTWnd::OnRTSetText(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);
	
	HDC hDC = GetWindowDC(hWnd);
	if(hDC != NULL)
	{
		CDC *pDC = CDC::FromHandle(hDC);
		RTDrawTitleBar(pDC,m_bActive,hWnd);
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
	}
	return TRUE;
}

BOOL CRTWnd::SetRestoreButtonBitmap(CBitmap* RestoreButtonBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_RestoreButtonBitmap[i] = RestoreButtonBitmap[i];
		m_RestoreButtonBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}
BOOL CRTWnd::SetExitButtonBitmap(CBitmap* ExitButtonBitmap[],UINT DrawMode[])
{
	for(int i = 0; i < 5; i ++)
	{
		m_ExitButtonBitmap[i] = ExitButtonBitmap[i];
		m_ExitButtonBitmapDrawMode[i] = DrawMode[i];
	}
	return TRUE;
}


BOOL CRTWnd::RTDrawTitleBarButtons(CDC* pDC,HRGN hRgn,HWND hWnd)
{	
	//ȡ�ñ�������λ��
	if(m_bUsedDefTitleBar)return TRUE;

	CRect rtWnd;
	CRect rtTitle;
	GetWindowRect(hWnd,&rtWnd);
	rtTitle.left = GetSystemMetrics(SM_CXFRAME);
	rtTitle.top = GetSystemMetrics(SM_CYFRAME);
	rtTitle.right = rtWnd.right - rtWnd.left - GetSystemMetrics(SM_CXFRAME);
	rtTitle.bottom = rtTitle.top + GetSystemMetrics(SM_CYSIZE);
	
	CRect rtButtons;

	//����������Ť
	DWORD dwStyle = GetWindowLong(hWnd,GWL_STYLE);
	
	CBitmap* pCloseBox = NULL;
	CBitmap* pMaximizeBox = NULL;
	CBitmap* pMinimizeBox = NULL;

	if(TRUE)
	{
		if(m_ExitButtonState == StateNormal)
		{
			pCloseBox = m_ExitButtonBitmap[BMP_NORMAL];
		}
		else if(m_ExitButtonState == StateDown)
		{
			pCloseBox = m_ExitButtonBitmap[BMP_DOWN];
		}
		else if(m_ExitButtonState == StateFocus)
		{
			pCloseBox = m_ExitButtonBitmap[BMP_FOCUS];
		}
	}

	if(WS_MAXIMIZEBOX & dwStyle)
	{
		if(IsZoomed(hWnd))
		{
			if(m_MaximizeButtonState == StateNormal)
			{
				pMaximizeBox = m_RestoreButtonBitmap[BMP_NORMAL];
			}
			else if(m_MaximizeButtonState == StateDown)
			{
				pMaximizeBox = m_RestoreButtonBitmap[BMP_DOWN];
			}
			else if(m_MaximizeButtonState == StateFocus)
			{
				pMaximizeBox = m_RestoreButtonBitmap[BMP_FOCUS];
			}
		}
		else
		{
			if(m_MaximizeButtonState == StateNormal)
			{
				pMaximizeBox = m_MaximizeButtonBitmap[BMP_NORMAL];
			}
			else if(m_MaximizeButtonState == StateDown)
			{
				pMaximizeBox = m_MaximizeButtonBitmap[BMP_DOWN];
			}
			else if(m_MaximizeButtonState == StateFocus)
			{
				pMaximizeBox = m_MaximizeButtonBitmap[BMP_FOCUS];
			}
		}
	}
	else if(WS_MINIMIZEBOX & dwStyle)
	{
		if(IsZoomed(hWnd))
		{
			pMaximizeBox = m_RestoreButtonBitmap[BMP_DISABLE];
		}
		else
		{
			pMaximizeBox = m_MaximizeButtonBitmap[BMP_DISABLE];
		}
	}

	if(WS_MINIMIZEBOX & dwStyle)
	{
		if(m_MinimizeButtonState == StateNormal)
		{
			pMinimizeBox = m_MinimizeButtonBitmap[BMP_NORMAL];
		}
		else if(m_MinimizeButtonState == StateDown)
		{
			pMinimizeBox = m_MinimizeButtonBitmap[BMP_DOWN];
		}
		else if(m_MinimizeButtonState == StateFocus)
		{
			pMinimizeBox = m_MinimizeButtonBitmap[BMP_FOCUS];
		}
	}
	else if(WS_MAXIMIZEBOX & dwStyle)
	{
		pMinimizeBox = m_MinimizeButtonBitmap[BMP_DISABLE];
	}

	//�ػ��ر�button
	if(dwStyle & WS_SYSMENU)
	{
		rtButtons.left = rtTitle.right - rtTitle.Height();
		rtButtons.top = rtTitle.top + 2;
		rtButtons.right = rtTitle.right - 2;
		rtButtons.bottom = rtTitle.bottom - 2;
		CRTDraw::RTDrawBitmap(pDC,&rtButtons,pCloseBox,CRTDraw::DrawModeAllStretch);
	}
	//�ػ����/�ָ�button
	if(dwStyle & WS_MAXIMIZEBOX || dwStyle & WS_MINIMIZEBOX)
	{
		rtButtons.right = rtButtons.left - 2;
		rtButtons.left = rtButtons.left - rtTitle.Height();
		CRTDraw::RTDrawBitmap(pDC,&rtButtons,pMaximizeBox,CRTDraw::DrawModeAllStretch);
	}
	//�ػ���С��button
	if(dwStyle & WS_MAXIMIZEBOX || dwStyle & WS_MINIMIZEBOX)
	{
		rtButtons.right = rtButtons.left;
		rtButtons.left = rtButtons.left - rtTitle.Height() + 2;
		CRTDraw::RTDrawBitmap(pDC,&rtButtons,pMinimizeBox,CRTDraw::DrawModeAllStretch);
	}
	return TRUE;
}


BOOL CRTWnd::OnRTSetIcon(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);
	
	if(IsWindow(hWnd))
	{
		HDC hDC = GetWindowDC(hWnd);
		if(hDC != NULL)
		{
			CDC *pDC = CDC::FromHandle(hDC);
			RTDrawTitleBar(pDC,m_bActive,hWnd);
			pDC->Detach();
			ReleaseDC(hWnd,hDC);
		}
	}
	return TRUE;
}

BOOL CRTWnd::OnRTNcMouseMove(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	*pResult = 0;
	
	HDC hDC = GetWindowDC(hWnd);
	if(hDC == NULL)return TRUE;

	CDC* pDC = CDC::FromHandle(hDC);

	switch(wParam)
	{
	case HTMAXBUTTON:
		if(m_NcMouseState == MouseStateNormal)
		{
			if(m_MaximizeButtonState != StateFocus)
			{
				m_MaximizeButtonState = StateFocus;
				m_MinimizeButtonState = StateNormal;
				m_ExitButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		else if(m_NcMouseState == MouseStateDown)
		{
			if(m_SelTitleButton == MaximizeButton)
			{
				if(m_MaximizeButtonState != StateDown)
				{
					m_MaximizeButtonState = StateDown;
					RTDrawTitleBarButtons(pDC,hWnd);
				}
			}
			else if(m_SelTitleButton != NoneButton)
			{
				m_MinimizeButtonState = StateNormal;
				m_ExitButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		break;
	case HTMINBUTTON:
		if(m_NcMouseState == MouseStateNormal)
		{
			if(m_MinimizeButtonState != StateFocus)
			{
				m_MinimizeButtonState = StateFocus;
				m_MaximizeButtonState = StateNormal;
				m_ExitButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		else if(m_NcMouseState == MouseStateDown)
		{
			if(m_SelTitleButton == MinimizeButton)
			{
				if(m_MinimizeButtonState != StateDown)
				{
					m_MinimizeButtonState = StateDown;
					RTDrawTitleBarButtons(pDC,hWnd);
				}
			}
			else if(m_SelTitleButton != NoneButton)
			{
				m_MaximizeButtonState = StateNormal;
				m_ExitButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		break;
	case HTCLOSE:
		if(m_NcMouseState == MouseStateNormal)
		{
			if(m_ExitButtonState != StateFocus)
			{
				m_ExitButtonState = StateFocus;
				m_MaximizeButtonState = StateNormal;
				m_MinimizeButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		else if(m_NcMouseState == MouseStateDown)
		{
			if(m_SelTitleButton == ExitButton)
			{
				if(m_ExitButtonState != StateDown)
				{
					m_ExitButtonState = StateDown;
					RTDrawTitleBarButtons(pDC,hWnd);
				}
			}
			else if(m_SelTitleButton != NoneButton)
			{
				m_MaximizeButtonState = StateNormal;
				m_MinimizeButtonState = StateNormal;
				RTDrawTitleBarButtons(pDC,hWnd);
			}
		}
		break;
	default:
		if(m_ExitButtonState != StateNormal || m_MinimizeButtonState != StateNormal || m_MaximizeButtonState != StateNormal)
		{
			m_MaximizeButtonState = StateNormal;
			m_MinimizeButtonState = StateNormal;
			m_ExitButtonState = StateNormal;
			RTDrawTitleBarButtons(pDC,hWnd);
		}
		break;
	}
	pDC->Detach();
	ReleaseDC(hWnd,hDC);

	return TRUE;
}

BOOL CRTWnd::OnRTNcLMouseDown(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	HDC hDC = GetWindowDC(hWnd);
	if(hDC == NULL)return TRUE;

	CDC *pDC = CDC::FromHandle(hDC);

	switch(wParam)
	{
	case HTMAXBUTTON:
		m_NcMouseState = MouseStateDown;
		m_SelTitleButton = MaximizeButton;
		m_MaximizeButtonState = StateDown;
		RTDrawTitleBarButtons(pDC,hWnd);
		SetCapture(hWnd);
		break;
	case HTMINBUTTON:
		m_NcMouseState = MouseStateDown;
		m_SelTitleButton = MinimizeButton;
		m_MinimizeButtonState = StateDown;
		RTDrawTitleBarButtons(pDC,hWnd);
		SetCapture(hWnd);
		break;
	case HTCLOSE:
		m_NcMouseState = MouseStateDown;
		m_SelTitleButton = ExitButton;
		m_ExitButtonState = StateDown;
		RTDrawTitleBarButtons(pDC,hWnd);
		SetCapture(hWnd);
		break;
	default:
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
		return FALSE;
		break;
	}
	pDC->Detach();
	ReleaseDC(hWnd,hDC);
	return TRUE;
}

BOOL CRTWnd::OnRTNcLMouseUp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	if(m_NcMouseState == MouseStateNormal)
	{
		return FALSE;
	}
	m_NcMouseState = MouseStateNormal;
	ReleaseCapture();

	pResult = 0;
	HDC hDC = GetWindowDC(hWnd);
	CDC* pDC = CDC::FromHandle(hDC);

	if(wParam == HTMAXBUTTON)
	{
		if(m_SelTitleButton == MaximizeButton)
		{
			m_SelTitleButton = NoneButton;
			m_MaximizeButtonState = StateNormal;
			RTDrawTitleBarButtons(pDC,hWnd);
			if(IsZoomed(hWnd))
			{
				SendMessage(hWnd,WM_SYSCOMMAND, SC_RESTORE, lParam);
			}
			else
			{
				SendMessage(hWnd,WM_SYSCOMMAND, SC_MAXIMIZE,lParam);
			}
		}
	}
	else if(wParam == HTMINBUTTON)
	{
		if(m_SelTitleButton == MinimizeButton)
		{
			m_SelTitleButton = NoneButton;
			m_MinimizeButtonState = StateNormal;
			RTDrawTitleBarButtons(pDC,hWnd);
			SendMessage(hWnd,WM_SYSCOMMAND, SC_MINIMIZE,lParam);
		}
	}
	else if(wParam == HTCLOSE)
	{
		if(m_SelTitleButton == ExitButton)
		{
			m_SelTitleButton = NoneButton;
			m_ExitButtonState = StateNormal;
			SendMessage(hWnd,WM_SYSCOMMAND,SC_CLOSE,lParam);
		}
	}
	else
	{
		m_MinimizeButtonState = StateNormal;
		m_MaximizeButtonState = StateNormal;
		m_ExitButtonState = StateNormal;
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
		return FALSE;
	}
	pDC->Detach();
	ReleaseDC(hWnd,hDC);
	return TRUE;
}

BOOL CRTWnd::OnRTMouseMove(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	if(m_NcMouseState != MouseStateNormal)
	{
		CRect rtWnd;
		GetWindowRect(hWnd,&rtWnd);
		CPoint point(lParam);
		ClientToScreen(hWnd,&point);
		UINT hit = (UINT)DefWindowProc(hWnd,WM_NCHITTEST,wParam,MAKELPARAM(point.x,point.y));
		return OnRTNcMouseMove(hWnd,WM_NCMOUSEMOVE,hit,MAKELPARAM(point.x,point.y),pResult);
	}
	return FALSE;
}

BOOL CRTWnd::OnRTLButtonUp(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;
	
	if(m_NcMouseState != MouseStateNormal)
	{
		CRect rtWnd;
		GetWindowRect(hWnd,&rtWnd);
		CPoint point(lParam);
		ClientToScreen(hWnd,&point);
		UINT hit = (UINT)DefWindowProc(hWnd,WM_NCHITTEST,wParam,MAKELPARAM(point.x,point.y));	
		return OnRTNcLMouseUp(hWnd,WM_NCLBUTTONUP,hit,MAKELPARAM(point.x,point.y),pResult);
	}
	return FALSE;
}



BOOL CRTWnd::RTDrawDefaultMenu(LPARAM lParam,HRGN hRgn,HWND hWnd)
{
	HMENU hMenu = GetMenu(hWnd);
	if(hMenu == NULL)return TRUE;
	
	CRect rtMenu;
	CRect rtWnd;
	
	GetWindowRect(hWnd,&rtWnd);
	rtMenu.left = GetSystemMetrics(SM_CXFRAME);
	rtMenu.top = GetSystemMetrics(SM_CYSIZE) + GetSystemMetrics(SM_CXFRAME) + 1;
	rtMenu.right = rtWnd.Width() - GetSystemMetrics(SM_CXFRAME);
	rtMenu.bottom = rtMenu.top +  GetSystemMetrics(SM_CYMENU);

	UINT ItemCount = GetMenuItemCount(hMenu);

	int PrevTop = rtMenu.top;
	int PrevLeft = rtMenu.left;
	int MenuItemHeight = GetSystemMetrics(SM_CYMENU);
	CRect rtMenuItem;
	
	for(UINT items = 0; items < ItemCount; items++)
	{
		
		GetMenuItemRect(hWnd,hMenu,items,&rtMenuItem);
		HRGN rgn = CreateRectRgn(rtMenuItem.left,rtMenuItem.top,rtMenuItem.right,rtMenuItem.bottom);
		if(hRgn != NULL)
		{
			if(NULLREGION != CombineRgn(rgn,rgn,hRgn,RGN_AND))
			{
				DefWindowProc(hWnd,WM_NCPAINT,(WPARAM)(rgn),lParam);
				DeleteObject(rgn);
			}
		}
		
	}
	return TRUE;
}
BOOL CRTWnd::OnRTSetCursor(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	*pResult = DefWindowProc(hWnd,uMsg,wParam,lParam);
	
	UINT uHitTest = LOWORD(lParam);

	HDC hDC = GetWindowDC(hWnd);
	CDC *pDC = CDC::FromHandle(hDC);
	
	switch(uHitTest)
	{
	case HTBORDER:
	case HTLEFT:
	case HTRIGHT:
	case HTTOP:
	case HTBOTTOM:
	case HTBOTTOMLEFT:
	case HTBOTTOMRIGHT:
	case HTTOPLEFT:
	case HTTOPRIGHT:
		RTDrawTitleBar(pDC,m_bActive,hWnd);
		break;
	default:
		break;
	}
	pDC->Detach();
	ReleaseDC(hWnd,hDC);
	return TRUE;
}

BOOL CRTWnd::OnRTSysCommand(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;
	
	HDC hDC = GetWindowDC(hWnd);
	if(hDC != NULL)
	{
		CDC *pDC = CDC::FromHandle(hDC);
		RTDrawTitleBar(pDC,m_bActive,hWnd);
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
	}
	return FALSE;
}


BOOL CRTWnd::OnRTNcHitTest(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	return FALSE;
}

BOOL CRTWnd::OnRTInitMenuPop(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	if(m_bUsedDefTitleBar)return FALSE;

	HDC hDC = GetWindowDC(hWnd);
	if(hDC != NULL)
	{
		CDC *pDC = CDC::FromHandle(hDC);
		RTDrawTitleBar(pDC,m_bActive,hWnd);
		pDC->Detach();
		ReleaseDC(hWnd,hDC);
	}
	return FALSE;
}
BOOL CRTWnd::RTWindowProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam,LRESULT* pResult)
{
	BOOL bPass = FALSE;
	
	if(!m_bUseRTStyle)return bPass;

	switch(uMsg)
	{
	case WM_NCPAINT:
		bPass = OnRTNcPaint(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_NCMOUSEMOVE:
		bPass = OnRTNcMouseMove(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_NCLBUTTONDOWN:
		bPass = OnRTNcLMouseDown(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_NCLBUTTONUP:
		bPass = OnRTNcLMouseUp(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_NCACTIVATE:
		bPass = OnRTNcActive(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_ACTIVATE:
		bPass = OnRTActive(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_ACTIVATEAPP:
		bPass = OnRTActiveApp(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_SYSCOMMAND:
		bPass = OnRTSysCommand(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_INITMENUPOPUP:
		bPass = OnRTInitMenuPop(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_NCHITTEST:
		bPass = OnRTNcHitTest(hWnd,uMsg,wParam,lParam,pResult);
		break;
	case WM_SETCURSOR:
		bPass = OnRTSetCursor(hWnd,uMsg,wParam,lParam,pResult);
		break;
	default:
		break;
	}

	return bPass;
}


