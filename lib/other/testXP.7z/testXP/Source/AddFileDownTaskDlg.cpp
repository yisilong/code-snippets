// AddFileDownTaskDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "AddFileDownTaskDlg.h"


// CAddFileDownTaskDlg

IMPLEMENT_DYNCREATE(CAddFileDownTaskDlg, CRTDialog)

CAddFileDownTaskDlg::CAddFileDownTaskDlg(CWnd* pParent,BOOL IsSave)
	: CRTDialog(CAddFileDownTaskDlg::IDD,pParent)
{
	m_ParentTypeName.Empty();
	m_SavePath.Empty();
	m_FileFilter = "*";
	m_bSave = IsSave;
	m_TypeName = "";
}

CAddFileDownTaskDlg::~CAddFileDownTaskDlg()
{
}

void CAddFileDownTaskDlg::DoDataExchange(CDataExchange* pDX)
{
	CRTDialog::DoDataExchange(pDX);
	DDX_Control(pDX,IDC_S_TypeName,m_s_TypeName);
	DDX_Control(pDX,IDC_S_SavePath,m_s_SavePath);
	DDX_Control(pDX,IDC_S_FileFilter,m_s_FileFilter);
	DDX_Control(pDX,IDC_S_ParentType,m_s_ParentType);

	DDX_Control(pDX,IDC_E_FileFilter,m_e_FileFilter);
	DDX_Control(pDX,IDC_E_SavePath,m_e_SavePath);
	DDX_Control(pDX,IDC_E_TypeName,m_e_TypeName);
	
	DDX_Control(pDX,IDOK,m_b_Add);
	DDX_Control(pDX,IDCANCEL,m_b_Close);
	DDX_Control(pDX,IDC_B_Browser,m_b_Browser);

	DDX_Control(pDX,IDC_S_ParentTypeName,m_s_ParentTypeName);
}

BEGIN_MESSAGE_MAP(CAddFileDownTaskDlg, CRTDialog)
	ON_EN_CHANGE(IDC_E_TypeName, OnEnChangeETypename)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// CAddFileDownTaskDlg ���

#ifdef _DEBUG
void CAddFileDownTaskDlg::AssertValid() const
{
	CRTDialog::AssertValid();
}

void CAddFileDownTaskDlg::Dump(CDumpContext& dc) const
{
	CRTDialog::Dump(dc);
}


#endif //_DEBUG


// CAddFileDownTaskDlg ��Ϣ��������

BOOL CAddFileDownTaskDlg::OnInitDialog()
{
	CRTDialog::OnInitDialog();

	if(!m_ParentTypeName.IsEmpty())m_s_ParentTypeName.SetWindowText(m_ParentTypeName);
	if(!m_SavePath.IsEmpty())m_e_SavePath.SetWindowText(m_SavePath);
	if(!m_FileFilter.IsEmpty())m_e_FileFilter.SetWindowText(m_FileFilter);

	if(m_bSave)
	{
		SetWindowText("����༭");
		m_b_Add.SetWindowText("����");
		m_e_TypeName.SetWindowText(m_TypeName);
	}
	return TRUE; 
}

void CAddFileDownTaskDlg::OnEnChangeETypename()
{
	CString strTypeName;
	m_e_TypeName.GetWindowText(strTypeName);
	strTypeName = strTypeName.Trim();
	if(strTypeName == "")
	{
		m_e_SavePath.SetWindowText(m_SavePath);
	}
	else
	{
		strTypeName = m_SavePath + "\\" + strTypeName;
		m_e_SavePath.SetWindowText(strTypeName);
	}
}

void CAddFileDownTaskDlg::OnBnClickedOk()
{
	m_e_SavePath.GetWindowText(m_SavePath);
	m_e_FileFilter.GetWindowText(m_FileFilter);
	m_e_TypeName.GetWindowText(m_TypeName);

	m_TypeName = m_TypeName.Trim();
	if(m_TypeName == "")return;
	CDialog::OnOK();
}
