#pragma once

#include "RTDialog.h"
#include "rtstatic.h"
#include "RTButton.h"
#include "RTTreeCtrl.h"
#include "RTEdit.h"

// CAddFileDownTaskDlg ������ͼ

class CAddFileDownTaskDlg : public CRTDialog
{
	DECLARE_DYNCREATE(CAddFileDownTaskDlg)

public:
	CAddFileDownTaskDlg(CWnd* pParent = NULL,BOOL IsSave = FALSE);           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CAddFileDownTaskDlg();

public:
	enum { IDD = IDD_AddFileDownTask };
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BOOL   m_bSave;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CRTStatic m_s_TypeName;
	CRTStatic m_s_SavePath;
	CRTStatic m_s_FileFilter;
	CRTStatic m_s_ParentType;
	CString   m_ParentTypeName;
	CString   m_TypeName;
	CString   m_SavePath;
	CString   m_FileFilter;

	CRTEdit   m_e_TypeName;
	CRTEdit   m_e_SavePath;
	CRTEdit   m_e_FileFilter;

	CRTButton m_b_Add;
	CRTButton m_b_Close;
	CRTButton m_b_Browser;

	CRTStatic m_s_ParentTypeName;
	virtual BOOL OnInitDialog();
	afx_msg void OnEnChangeETypename();
	afx_msg void OnBnClickedOk();
};


