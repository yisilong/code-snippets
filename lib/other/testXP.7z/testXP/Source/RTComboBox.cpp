// RTComboBox.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RTComboBox.h"


// CRTComboBox

IMPLEMENT_DYNAMIC(CRTComboBox, CComboBox)
CRTComboBox::CRTComboBox()
{
}

CRTComboBox::~CRTComboBox()
{
}


BEGIN_MESSAGE_MAP(CRTComboBox, CComboBox)
END_MESSAGE_MAP()



// CRTComboBox ��Ϣ��������

