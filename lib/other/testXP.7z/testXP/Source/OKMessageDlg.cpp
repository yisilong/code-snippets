// OKMessageDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "OKMessageDlg.h"


// COKMessageDlg �Ի���

IMPLEMENT_DYNAMIC(COKMessageDlg, CRTDialog)
COKMessageDlg::COKMessageDlg(CWnd* pParent,LPCTSTR lpCaption,LPCTSTR lpMessage)
	: CRTDialog(COKMessageDlg::IDD, pParent)
{
	m_Cpation = lpCaption;
	m_Message = lpMessage;
}

COKMessageDlg::~COKMessageDlg()
{
}

void COKMessageDlg::DoDataExchange(CDataExchange* pDX)
{
	CRTDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_S_MESSAGE, m_s_Message);
	DDX_Control(pDX, IDOK, m_b_OK);
	DDX_Control(pDX, IDCANCEL, m_b_Cancel);
}


BEGIN_MESSAGE_MAP(COKMessageDlg, CRTDialog)
END_MESSAGE_MAP()


// COKMessageDlg ��Ϣ��������

BOOL COKMessageDlg::OnInitDialog()
{
	CRTDialog::OnInitDialog();

	m_s_Message.SetWindowText(m_Message);
	SetWindowText(m_Cpation);

	return TRUE; 
}
