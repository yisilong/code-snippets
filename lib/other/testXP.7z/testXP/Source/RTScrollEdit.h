#pragma once

#include "RTEdit.h"
#include "RTScrollControlContainer.h"
// CRTScrollEdit

class CRTScrollEdit : public CRTEdit
{
	DECLARE_DYNAMIC(CRTScrollEdit)

public:
	CRTScrollControlContainer m_Container;
	CRTScrollEdit();
	virtual ~CRTScrollEdit();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
protected:
	virtual void PreSubclassWindow();
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	void SetScroll(void);
};


