// RTScrollEdit.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RTScrollEdit.h"


// CRTScrollEdit

IMPLEMENT_DYNAMIC(CRTScrollEdit, CRTEdit)
CRTScrollEdit::CRTScrollEdit()
{
}

CRTScrollEdit::~CRTScrollEdit()
{
}


BEGIN_MESSAGE_MAP(CRTScrollEdit, CRTEdit)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
END_MESSAGE_MAP()



// CRTScrollEdit ��Ϣ��������


void CRTScrollEdit::OnPaint()
{
	

	CRTEdit::OnPaint();
}

BOOL CRTScrollEdit::OnEraseBkgnd(CDC* pDC)
{
	return CRTEdit::OnEraseBkgnd(pDC);
}

void CRTScrollEdit::PreSubclassWindow()
{
	m_Container.Create(this);
	CRTEdit::PreSubclassWindow();
}

int CRTScrollEdit::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CRTEdit::OnCreate(lpCreateStruct) == -1)
		return -1;
	m_Container.Create(this);
	return 0;
}

void CRTScrollEdit::SetScroll(void)
{

}
