#pragma once


// CRTListBox

class CRTListBox : public CListBox
{
	DECLARE_DYNAMIC(CRTListBox)

public:
	CRTListBox();
	virtual ~CRTListBox();

protected:
	DECLARE_MESSAGE_MAP()
};


