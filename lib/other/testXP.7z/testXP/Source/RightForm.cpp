// RightForm.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "RightForm.h"
#include "MainFrm.h"

// CRightForm �Ի���

IMPLEMENT_DYNAMIC(CRightForm, CPropertyPage)
CRightForm::CRightForm()
	: CPropertyPage(CRightForm::IDD)
{
}

CRightForm::~CRightForm()
{
}

void CRightForm::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TabRight, m_TabRight);
	DDX_Control(pDX, IDC_ListDownFile, m_ListDwonFile);
	DDX_Control(pDX, IDC_ListWebDown, m_ListWebDown);
	DDX_Control(pDX, IDC_ListWebMgr, m_ListWebMgr);
	DDX_Control(pDX, IDC_ListWebMgrInfo, m_ListWebMgrInfo);
	DDX_Control(pDX, IDC_ListWebDownInfo, m_ListWebDownInfo);
	DDX_Control(pDX, IDC_TreeFileDownInfo, m_TreeFileDownInfo);
}


BEGIN_MESSAGE_MAP(CRightForm, CPropertyPage)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CRightForm ��Ϣ��������

void CRightForm::OnSize(UINT nType, int cx, int cy)
{
	CPropertyPage::OnSize(nType, cx, cy);

	if(IsWindow(m_TabRight.m_hWnd))m_TabRight.MoveWindow(0,0,cx,cy);
}

BOOL CRightForm::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	m_TabRight.ShowTabItem(FALSE);
	m_SplitterFileDown.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),this,ID_SP_FILEDOWN);
	m_SplitterWebDown.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),this,ID_SP_WEBDOWN);
	m_SplitterWebMgr.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),this,ID_SP_WEBMGR);
	m_SplitterFileDownInfo.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),this,ID_SP_FILEDOWNINFO);
	m_FileDownInfo.Create(CFileDownInfo::IDD,&m_SplitterFileDownInfo);

	m_SplitterFileDownInfo.SetVertical(&m_TreeFileDownInfo.m_Container,&m_FileDownInfo,100,-1);
	m_SplitterFileDown.SetHorizoncal(&m_ListDwonFile.m_Container,&m_SplitterFileDownInfo,-1,150);
	m_SplitterWebDown.SetHorizoncal(&m_ListWebDown.m_Container,&m_ListWebDownInfo.m_Container,-1,150);
	m_SplitterWebMgr.SetHorizoncal(&m_ListWebMgr.m_Container,&m_ListWebMgrInfo.m_Container,-1,150);

	m_TabRight.Add(0,"�ļ�����",0,&m_SplitterFileDown);
	m_TabRight.Add(1,"վ������",1,&m_SplitterWebDown);
	m_TabRight.Add(2,"վ�����",2,&m_SplitterWebMgr);

	



	return TRUE; 
}

void CRightForm::SetCurSel(int sel)
{
	m_TabRight.SetCurSel(sel);
}

BOOL CRightForm::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}
