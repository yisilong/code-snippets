// LeftForm.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "LeftForm.h"
#include "MainFrm.h"
#include "RightForm.h"
#include "RTXmlFile.h"
#include "DownInfoType.h"
#include "RTFolder.h"

#include "AddFileDownTaskDlg.h"
#include "OKMessageDlg.h"
// CLeftForm �Ի���

IMPLEMENT_DYNAMIC(CLeftForm, CPropertyPage)
IMPLEMENT_MENUXP(CLeftForm,CPropertyPage)
CLeftForm::CLeftForm()
	: CPropertyPage(CLeftForm::IDD)
{
	m_FileDownSelectIem = NULL;
}

CLeftForm::~CLeftForm()
{
}

void CLeftForm::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TabTaskMgr, m_TabTaskMgr);
	DDX_Control(pDX, IDC_TreeFileDown, m_TreeFileDown);
	DDX_Control(pDX, IDC_TreeWebMgr, m_TreeWebMgr);
	DDX_Control(pDX, IDC_TreeWebDown, m_TreeWebDown);
}


BEGIN_MESSAGE_MAP(CLeftForm, CPropertyPage)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TabTaskMgr, OnTcnSelchangeTabtaskmgr)
	ON_NOTIFY(NM_RCLICK, IDC_TreeFileDown, OnNMRclickTreefiledown)
	ON_NOTIFY(NM_RCLICK, IDC_TreeWebDown, OnNMRclickTreewebdown)
	ON_MENUXP_MESSAGES()
	ON_COMMAND(ID_NewFileDownType, OnNewfiledowntype)
	ON_COMMAND(ID_DeleteFileDownType, OnDeletefiledowntype)
	ON_WM_CLOSE()
	ON_COMMAND(ID_FileDownTypeProperty, OnFiledowntypeproperty)
END_MESSAGE_MAP()


// CLeftForm ��Ϣ��������

void CLeftForm::OnSize(UINT nType, int cx, int cy)
{
	CPropertyPage::OnSize(nType, cx, cy);

	if(IsWindow(m_TabTaskMgr.m_hWnd))m_TabTaskMgr.MoveWindow(0,0,cx,cy);
}

BOOL CLeftForm::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	//Add Tab Items
	m_TabTaskMgr.Add(0,"�ļ�����",0,&m_TreeFileDown.m_Container);
	m_TabTaskMgr.Add(1,"վ������",1,&m_TreeWebDown.m_Container);
	m_TabTaskMgr.Add(2,"վ�����",2,&m_TreeWebMgr.m_Container);

	InitFileDown();
	InitWebDown();
	return TRUE;  
}

BOOL CLeftForm::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CLeftForm::OnTcnSelchangeTabtaskmgr(NMHDR *pNMHDR, LRESULT *pResult)
{
	int sel = TabCtrl_GetCurSel(pNMHDR->hwndFrom);
	m_RightForm->m_TabRight.SetCurSel(sel);
	CWnd *pParent = GetParent();
	pParent->SendMessage(WM_NOTIFY,(WPARAM)IDC_TabTaskMgr,(LPARAM)pNMHDR);
	*pResult = 0;
}

void CLeftForm::InitWebDown(void)
{

	//��ȡ������·��
	char AppPath[MAX_PATH];
	char TypeFile[MAX_PATH];
	ZeroMemory(AppPath,MAX_PATH);
	DWORD nLen = GetModuleFileName(NULL,AppPath,MAX_PATH) - 1;
	while(nLen >= 0)
	{
		
		if(AppPath[nLen] == '\\')
		{
			AppPath[nLen] = NULL;
			break;
		}
		nLen --;
	}
	
	//�ļ����ص����񱣴�·����Ϣ
	HTREEITEM hRoot = m_TreeWebDown.InsertItem("վ������",0,0);
	HTREEITEM hItem = NULL;

	DownTypeInfo* pDTI = new DownTypeInfo;
	ZeroMemory(pDTI->TypePath,MAX_PATH);
	strcpy(pDTI->TypePath,AppPath);
	strcat(pDTI->TypePath,"\\WebDown");
	strcpy(pDTI->SavePath,"C:\\WebDown");
	pDTI->Type = 0;
	pDTI->Layer = 0;
	strcpy(pDTI->FileFilter,"*");

	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,pDTI->TypePath);
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	m_TreeWebDown.SetItemData(hItem,(DWORD_PTR)pDTI);

	//�����е����񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\WebDown");
	strcat(TypeFile,"\\UnComplete");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\WebDown");
	pDTI->Type = TYPE_FILEDOWNING;
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeWebDown.InsertItem("������",1,2,hRoot);
	m_TreeWebDown.SetItemData(hItem,(DWORD_PTR)pDTI);


	//�����ص����񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\WebDown");
	strcat(TypeFile,"\\Completed");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\WebDown");
	pDTI->Type = TYPE_FILEDOWNED | TYPE_EDIT;

	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeWebDown.InsertItem("������",1,2,hRoot);
	m_TreeWebDown.SetItemData(hItem,(DWORD_PTR)pDTI);

	CDownInfoType::LoadTreeTypeInfo(m_TreeWebDown, hItem,TYPE_FILEDOWNED);

	//��ɾ�������񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\WebDown");
	strcat(TypeFile,"\\Recycled");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\WebDown");
	pDTI->Type = TYPE_RECYCLED;
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeWebDown.InsertItem("��ɾ��",3,3,hRoot);
	m_TreeWebDown.SetItemData(hItem,(DWORD_PTR)pDTI);

	CDownInfoType::LoadTreeTypeInfo(m_TreeWebDown,hItem,TYPE_RECYCLED);

	m_TreeWebDown.Expand(hRoot,TVE_EXPAND);	
}

void CLeftForm::InitFileDown(void)
{
	//��ȡ������·��
	char AppPath[MAX_PATH];
	char TypeFile[MAX_PATH];
	ZeroMemory(AppPath,MAX_PATH);
	DWORD nLen = GetModuleFileName(NULL,AppPath,MAX_PATH) - 1;
	while(nLen >= 0)
	{
		
		if(AppPath[nLen] == '\\')
		{
			AppPath[nLen] = NULL;
			break;
		}
		nLen --;
	}
	
	//�ļ����ص����񱣴�·����Ϣ
	HTREEITEM hRoot = m_TreeFileDown.InsertItem("�ļ�����",0,0);
	HTREEITEM hItem = NULL;

	DownTypeInfo* pDTI = new DownTypeInfo;
	ZeroMemory(pDTI->TypePath,MAX_PATH);
	strcpy(pDTI->TypePath,AppPath);
	strcat(pDTI->TypePath,"\\FileDown");
	strcpy(pDTI->SavePath,"C:\\Download");
	pDTI->Type = 0;
	pDTI->Layer = 0;
	strcpy(pDTI->FileFilter,"*");

	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,pDTI->TypePath);
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	m_TreeFileDown.SetItemData(hRoot,(DWORD_PTR)pDTI);

	//�����е����񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\FileDown");
	strcat(TypeFile,"\\UnComplete");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\Download");
	pDTI->Type = TYPE_FILEDOWNING;
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeFileDown.InsertItem("������",1,2,hRoot);
	m_TreeFileDown.SetItemData(hItem,(DWORD_PTR)pDTI);
	m_FileDownUnCompleteItem = hItem;

	//�����ص����񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\FileDown");
	strcat(TypeFile,"\\Completed");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\Download");
	pDTI->Type = TYPE_FILEDOWNED | TYPE_EDIT | TYPE_ADD;
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeFileDown.InsertItem("������",1,2,hRoot);
	m_TreeFileDown.SetItemData(hItem,(DWORD_PTR)pDTI);
	m_FileDownCompleteItem = hItem;
	CDownInfoType::LoadTreeTypeInfo(m_TreeFileDown,hItem);

	//��ɾ�������񱣴�·����Ϣ
	ZeroMemory(TypeFile,MAX_PATH);
	strcpy(TypeFile,AppPath);
	strcat(TypeFile,"\\FileDown");
	strcat(TypeFile,"\\Recycled");
	pDTI = new DownTypeInfo;
	pDTI->Layer = 1;
	strcpy(pDTI->TypePath,TypeFile);
	strcpy(pDTI->FileFilter,"*");
	strcpy(pDTI->SavePath,"C:\\Download");
	pDTI->Type = TYPE_RECYCLED;
	
	CDownInfoType::LoadTypeInfo(TypeFile,pDTI);
	hItem = m_TreeFileDown.InsertItem("��ɾ��",3,3,hRoot);
	m_TreeFileDown.SetItemData(hItem,(DWORD_PTR)pDTI);
	m_FileDownRecycledItem = hItem;

	CDownInfoType::LoadTreeTypeInfo(m_TreeFileDown,hItem,TYPE_RECYCLED);
	m_TreeFileDown.Expand(hRoot,TVE_EXPAND);	
}

void CLeftForm::OnNMRclickTreefiledown(NMHDR *pNMHDR, LRESULT *pResult)
{
	CPoint point;
	GetCursorPos(&point);
	CPoint pt(point);
	m_TreeFileDown.ScreenToClient(&pt);
	HTREEITEM hItem = m_TreeFileDown.HitTest(pt);
	CMenu menu;
	menu.LoadMenu(IDR_MenuFileDown);
	CMenu* PopMenu = menu.GetSubMenu(0);

	m_FileDownSelectIem = hItem;
	if(hItem != NULL)
	{
		DownTypeInfo* pType = (DownTypeInfo *)m_TreeFileDown.GetItemData(hItem);
		if(pType != NULL)
		{
			if((pType->Type & TYPE_ADD) != TYPE_ADD)
			{
				PopMenu->EnableMenuItem(ID_NewFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
			}
			if((pType->Type & TYPE_EDIT) != TYPE_EDIT)
			{
				PopMenu->EnableMenuItem(ID_FileDownTypeProperty,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
			}

			if((pType->Type & TYPE_DELETE) != TYPE_DELETE)
			{
                PopMenu->EnableMenuItem(ID_DeleteFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
				PopMenu->EnableMenuItem(ID_MoveFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
			}
		}
		else
		{

		}
	}
	else
	{
		PopMenu->EnableMenuItem(ID_NewFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
		PopMenu->EnableMenuItem(ID_MoveFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
		PopMenu->EnableMenuItem(ID_DeleteFileDownType,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
		PopMenu->EnableMenuItem(ID_FileDownTypeProperty,MF_DISABLED|MF_BYCOMMAND|MF_GRAYED);
	}

	CRTMenu::SetXPLookNFeel(this,PopMenu->GetSafeHmenu(),TRUE);
	PopMenu->TrackPopupMenu(TPM_TOPALIGN|TPM_LEFTALIGN,point.x,point.y,this);
	
	*pResult = 0;
}

void CLeftForm::OnNMRclickTreewebdown(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
}

void CLeftForm::OnNewfiledowntype()
{
	if(m_FileDownSelectIem == NULL)return;
	DownTypeInfo *pInfo = (DownTypeInfo *)m_TreeFileDown.GetItemData(m_FileDownSelectIem);
	if(pInfo == NULL)return;
	CAddFileDownTaskDlg dlgAdd(this);
	CString strTypeName = m_TreeFileDown.GetItemText(m_FileDownSelectIem);
	dlgAdd.m_ParentTypeName = strTypeName;
	dlgAdd.m_SavePath = pInfo->SavePath;
	if(dlgAdd.DoModal() == IDOK)
	{
		DownTypeInfo* pNewTypeInfo = new DownTypeInfo;
		strcpy(pNewTypeInfo->FileFilter,dlgAdd.m_FileFilter);
		strcpy(pNewTypeInfo->SavePath,dlgAdd.m_SavePath);
		pNewTypeInfo->Layer = pInfo->Layer + 1;
		pNewTypeInfo->Type = TYPE_DELETE | TYPE_EDIT | TYPE_FILEDOWNED | TYPE_ADD;
		
		HTREEITEM hItem = m_TreeFileDown.InsertItem(dlgAdd.m_TypeName,1,2,m_FileDownSelectIem);
		CString TypeFile = pInfo->TypePath;
		TypeFile += "\\";
		TypeFile += dlgAdd.m_TypeName;
		strcpy(pNewTypeInfo->TypePath,TypeFile);
		
		CDownInfoType::LoadTypeInfo(TypeFile,pNewTypeInfo);
		m_TreeFileDown.SetItemData(hItem,(DWORD_PTR)pNewTypeInfo);

		m_TreeFileDown.RedrawWindow();
	}

	m_FileDownSelectIem = NULL;
	m_TreeFileDown.SetFocus();
}

void CLeftForm::OnDeletefiledowntype()
{
	if(m_FileDownSelectIem == NULL)return;

	BOOL bDelete = FALSE;

	UINT type = CDownInfoType::GetDownInfoType(m_TreeFileDown,m_FileDownSelectIem);
	if((type & TYPE_RECYCLED) == TYPE_RECYCLED)bDelete = TRUE;
	SHORT lshit = GetKeyState(VK_LSHIFT);
	SHORT rshit = GetKeyState(VK_RSHIFT);

	//�û�����SHIT������ɾ��
	if(lshit < 0 || rshit < 0)
	{
		bDelete = TRUE;
	}

	if(bDelete)
	{
		MessageBox("���Ҫɾ��Щ���༰�����µ������ļ���?","ȷ��",MB_YESNO);
		CDownInfoType::DeleteTreeTypeInfo(m_TreeFileDown,m_FileDownSelectIem);
	}
	else
	{
		CDownInfoType::MoveTreeTypeInfoTo(m_TreeFileDown,m_FileDownSelectIem,m_FileDownRecycledItem,TYPE_RECYCLED);		
	}

	m_TreeFileDown.SetFocus();
}

void CLeftForm::OnClose()
{
	CDownInfoType::ClearTreeTypeInfoData(m_TreeFileDown);
	CDownInfoType::ClearTreeTypeInfoData(m_TreeWebDown);
	CPropertyPage::OnClose();
}

void CLeftForm::OnFiledowntypeproperty()
{
	if(m_FileDownSelectIem == NULL)return;
	DownTypeInfo *pInfo = (DownTypeInfo *)m_TreeFileDown.GetItemData(m_FileDownSelectIem);
	if(pInfo == NULL)return;
	CAddFileDownTaskDlg dlgSave(this,TRUE);
	CString strTypeName = m_TreeFileDown.GetItemText(m_FileDownSelectIem);
	CString strParentTypeName = m_TreeFileDown.GetItemText( m_TreeFileDown.GetParentItem(m_FileDownSelectIem));
	dlgSave.m_ParentTypeName = strParentTypeName;
	dlgSave.m_SavePath = pInfo->SavePath;
	dlgSave.m_TypeName = strTypeName;

	if(IDOK == dlgSave.DoModal())
	{
		char OldPath[MAX_PATH];
		CDownInfoType::GetTreeTypePath(m_TreeFileDown,m_FileDownSelectIem,OldPath);
		if(CRTFolder::ReName(OldPath,dlgSave.m_TypeName))
		{
			strcpy(pInfo->SavePath,dlgSave.m_SavePath);
			m_TreeFileDown.SetItemText(m_FileDownSelectIem,dlgSave.m_TypeName);
			if(!CDownInfoType::SaveTypeInfo(m_TreeFileDown,m_FileDownSelectIem))
			{
				//Error
			}
		}
	}
}
