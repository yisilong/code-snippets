// FileDownInfo.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WebGet.h"
#include "FileDownInfo.h"


// CFileDownInfo �Ի���

IMPLEMENT_DYNAMIC(CFileDownInfo, CPropertyPage)
CFileDownInfo::CFileDownInfo()
	: CPropertyPage(CFileDownInfo::IDD)
{
}

CFileDownInfo::~CFileDownInfo()
{
}

void CFileDownInfo::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ListFileDownInfo);
}


BEGIN_MESSAGE_MAP(CFileDownInfo, CPropertyPage)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CFileDownInfo ��Ϣ��������

void CFileDownInfo::OnSize(UINT nType, int cx, int cy)
{
	CPropertyPage::OnSize(nType, cx, cy);
	if(IsWindow(m_ListFileDownInfo.m_hWnd))m_ListFileDownInfo.m_Container.MoveWindow(0,0,cx,cy);
}
