// RTListBox.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RTListBox.h"


// CRTListBox

IMPLEMENT_DYNAMIC(CRTListBox, CListBox)
CRTListBox::CRTListBox()
{
}

CRTListBox::~CRTListBox()
{
}


BEGIN_MESSAGE_MAP(CRTListBox, CListBox)
END_MESSAGE_MAP()



// CRTListBox ��Ϣ��������

