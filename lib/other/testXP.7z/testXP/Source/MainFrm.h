// MainFrm.h : CMainFrame ��Ľӿ�
//


#pragma once

#include "RTFrameWnd.h"
#include "RTSkin.h"
#include "RTMenu.h"
#include "RTSplitterWnd.h"
#include "RTToolBar.h"
#include "RTStatusBar.h"
#include "RTXmlFile.h"
#include "LeftForm.h"
#include "RightForm.h"


class CMainFrame : public CRTFrameWnd
{
	
public:
	CMainFrame();
protected: 
	CRTSkin m_Skin;

	DECLARE_DYNAMIC(CMainFrame)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // �ؼ���Ƕ���Ա
	CRTStatusBar  m_wndStatusBar;
	CRTToolBar    m_ToolBarFileDown;
	CRTToolBar    m_ToolBarWebDown;
	CRTToolBar    m_ToolBarWebMgr;
	CRTSplitterWnd m_Splitter;
	CLeftForm m_LeftForm;
	CRightForm m_RightForm;
	CRTXmlFile m_SkinFile;
	HCURSOR m_hVerCursor;
	HCURSOR m_hHorCursor;

	BOOL EnableSkin;
	BOOL EnableSDITitleBar;
	BOOL EnableSDIBorder;
	BOOL EnableDLGTitleBar;
	BOOL EnableDLGBorder;
	BOOL EnableDlgBack;
	BOOL EnableMenuBar;
	char SkinFile[MAX_PATH];

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnTabTaskMgrSelChange(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg LRESULT OnSelectedSkin(WPARAM wParam,LPARAM lParam);
	afx_msg LRESULT OnEnableSkin(WPARAM wParam,LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	//DECLARE_MENUXP()
public:
	void UseSkin(BOOL IsEnable);
	virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);
protected:
	virtual void OnUpdateFrameMenu(HMENU hMenuAlt);
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
public:
	afx_msg void OnShowSelectSkinDlg();
	void LoadSkin(void);
	void SaveSkin(void);
};


