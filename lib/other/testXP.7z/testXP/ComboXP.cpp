// ComboXP.cpp: implementation of the CComboXP class.
//
//////////////////////////////////////////////////////////////////////
/**************�������ñ��������ÿ��������**********************/
//ͷ��
////////////////////////////////////////////////////////////////////////////////////////////////////
// ����Ԥ����
#if _WIN32_WINNT < 0x0400
#define _WIN32_WINNT 0x0400
#endif
// ǿ��ʹ�� C ���Է�ʽ����
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
#include "ComboXP.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// ȫ�ֱ���
extern HHOOK g_hPrevHookXP ;		// ������Ϣ HOOK ���
extern PCLASSXP g_pClassXP ;		// ���ڵ� CLASSXP �ṹָ��
extern COLORREF g_crDialogbkColor;  // ���ڱ�����ɫ
//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
// ������Ͽ�
VOID WINAPI ComboDrawComboBoxXP(PCLASSXP pCxp)
{
	int i;
	RECT Rect;
	MEMDCXP Mdcxp;
	HANDLE hHandle;
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00EFF3F7, 0x00DEE7E7, 0x00DEE3E7, 0x00DEE3E7},
		{0x00DEAEA5, 0x00F7CBBD, 0x00DE8273, 0x00F7C7B5},
		{0x00EFC7B5, 0x00E7AE94, 0x00DEA284, 0x00DEA68C},
		{0x00FFE3D6, 0x00F7CBBD, 0x00F7C3AD, 0x00F7C7B5},

		{0x00F7F7F7, 0x00EFF3F7, 0x00EFF3F7, 0x00EFF3F7},
		{0x00DEC3BD, 0x00DEB6AD, 0x00FFE3DE, 0x00F7E3DE},
		{0x00EFDBCE, 0x00EFCFC6, 0x00E7CFC6, 0x00E7CBBD},
		{0x00FFEFE7, 0x00FFE7DE, 0x00FFE3DE, 0x00F7E3DE},

		{0x00F7F7F7, 0x00E7EFEF, 0x00E7EBEF, 0x00DEE7E7},
		{0x00F78E6B, 0x00F79684, 0x00EF9E8C, 0x00EFDFD6},
		{0x00FFFFFF, 0x00FFE3CE, 0x00FFDFC6, 0x00FFDBBD},
		{0x00FFEBE7, 0x00FFCFBD, 0x00FFCBB5, 0x00F7CBAD}
	};

	// ��ȡ�ڴ�����豸����
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = TRUE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);

	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.top = Rect.left = 0;

	/*if ((GetWindowLong(hWnd, GWL_STYLE) & 0x00000003) == CBS_SIMPLE)
	{
		GetWindow(hWnd, GW_CHILD);
		// ��ԭ���ͷ��ڴ��豸����
		Mdcxp.bTransfer = TRUE;
		ReleaseMemDCXP(&Mdcxp);		
	}*/

	// �������
	hHandle = (HANDLE) CreateSolidBrush(
		(pCxp->dwState & CXPS_DISABLED) ? (GetSysColor(COLOR_BTNFACE) - 0x00202020) : 0x00BD9E7B);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
	DeleteObject((HGDIOBJ) hHandle);

	// �����ڿ�
	InflateRect(&Rect, -1, -1);
//	hHandle = (HANDLE) GetSysColorBrush((pCxp->dwState & CXPS_DISABLED) ? COLOR_BTNFACE : COLOR_WINDOW);
	if (pCxp->dwState & CXPS_DISABLED) 
  	  hHandle = (HANDLE) GetSysColorBrush(g_crDialogbkColor);
	else
	  hHandle = (HANDLE) GetSysColorBrush(COLOR_WINDOW);

	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);

	InflateRect(&Rect, -1, -1);
	Rect.left = Rect.right - GetSystemMetrics(SM_CYVTHUMB);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);

	Rect.left++;
	if (pCxp->dwState & CXPS_DISABLED)
		i = 0;
	else if (pCxp->dwState & CXPS_PRESSED)
		i = 1;
	else if (pCxp->dwState & CXPS_HOTLIGHT)
		i = 2;
	else
		i = 3;

	// �����������
	GradientRectXP(Mdcxp.hMemDC, &Rect, s_crGradientXP[i]);

	// �����������ս�����
	SetPixel(Mdcxp.hMemDC, Rect.left, Rect.top, s_crGradientXP[i + 4][0]);
	SetPixel(Mdcxp.hMemDC, Rect.right - 1, Rect.top, s_crGradientXP[i + 4][1]);
	SetPixel(Mdcxp.hMemDC, Rect.left, Rect.bottom - 1, s_crGradientXP[i + 4][2]);
	SetPixel(Mdcxp.hMemDC, Rect.right - 1, Rect.bottom - 1, s_crGradientXP[i + 4][3]);		

	// ���������ڿ�
	InflateRect(&Rect, -1, -1);
	GradientRectXP(Mdcxp.hMemDC, &Rect, s_crGradientXP[i + 8]);

	// ����������־
	Rect.left += (Rect.right - Rect.left) / 2;
	Rect.top += (Rect.bottom - Rect.top) / 2;
	hHandle = (HANDLE) SelectObject(Mdcxp.hMemDC,
		CreatePen(PS_SOLID, 1, (pCxp->dwState & CXPS_DISABLED) ? 0x00C6CBCE : 0x0084614A));
	MoveToEx(Mdcxp.hMemDC, Rect.left - 4, Rect.top - 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top + 2);
	LineTo(Mdcxp.hMemDC, Rect.left + 5, Rect.top - 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top - 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top + 1);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top - 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top - 3, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top - 4);

	DeleteObject(SelectObject(Mdcxp.hMemDC, (HGDIOBJ) hHandle));

	// ��ԭ���ͷ��ڴ��豸����
	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
}
/****************************************************************/
LRESULT ComboWindowProc(PCLASSXP pCxp, UINT message,WPARAM wParam, LPARAM lParam)
{
	LONG lReturn;
	HWND hWnd = pCxp->hWnd;
	switch (message)
		{
		case WM_PAINT:
		case WM_NCPAINT:
			lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			ComboDrawComboBoxXP(pCxp);
			return lReturn;

		case WM_LBUTTONDOWN:
			pCxp->dwState |= CXPS_PRESSED;
			break;

		case WM_LBUTTONUP:
			pCxp->dwState &= ~CXPS_PRESSED;
			break;
		}
// ����ԭ���Ļص�����
	lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
	switch (message)
	{
	case WM_DESTROY:		// ��������
		DeleteClassXP(hWnd);
	}
	return lReturn;
}


/**************�������ñ��������ÿ��������**********************/
//β��
#ifdef __cplusplus
}
#endif // __cplusplus
/*****************************************************************/


