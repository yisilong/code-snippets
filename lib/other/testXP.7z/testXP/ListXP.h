// ListXP.h: interface for the CListXP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTXP_H__FD67318C_72FC_444F_9CED_9F2F9C7BAFA3__INCLUDED_)
#define AFX_LISTXP_H__FD67318C_72FC_444F_9CED_9F2F9C7BAFA3__INCLUDED_

#include "ClassXP.H"
LRESULT ListWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);

#endif // !defined(AFX_LISTXP_H__FD67318C_72FC_444F_9CED_9F2F9C7BAFA3__INCLUDED_)
