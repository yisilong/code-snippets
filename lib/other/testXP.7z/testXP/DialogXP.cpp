// DialogXP.cpp: implementation of the CDialogXP class.
//
//////////////////////////////////////////////////////////////////////

//#include "stdafx.h"
//#include "test.h"
//#include <winuser.H>

//////////////////////////////////////////////////////////////////////
/**************�������ñ��������ÿ��������**********************/
//ͷ��
////////////////////////////////////////////////////////////////////////////////////////////////////
// ����Ԥ����
#if _WIN32_WINNT < 0x0400
#define _WIN32_WINNT 0x0400
#endif

// ǿ��ʹ�� C ���Է�ʽ����
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "DialogXP.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// ȫ�ֱ���
extern HHOOK g_hPrevHookXP ;		// ������Ϣ HOOK ���
extern PCLASSXP g_pClassXP ;		// ���ڵ� CLASSXP �ṹָ��
extern COLORREF g_crDialogbkColor;  // ���ڱ�����ɫ



///////////////////////////////////////////////////////////
void DlgDrawExitButton(HWND hWnd,HDC hDC, RECT Rect, int iState)
{
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00C1CCD1, 0x00C1CCD1, 0x00EEF1F2, 0xFFEEF1F2},
		{0x00CFF0FF, 0x00CFF0FF, 0x000097E5, 0xFF0097E5},
		{0x00BDCBD6, 0x00C6CFD6, 0x00EFF3F7, 0xFFEFF3F7},
		{0x00FFE7CE, 0x00FFE7CE, 0x00EE8269, 0xFFEE8269},
		{0x00FFFFFF, 0x00FFFFFF, 0x00D6DFE2, 0xFFD6DFE2},
	};
	DWORD dwStyle ;
	int nWidth;
	RECT rc;
	dwStyle = GetWindowLong(hWnd, GWL_STYLE);
	nWidth = Rect.bottom - Rect.top - 8;
	rc.top = Rect.top +4;
	rc.bottom = rc.top + nWidth;
	if(dwStyle & WS_SYSMENU)
	{
		rc.left = Rect.right - (nWidth+ 4);
		rc.right = rc.left + nWidth;
        GradientRectXP(hDC, &rc, s_crGradientXP[iState]);
		MoveToEx(hDC, rc.left + 3, rc.top + 3, NULL);
		LineTo(hDC,   rc.right - 3, rc.bottom - 3);
		MoveToEx(hDC, rc.right - 3, rc.top + 3, NULL);
		LineTo(hDC,   rc.left + 3, rc.bottom - 3);
		RoundRect(hDC, rc.left-2, rc.top -2,
			rc.right +2, rc.bottom +2, 4,4);

	}
}
///////////////////////////////////////////////////////////
void DlgDrawMinButton(HWND hWnd, HDC hDC, RECT Rect, int iState)
{
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00C1CCD1, 0x00C1CCD1, 0x00EEF1F2, 0xFFEEF1F2},
		{0x00CFF0FF, 0x00CFF0FF, 0x000097E5, 0xFF0097E5},
		{0x00BDCBD6, 0x00C6CFD6, 0x00EFF3F7, 0xFFEFF3F7},
		{0x00FFE7CE, 0x00FFE7CE, 0x00EE8269, 0xFFEE8269},
		{0x00FFFFFF, 0x00FFFFFF, 0x00D6DFE2, 0xFFD6DFE2},
	};
	DWORD dwStyle ;
	int nWidth;
	RECT rc;
	dwStyle = GetWindowLong(hWnd, GWL_STYLE);
	nWidth = Rect.bottom - Rect.top - 8;
	rc.top = Rect.top +4;
	rc.bottom = rc.top + nWidth;
	//�ػ���С��button
	if(dwStyle & WS_MAXIMIZEBOX || dwStyle & WS_MINIMIZEBOX)
	{
		rc.left = Rect.right - 3*(nWidth +4) -2;
		rc.right = rc.left + nWidth;
        GradientRectXP(hDC, &rc, s_crGradientXP[iState]);
		MoveToEx(hDC, rc.left + 4, rc.bottom - 4, NULL);
		LineTo(hDC,   rc.right - 4, rc.bottom - 4);
		MoveToEx(hDC, rc.left + 4, rc.bottom - 5, NULL);
		LineTo(hDC,   rc.right -
			4, rc.bottom - 5);
		RoundRect(hDC, rc.left-2, rc.top -2,
			rc.right +2, rc.bottom +2, 4,4);
	}
}
///////////////////////////////////////////////////////////
void DlgDrawMaxButton(HWND hWnd,HDC hDC, RECT Rect, int iState)
{
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00C1CCD1, 0x00C1CCD1, 0x00EEF1F2, 0xFFEEF1F2},
		{0x00CFF0FF, 0x00CFF0FF, 0x000097E5, 0xFF0097E5},
		{0x00BDCBD6, 0x00C6CFD6, 0x00EFF3F7, 0xFFEFF3F7},
		{0x00FFE7CE, 0x00FFE7CE, 0x00EE8269, 0xFFEE8269},
		{0x00FFFFFF, 0x00FFFFFF, 0x00D6DFE2, 0xFFD6DFE2},
	};
	DWORD dwStyle ;
	int nWidth;
	RECT rc;
	dwStyle = GetWindowLong(hWnd, GWL_STYLE);
	nWidth = Rect.bottom - Rect.top - 8;
	rc.top = Rect.top +4;
	rc.bottom = rc.top + nWidth;
	//�ػ����/�ָ�button
	if(dwStyle & WS_MAXIMIZEBOX || dwStyle & WS_MINIMIZEBOX)
	{
		rc.left = Rect.right - 2*(nWidth + 4) - 1;
		rc.right = rc.left + nWidth;
        GradientRectXP(hDC, &rc, s_crGradientXP[iState]);
		MoveToEx(hDC, rc.left + 2, rc.top + 5, NULL);
		LineTo(hDC,   rc.left + 9, rc.top + 5);
		MoveToEx(hDC, rc.left + 5, rc.top + 2, NULL);
		LineTo(hDC,   rc.left + 5, rc.top + 9);
		RoundRect(hDC, rc.left-2, rc.top -2,
			rc.right +2, rc.bottom +2, 4,4);
	}
}
//���˵���ť
BOOL DlgDrawTitleBarButtons(PCLASSXP pCxp, HDC hDC)
{	
	int iExit = 0, iMax = 0, iMin = 0;
	HANDLE hHandle, hOldBrush;
	//ȡ�ñ�������λ��
	RECT Rect, rc;
	GetWindowRect(pCxp->hWnd, &rc);
	Rect.left = GetSystemMetrics(SM_CXDLGFRAME);
	Rect.top = GetSystemMetrics(SM_CYDLGFRAME);
	Rect.right = rc.right - rc.left - GetSystemMetrics(SM_CXDLGFRAME);
	Rect.bottom = Rect.top + GetSystemMetrics(SM_CYCAPTION);
	PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	//����������Ť
	DWORD dwStyle = GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if(pDlg->m_ExitButtonState == StateNormal)
		{
			iExit = 2;
		}
	else if(pDlg->m_ExitButtonState == StateDown)
		{
			iExit = 0;
		}
	else if(pDlg->m_ExitButtonState == StateFocus)
		{
			iExit = 3;
		}
	if(WS_MAXIMIZEBOX & dwStyle) //��󻯰�ť
	{
		if(IsZoomed(pCxp->hWnd))//���
		{
			if(pDlg->m_MaximizeButtonState == StateNormal)
			{
				iMax = 2;
			}
			else if(pDlg->m_MaximizeButtonState == StateDown)
			{
				iMax = 0;
			}
			else if(pDlg->m_MaximizeButtonState == StateFocus)
			{
				iMax = 3;
			}
		}
		else
		{
			if(pDlg->m_MaximizeButtonState == StateNormal)
			{
				iMax = 2;
			}
			else if(pDlg->m_MaximizeButtonState == StateDown)
			{
				iMax = 0;
			}
			else if(pDlg->m_MaximizeButtonState == StateFocus)
			{
				iMax = 3;
			}
		}
	}
	else if(WS_MINIMIZEBOX & dwStyle) //��С����ť
	{
		if(IsZoomed(pCxp->hWnd))//���
		{
			iMin = 4;
		}
		else
		{
			iMax = 4;
		}
	}
	if(WS_MINIMIZEBOX & dwStyle) //��С����ť
	{
		if(pDlg->m_MinimizeButtonState == StateNormal)
		{
			iMin = 2;
		}
		else if(pDlg->m_MinimizeButtonState == StateDown)
		{
			iMin = 0;
		}
		else if(pDlg->m_MinimizeButtonState == StateFocus)
		{
			iMin = 3;
		}
	}
	else if(WS_MAXIMIZEBOX & dwStyle)//��󻯰�ť
	{
		iMin = 4;
	}

	//�ػ��ر�button
    hOldBrush = SelectObject(hDC, GetStockObject(NULL_BRUSH));
    hHandle = (HANDLE) SelectObject(hDC, CreatePen(PS_SOLID, 1, 0x00FFFFFF));

    DlgDrawExitButton(pCxp->hWnd,hDC, Rect, iExit);
    DlgDrawMinButton(pCxp->hWnd,hDC, Rect, iMin);
    DlgDrawMaxButton(pCxp->hWnd,hDC, Rect, iMax);

    SelectObject(hDC, hOldBrush);
	DeleteObject(SelectObject(hDC,hHandle));
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// ���Ƶ�������
LRESULT DlgOnNcPaint(PCLASSXP pCxp, WPARAM wParam)
{

	RECT Rect;
//	MEMDCXP Mdcxp;
	HDC hDC;
	HRGN hRgn = NULL;
	GetWindowRect(pCxp->hWnd, &Rect);
// ��ȡ�ڴ�����豸����
/*	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = FALSE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);
    hDC = Mdcxp.hMemDC;
*/
    hDC = GetWindowDC(pCxp->hWnd);
	if(wParam != 1)
	{
		hRgn = (HRGN)wParam;
	}
	if(hRgn != NULL)
	{
		SelectClipRgn(hDC, hRgn);
		OffsetClipRgn(hDC,0 - Rect.left,0 - Rect.top);
	}
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
/*  if (!pCxp->hRgn)
   {
	 if(!IsZoomed(pCxp->hWnd))
	 {
       pCxp->hRgn = CreateRoundRectRgn(0,0,Rect.right ,Rect.bottom,16,16);
       SetWindowRgn(pCxp->hWnd, pCxp->hRgn,TRUE);	// set window region to make rounded window
	 }
   }
*/
	DlgDrawFrameBorder(pCxp, (WPARAM)hDC, hRgn);
	DlgDrawTitleBar(pCxp, (WPARAM)hDC);


//��� 	
//	Mdcxp.bTransfer = TRUE;
//	ReleaseMemDCXP(&Mdcxp);
	if(hRgn != NULL)
	{
        SelectClipRgn(hDC,NULL);
		DeleteObject(hRgn);
	}
	ReleaseDC(pCxp->hWnd,hDC);
	return FALSE;
}

LRESULT DlgOnNcActive(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	pCxp->dwState |= CXPS_FOCUS;
	hDC = GetWindowDC(pCxp->hWnd);
     DlgDrawTitleBar(pCxp, (WPARAM)hDC);
	ReleaseDC(pCxp->hWnd, hDC);
	return TRUE;

}
LRESULT DlgOnActive(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam)
{
	LRESULT result = CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_ACTIVATE, wParam, lParam);
//	PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData ;

	if(wParam == WA_INACTIVE)
		pCxp->dwState &= ~CXPS_FOCUS;
    else
		pCxp->dwState |= CXPS_FOCUS;
	DlgOnNcPaint(pCxp,1);
	return result;
}
// Dialog ��Ϣ��������
BOOL DlgDrawFrameBorder(PCLASSXP pCxp, WPARAM wParam, HRGN hRgn)
{
	RECT Rect, rc;
	HANDLE hHandle;
	int nWidth, nHeight;
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00FF900B, 0x00FF900B,0x00F7CBAD, 0x00FF350B },
		{0x00D6DFDE, 0x00EFF3F7, 0x00EFF3F7, 0x00FFFFFF},
		{0x00FBFCFC, 0x00FBFCFC, 0x00E6EBEC, 0xFFE6EBEC},
		{0x00FFE7CE, 0x00FFE7CE, 0x00EE8269, 0xFFEE8269},
		{0x00FFFFFF, 0x00FFFFFF, 0x00D6DFE2, 0xFFD6DFE2},

		{0x00DEE3E7, 0x00E7E7E7, 0x00DEE3E7, 0xFFDEE3E7},
		{0x00FBFCFC, 0x00FBFCFC, 0x00E6EBEC, 0xFFE6EBEC},
	};
	HDC hDC = (HDC)wParam;
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
    nWidth = GetSystemMetrics(SM_CXDLGFRAME);
	nHeight =GetSystemMetrics(SM_CYDLGFRAME);
 
   if (!pCxp->hRgn && !IsZoomed(pCxp->hWnd))
   {
     pCxp->hRgn = CreateRoundRectRgn(0,0,Rect.right ,Rect.bottom,16,16);
     SetWindowRgn(pCxp->hWnd, pCxp->hRgn,FALSE);	// set window region to make rounded window
   }

//left border
   hHandle = CreateSolidBrush(0x00FF350B);
   rc = Rect;
   rc.right = Rect.left + nWidth;
   FillRect(hDC, &rc,(HBRUSH) hHandle);
//top
   rc = Rect;
   rc.bottom = Rect.top + nHeight;
   FillRect(hDC, &rc,(HBRUSH) hHandle);
//right border
   rc = Rect;
   rc.left = Rect.right - nWidth;
   FillRect(hDC, &rc,(HBRUSH) hHandle);
//bottom
   rc = Rect;
   rc.top = Rect.bottom - nHeight;
   FillRect(hDC, &rc,(HBRUSH) hHandle);

   DeleteObject(hHandle);
	return TRUE;
}
BOOL DlgDrawTitleBar(PCLASSXP pCxp, WPARAM wParam)
{
	RECT Rect, rc;
	char szTemp[256];
	HANDLE hHandle;
	HDC hDC;
//	MEMDCXP Mdcxp;
 	static COLORREF s_crGradientXP[][4] =
	{
		{0x00FF900B, 0x00FF900B,0x00F7CBAD, 0x00FF350B },
		{0x00FFFFFF, 0x00FFFFFF,0x00FF900B, 0x00FF900B }
	};
// ��ȡ�ڴ�����豸����
//	Mdcxp.hWnd = pCxp->hWnd;
//	Mdcxp.bTransfer = FALSE;
//	Mdcxp.hBitmap = NULL;
//	GetMemDCXP(&Mdcxp);
//    hDC = Mdcxp.hMemDC;
    hDC = (HDC)wParam;
//ȡ�ñ�������λ��
	DWORD style =GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if((style & WS_CAPTION) != WS_CAPTION) return TRUE;
// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
	rc = Rect;
//��������С
	rc.left += GetSystemMetrics(SM_CXDLGFRAME);
	rc.right -= GetSystemMetrics(SM_CYDLGFRAME);
	rc.top += GetSystemMetrics(SM_CYDLGFRAME);
	rc.bottom = rc.top + GetSystemMetrics(SM_CYCAPTION);
//������

    hHandle = CreateSolidBrush(0x00FF350B);
	FillRect(hDC,&rc, (HBRUSH)hHandle);
	DeleteObject(hHandle);
	if (pCxp->dwState & CXPS_FOCUS) 
      GradientRectXP(hDC, &rc, s_crGradientXP[0]);
	else
      GradientRectXP(hDC, &rc, s_crGradientXP[1]);
//��ͼ��
    HICON hIcon = (HICON)SendMessage(pCxp->hWnd,WM_GETICON,ICON_SMALL,0);
	if (hIcon)
	{
		DrawIconEx(hDC,rc.left+6,rc.top+2,hIcon,16,16,0,NULL,DI_NORMAL);
		rc.left += 18;
	}
//������������
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{  		
		SetTextColor(hDC, 0x000000);
  	    SetBkMode(hDC,TRANSPARENT);
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		DrawText(hDC, szTemp, -1, &rc, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
		SelectObject(hDC, (HGDIOBJ) hHandle);
	}
//�����ⰴť
	DlgDrawTitleBarButtons(pCxp,hDC);
//��� 	
//	Mdcxp.bTransfer = TRUE;
//	ReleaseMemDCXP(&Mdcxp);
	return TRUE;
}
LRESULT DlgOnEraseBackGround(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
	RECT Rect;
	HANDLE hHandle; //����ԭ���豸���
	HDC hDC;
	hDC = (HDC)wParam;  //��Ч����ľ��
//�ͻ�����
	GetClientRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
//	Rect.left = Rect.top = 0;

//���ͻ���
	hHandle = CreateSolidBrush(0x00FF350B);
	FillRect(hDC,&Rect,(HBRUSH)hHandle);
	DeleteObject(hHandle);

	hHandle = SelectObject(hDC,CreateSolidBrush(0x00FFFFFF));
	RoundRect(hDC, Rect.left+2, Rect.top+2,
			Rect.right-2 , Rect.bottom-10 , 8,8);
	DeleteObject(SelectObject(hDC, (HGDIOBJ) hHandle));

	return true;
}
LRESULT DlgOnNodify(PCLASSXP pCxp,WPARAM wParam, LPARAM lParam)
{
	LRESULT nRet = CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_NOTIFY, wParam, lParam);
	HDC hDC = GetWindowDC(pCxp->hWnd);
	DlgDrawTitleBar(pCxp, (WPARAM)hDC);
    ReleaseDC(pCxp->hWnd, hDC);

	return nRet;
}
LRESULT DlgOnActiveApp(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam)
{
//	LRESULT result = CDialog::WindowProc(WM_ACTIVATEAPP,wParam,lParam);
	LRESULT result = CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_ACTIVATEAPP, wParam, lParam);
	if (wParam)
      pCxp->dwState |= CXPS_FOCUS;
	else
      pCxp->dwState &= ~CXPS_FOCUS;
	return 0;
}

LRESULT DlgOnSetText(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
	LRESULT nRet =	CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_SETTEXT, wParam, lParam);
	HDC hDC = GetWindowDC(pCxp->hWnd);
	DlgDrawTitleBar(pCxp, (WPARAM)hDC);
    ReleaseDC(pCxp->hWnd, hDC);
	return nRet;
}
LRESULT DlgOnSetIcon(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
	LRESULT nRet =	CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_SETICON, wParam, lParam);
	HDC hDC;
	if(IsWindow(pCxp->hWnd))
	{
	    hDC = GetWindowDC(pCxp->hWnd);
		DlgDrawTitleBar(pCxp, (WPARAM)hDC);
        ReleaseDC(pCxp->hWnd, hDC);
	}
	return nRet;
}
LRESULT OnNcMouseMove(PCLASSXP pCxp ,WPARAM wParam,LPARAM lParam)
{
	LRESULT result = 0;
    HDC hDC;
    hDC = GetWindowDC(pCxp->hWnd);
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	switch(wParam)
	{
	case HTMAXBUTTON:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_MaximizeButtonState != StateFocus)
			{
				pDlg->m_MaximizeButtonState = StateFocus;
				pDlg->m_MinimizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
				//RTDrawTitleBarButtons(&dc);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == MaximizeButton)
			{
				if(pDlg->m_MaximizeButtonState != StateDown)
				{
					pDlg->m_MaximizeButtonState = StateDown;
			    DlgDrawTitleBarButtons(pCxp, hDC);
				   //	RTDrawTitleBarButtons(&dc);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MinimizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
				//RTDrawTitleBarButtons(&dc);
			}
		}
		break;
	case HTMINBUTTON:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_MinimizeButtonState != StateFocus)
			{
				pDlg->m_MinimizeButtonState = StateFocus;
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
				//RTDrawTitleBarButtons(&dc);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == MinimizeButton)
			{
				if(pDlg->m_MinimizeButtonState != StateDown)
				{
					pDlg->m_MinimizeButtonState = StateDown;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//					RTDrawTitleBarButtons(&dc);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//				RTDrawTitleBarButtons(&dc);
			}
		}
		break;
	case HTCLOSE:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_ExitButtonState != StateFocus)
			{
				pDlg->m_ExitButtonState = StateFocus;
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_MinimizeButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//				RTDrawTitleBarButtons(&dc);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == ExitButton)
			{
				if(pDlg->m_ExitButtonState != StateDown)
				{
					pDlg->m_ExitButtonState = StateDown;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//					RTDrawTitleBarButtons(&dc);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_MinimizeButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//				RTDrawTitleBarButtons(&dc);
			}
		}
		break;
	default:
		if(pDlg->m_ExitButtonState != StateNormal ||
			pDlg->m_MinimizeButtonState != StateNormal || 
			pDlg->m_MaximizeButtonState != StateNormal)
		{
			pDlg->m_MaximizeButtonState = StateNormal;
			pDlg->m_MinimizeButtonState = StateNormal;
			pDlg->m_ExitButtonState = StateNormal;
			    DlgDrawTitleBarButtons(pCxp, hDC);
//			RTDrawTitleBarButtons(&dc);
		}
		result = 0;//DefWindowProc(WM_NCMOUSEMOVE,wParam,lParam);
		break;
	}
	ReleaseDC(pCxp->hWnd, hDC);
	return result;
}
LRESULT DlgOnNcLMouseDown(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam)
{
	LRESULT result = 0;
	DWORD dwStyle;
    HDC hDC;
    hDC = GetWindowDC(pCxp->hWnd);
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	switch(wParam)
	{
	case HTMAXBUTTON:
		pDlg->m_NcMouseState = MouseStateDown;
		pDlg->m_SelTitleButton = MaximizeButton;
		pDlg->m_MaximizeButtonState = StateDown;
		//RTDrawTitleBarButtons(&dc);
        DlgDrawTitleBarButtons(pCxp,hDC);
		SetCapture(pCxp->hWnd);
/*		if(!IsZoomed(pCxp->hWnd))
		{
           SelectClipRgn(hDC,NULL);
		   DeleteObject(pCxp->hRgn);
		   pCxp->hRgn = NULL;
		   ShowWindow(pCxp->hWnd,SW_SHOWMAXIMIZED);
           return TRUE;
		}
*/
		break;
	case HTMINBUTTON:
		pDlg->m_NcMouseState = MouseStateDown;
		pDlg->m_SelTitleButton = MinimizeButton;
		pDlg->m_MinimizeButtonState = StateDown;
//		RTDrawTitleBarButtons(&dc);
        DlgDrawTitleBarButtons(pCxp,hDC);
		SetCapture(pCxp->hWnd );
		break;
	case HTCLOSE:
		pDlg->m_NcMouseState = MouseStateDown;
		pDlg->m_SelTitleButton = ExitButton;
		pDlg->m_ExitButtonState = StateDown;
//		RTDrawTitleBarButtons(&dc);
        DlgDrawTitleBarButtons(pCxp,hDC);
		SetCapture(pCxp->hWnd);
		break;
	default: //�ƶ�
//���ձ���������ֹԭ�������ػ�
		dwStyle = GetWindowLong(pCxp->hWnd, GWL_STYLE);
		dwStyle &= ~WS_CAPTION;
        SetWindowLong(pCxp->hWnd, GWL_STYLE, dwStyle);
	    result =DefWindowProc(pCxp->hWnd, 
			       WM_NCLBUTTONDOWN, wParam, lParam);
		dwStyle |= WS_CAPTION;
        SetWindowLong(pCxp->hWnd, GWL_STYLE, dwStyle);
		result = 0;
		break;
	}
    DlgDrawTitleBar(pCxp, (WPARAM)hDC);
    ReleaseDC(pCxp->hWnd, hDC);
	return result;
}
LRESULT DlgOnNcLMouseUp(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam)
{
	LRESULT result = 0;
    HDC hDC;
    hDC = GetWindowDC(pCxp->hWnd);
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;

	if(pDlg->m_NcMouseState == MouseStateNormal)
	{
		//return CDialog::WindowProc(WM_NCLBUTTONUP,wParam,lParam);
	    return CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
			       WM_NCLBUTTONUP, wParam, lParam);
	}
	pDlg->m_NcMouseState = MouseStateNormal;
	ReleaseCapture();
	//ReleaseCapture(pCxp->hWnd);

	if(wParam == HTMAXBUTTON)
	{
		if(pDlg->m_SelTitleButton == MaximizeButton)
		{
			pDlg->m_SelTitleButton = NoneButton;
			pDlg->m_MaximizeButtonState = StateNormal;
//			RTDrawTitleBarButtons(&dc);
            DlgDrawTitleBarButtons(pCxp,hDC);
			if(IsZoomed(pCxp->hWnd))
			{
				SendMessage(pCxp->hWnd,WM_SYSCOMMAND, SC_RESTORE, lParam);
			}
			else
			{
				SendMessage(pCxp->hWnd,WM_SYSCOMMAND, SC_MAXIMIZE,lParam);
			}
		}
	}
	else if(wParam == HTMINBUTTON)
	{
		if(pDlg->m_SelTitleButton == MinimizeButton)
		{
			pDlg->m_SelTitleButton = NoneButton;
			pDlg->m_MinimizeButtonState = StateNormal;
//			RTDrawTitleBarButtons(&dc);
            DlgDrawTitleBarButtons(pCxp,hDC);
			SendMessage(pCxp->hWnd,WM_SYSCOMMAND, SC_MINIMIZE,lParam);
		}
	}
	else if(wParam == HTCLOSE)
	{
		if(pDlg->m_SelTitleButton == ExitButton)
		{
			pDlg->m_SelTitleButton = NoneButton;
			pDlg->m_ExitButtonState = StateNormal;
//			RTDrawTitleBarButtons(&dc);
            DlgDrawTitleBarButtons(pCxp,hDC);
			SendMessage(pCxp->hWnd,WM_CLOSE,0,0);
		}
	}
	else
	{
		pDlg->m_MinimizeButtonState = StateNormal;
		pDlg->m_MaximizeButtonState = StateNormal;
		pDlg->m_ExitButtonState = StateNormal;
		//result = CDialog::WindowProc(WM_NCLBUTTONUP,wParam,lParam);
	    result = CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
			       WM_NCLBUTTONUP, wParam, lParam);
	}
    ReleaseDC(pCxp->hWnd, hDC);
	return result;

}
LRESULT DlgOnLButtonUp(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
    UINT hit;
	RECT rtWnd;
	POINT point;
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	if(pDlg->m_NcMouseState != MouseStateNormal)
	{
		GetWindowRect(pCxp->hWnd,&rtWnd);
        point.x = LOWORD(lParam);
        point.y = HIWORD(lParam);
		ClientToScreen(pCxp->hWnd,&point);
		//UINT hit = (UINT)CDialog::WindowProc(WM_NCHITTEST,wParam,MAKELPARAM(point.x,point.y));	
	    hit = (UINT)CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
			                      WM_NCHITTEST,wParam,
					              MAKELPARAM(point.x,point.y));
		return DlgOnNcLMouseUp(pCxp, hit,MAKELPARAM(point.x,point.y));
	}

//	return CDialog::WindowProc(WM_LBUTTONUP,wParam,lParam);
	return	CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
		                   WM_LBUTTONUP,wParam,lParam);
}
LRESULT DlgOnMouseMove(PCLASSXP pCxp,WPARAM wParam, LPARAM lParam)
{
    UINT hit;
	RECT rtWnd;
	POINT point;
	HDC hDC;
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	if(pDlg->m_NcMouseState != MouseStateNormal)
	{
		GetWindowRect(pCxp->hWnd,&rtWnd);
        point.x = LOWORD(lParam);
        point.y = HIWORD(lParam);
		ClientToScreen(pCxp->hWnd,&point);
//		hit = (UINT)CDialog::WindowProc(WM_NCHITTEST,wParam,MAKELPARAM(point.x,point.y));
	    hit = (UINT)CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
			                      WM_NCHITTEST,wParam,
					              MAKELPARAM(point.x,point.y));
		return DlgOnNcMouseMove(pCxp,hit,MAKELPARAM(point.x,point.y));
	}
	else
	{
		if(pDlg->m_ExitButtonState != StateNormal || 
		   pDlg->m_MinimizeButtonState != StateNormal || 
		   pDlg->m_MaximizeButtonState != StateNormal)
		{
            hDC = GetWindowDC(pCxp->hWnd);
			pDlg->m_MaximizeButtonState = StateNormal;
			pDlg->m_MinimizeButtonState = StateNormal;
			pDlg->m_ExitButtonState = StateNormal;
//			RTDrawTitleBarButtons(&dc);
            DlgDrawTitleBarButtons(pCxp,hDC);
            ReleaseDC(pCxp->hWnd, hDC);
		}
	}

//	return CDialog::WindowProc(WM_MOUSEMOVE,wParam,lParam);
	return	CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
		                   WM_MOUSEMOVE,wParam,lParam);
}


LRESULT DlgOnNcMouseMove(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam)
{
	LRESULT result = 0;
    HDC hDC;
    hDC = GetWindowDC(pCxp->hWnd);
    PDIALOGXP pDlg = (PDIALOGXP)pCxp->pData;
	switch(wParam)
	{
	case HTMAXBUTTON:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_MaximizeButtonState != StateFocus)
			{
				pDlg->m_MaximizeButtonState = StateFocus;
				pDlg->m_MinimizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
				//RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == MaximizeButton)
			{
				if(pDlg->m_MaximizeButtonState != StateDown)
				{
					pDlg->m_MaximizeButtonState = StateDown;
//			RTDrawTitleBarButtons(&dc);
                    DlgDrawTitleBarButtons(pCxp,hDC);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MinimizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
//				RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		break;
	case HTMINBUTTON:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_MinimizeButtonState != StateFocus)
			{
				pDlg->m_MinimizeButtonState = StateFocus;
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
//				RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == MinimizeButton)
			{
				if(pDlg->m_MinimizeButtonState != StateDown)
				{
					pDlg->m_MinimizeButtonState = StateDown;
//					RTDrawTitleBarButtons(&dc);
    				DlgDrawTitleBarButtons(pCxp,hDC);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_ExitButtonState = StateNormal;
//				RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		break;
	case HTCLOSE:
		if(pDlg->m_NcMouseState == MouseStateNormal)
		{
			if(pDlg->m_ExitButtonState != StateFocus)
			{
				pDlg->m_ExitButtonState = StateFocus;
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_MinimizeButtonState = StateNormal;
//				RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		else if(pDlg->m_NcMouseState == MouseStateDown)
		{
			if(pDlg->m_SelTitleButton == ExitButton)
			{
				if(pDlg->m_ExitButtonState != StateDown)
				{
					pDlg->m_ExitButtonState = StateDown;
//					RTDrawTitleBarButtons(&dc);
     				DlgDrawTitleBarButtons(pCxp,hDC);
				}
			}
			else if(pDlg->m_SelTitleButton != NoneButton)
			{
				pDlg->m_MaximizeButtonState = StateNormal;
				pDlg->m_MinimizeButtonState = StateNormal;
//				RTDrawTitleBarButtons(&dc);
				DlgDrawTitleBarButtons(pCxp,hDC);
			}
		}
		break;
	default:
		if(pDlg->m_ExitButtonState != StateNormal ||
		   pDlg->m_MinimizeButtonState != StateNormal || 
		   pDlg->m_MaximizeButtonState != StateNormal)
		{
			pDlg->m_MaximizeButtonState = StateNormal;
			pDlg->m_MinimizeButtonState = StateNormal;
			pDlg->m_ExitButtonState = StateNormal;
//			RTDrawTitleBarButtons(&dc);
			DlgDrawTitleBarButtons(pCxp,hDC);
		}
		result = 0;//DefWindowProc(WM_NCMOUSEMOVE,wParam,lParam);
		break;
	}
    ReleaseDC(pCxp->hWnd, hDC);
	return result;
}
LRESULT DlgOnNcRButtonUp(PCLASSXP pCxp,WPARAM wParam,LPARAM lParam)
{
	HDC hDC = GetWindowDC(pCxp->hWnd);
	DlgDrawTitleBar(pCxp, (WPARAM)hDC);
	ReleaseDC(pCxp->hWnd, hDC);
	return CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_NCRBUTTONUP, wParam, lParam);
}
LRESULT DlgOnNcRButtonDown(PCLASSXP pCxp,WPARAM wParam,LPARAM lParam)
{
	return 0;
}
LRESULT DlgOnSysCommand(PCLASSXP pCxp,WPARAM wParam,LPARAM lParam)
{
//	HDC hDC = GetWindowDC(pCxp->hWnd);
//	DlgDrawTitleBar(pCxp, (WPARAM)hDC);
//	ReleaseDC(pCxp->hWnd, hDC);
	return CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_SYSCOMMAND, wParam, lParam);
}

LRESULT DlgOnSetCursor(PCLASSXP pCxp,WPARAM wParam,LPARAM lParam)
{
	LRESULT rt = CallWindowProc(pCxp->wpPrev, pCxp->hWnd, 
		                     WM_SETCURSOR,wParam, lParam);
	UINT nHitTest = LOWORD(lParam);
		switch(nHitTest)
		{
		case HTBORDER:
		case HTLEFT:
		case HTRIGHT:
		case HTTOP:
		case HTBOTTOM:
		case HTBOTTOMLEFT:
		case HTBOTTOMRIGHT:
		case HTTOPLEFT:
		case HTTOPRIGHT:
	          //hDC = GetWindowDC(pCxp->hWnd);
	          //DlgDrawTitleBar(pCxp, (WPARAM)hDC);
	          //ReleaseDC(pCxp->hWnd, hDC);
	          //break;
			return 0;
		default:
			break;
		}
	return rt;
}

LRESULT DlgOnSize(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
  RECT Rect;
  UINT nWidth = GetSystemMetrics(SM_CXDLGFRAME);
  UINT nHeight =GetSystemMetrics(SM_CYDLGFRAME);
  GetWindowRect(pCxp->hWnd, &Rect);
  Rect.right -= Rect.left;
  Rect.bottom -= Rect.top;
  Rect.left = Rect.top = 0;

  if (wParam == SIZE_MAXHIDE)
      return FALSE;
  if (IsZoomed(pCxp->hWnd))
  {
       //SelectClipRgn(GetWindowDC(pCxp->hWnd),NULL);
       SetWindowRgn(pCxp->hWnd, NULL,TRUE);	// set window region to make rounded window
	   DeleteObject((HGDIOBJ)pCxp->hRgn);
	   pCxp->hRgn = NULL;
 }
  else if(wParam == SIZE_RESTORED)
  {
	GetWindowRect(pCxp->hWnd, &Rect);
// �ػ�����
  RedrawWindow(pCxp->hWnd, NULL, NULL,
				 RDW_UPDATENOW|RDW_ERASE | RDW_FRAME | RDW_INVALIDATE | RDW_ERASENOW);

//  MoveWindow(pCxp->hWnd, Rect.top,Rect.left,	Rect.right,	Rect.bottom, TRUE);
  return TRUE;
/*	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
	//nWidth += LOWORD(lParam);  // width of client area 
    //nHeight += HIWORD(lParam); // height of client area 
	nWidth = Rect.right;
	nHeight = Rect.bottom;
    if(pCxp->hRgn)
	   DeleteObject((HGDIOBJ)pCxp->hRgn);
    pCxp->hRgn = CreateRoundRectRgn(0,0,nWidth,nHeight,16,16);
    SetWindowRgn(pCxp->hWnd,pCxp->hRgn,TRUE);	// set window region to make rounded window
*/
  }
// �ػ�����
  RedrawWindow(pCxp->hWnd, NULL, NULL,
				 RDW_UPDATENOW|RDW_ERASE | RDW_FRAME | RDW_INVALIDATE | RDW_ERASENOW);

//  MoveWindow(pCxp->hWnd, 0,0,	Rect.right,	Rect.bottom, TRUE);
  return TRUE;
}





LRESULT DlgWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_SIZE:
//		return 0;
		return DlgOnSize(pCxp, wParam, lParam);
	case WM_INITMENUPOPUP: //
		return 0;
	case WM_NCPAINT:  //1
		return DlgOnNcPaint(pCxp, wParam);
	case WM_NCACTIVATE: //2
		return DlgOnNcActive(pCxp,wParam,lParam);
	case WM_ACTIVATE: //3
		return DlgOnActive(pCxp, wParam,lParam);
	case WM_ACTIVATEAPP: //4
		return DlgOnActiveApp(pCxp,wParam,lParam);
	case WM_NOTIFY: //5
		return DlgOnNodify(pCxp, wParam,lParam);
	case WM_SETTEXT: //6
		return DlgOnSetText(pCxp, wParam,lParam);
	case WM_SETICON: //7
 		return DlgOnSetIcon(pCxp, wParam,lParam);
	case WM_NCMOUSEMOVE: //8
		return DlgOnNcMouseMove(pCxp, wParam,lParam);
	case WM_NCLBUTTONDOWN: //9
		return DlgOnNcLMouseDown(pCxp, wParam,lParam);
	case WM_NCLBUTTONUP: //10
		 DlgOnNcLMouseUp(pCxp, wParam,lParam);
	case WM_LBUTTONUP: //11
		return DlgOnLButtonUp(pCxp, wParam,lParam);
	case WM_MOUSEMOVE: //12
		return DlgOnMouseMove(pCxp, wParam,lParam);
    case WM_ERASEBKGND: //13
		return DlgOnEraseBackGround(pCxp, wParam,lParam);
	case WM_NCRBUTTONUP: //14
		return DlgOnNcRButtonUp(pCxp, wParam,lParam);
	case WM_NCRBUTTONDOWN: //15
		return DlgOnNcRButtonDown(pCxp,wParam,lParam);
	case WM_SYSCOMMAND: //16
		return DlgOnSysCommand(pCxp, wParam,lParam);
	case WM_SETCURSOR: //17
		return DlgOnSetCursor(pCxp, wParam,lParam);
	default:
		break;
	}

	// ����ԭ���Ļص�����
	return  CallWindowProc(pCxp->wpPrev, pCxp->hWnd, message, wParam, lParam);
//	return  DefWindowProc(pCxp->hWnd, message, wParam, lParam);
}
////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif // __cplusplus
////////////////////////////////////////////////////////////////////////////////////////////////////
