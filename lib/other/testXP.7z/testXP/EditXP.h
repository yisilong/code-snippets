// EditXP.h: interface for the EditXP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITXP_H__47D5569B_3270_490D_981B_9DC39C8BB493__INCLUDED_)
#define AFX_EDITXP_H__47D5569B_3270_490D_981B_9DC39C8BB493__INCLUDED_

#include "ClassXP.H"
LRESULT EditWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);

#endif // !defined(AFX_EDITXP_H__47D5569B_3270_490D_981B_9DC39C8BB493__INCLUDED_)
