// ButtonXP.cpp: implementation of the CButtonXP class.
//
//////////////////////////////////////////////////////////////////////
/**************�������ñ��������ÿ��������**********************/
//ͷ��
////////////////////////////////////////////////////////////////////////////////////////////////////
// ����Ԥ����
#if _WIN32_WINNT < 0x0400
#define _WIN32_WINNT 0x0400
#endif
// ǿ��ʹ�� C ���Է�ʽ����
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
#include "ButtonXP.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// ȫ�ֱ���
extern HHOOK g_hPrevHookXP ;		// ������Ϣ HOOK ���
extern PCLASSXP g_pClassXP ;		// ���ڵ� CLASSXP �ṹָ��
extern COLORREF g_crDialogbkColor;  // ���ڱ�����ɫ
//////////////////////////////////////////////////////////////
/****************************************************************/
//��ť����ת���ı�����
UINT ButtonStyle2Format(DWORD style)
{
	UINT uFormat = 0;

	if((style & BS_MULTILINE) != BS_MULTILINE)
		uFormat |= DT_SINGLELINE;
	if((style & BS_TOP) == BS_TOP)
		uFormat |= DT_TOP;
	else if((style & BS_BOTTOM) == BS_BOTTOM)
		uFormat |= DT_BOTTOM;
	else
		uFormat |= DT_VCENTER | DT_SINGLELINE;
	if((style & BS_LEFT) == BS_LEFT)
		uFormat |= DT_LEFT;
	else if((style & BS_RIGHT) == BS_RIGHT)
		uFormat |= DT_RIGHT;
	else
		uFormat |= DT_CENTER;
	uFormat |= DT_END_ELLIPSIS;
	return uFormat;
}
/////////////////////////////////////////////////////////////
//����ͼ��
LRESULT ButtonOnSetIcon(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam)
{
//���ɻҶȽ�ֹͼ��
	if (pCxp->hIconDisabled) DeleteObject(pCxp->hIconDisabled);
	pCxp->hIconDisabled =(HICON)CopyImage((HICON)lParam, IMAGE_ICON, 0,0,LR_MONOCHROME|LR_COPYRETURNORG);
//����ʹ��ͼ��
	LRESULT nRet =	CallWindowProc(pCxp->wpPrev, pCxp->hWnd, WM_SETICON, wParam, lParam);
//	if(IsWindow(pCxp->hWnd)) // �ػ�����
//	  RedrawWindow(pCxp->hWnd, NULL, NULL,RDW_UPDATENOW|RDW_ERASE | RDW_FRAME | RDW_INVALIDATE | RDW_ERASENOW);
	return nRet;
}



////////////////////////////////////////////////
//���ư�ť2
VOID WINAPI ButtonDrawPushButtonXP(PCLASSXP pCxp)
{
    RECT Rect, rc; 
	MEMDCXP Mdcxp;
	HBRUSH hBrush;
	HANDLE hHandle;
//	COLORREF crColor;
//	char szTemp[256];
//	HICON hIcon;
    DWORD dwStyle;
//	UINT uFormat;
    DWORD pID = NULL;
///	HANDLE hInst;
//    ICONINFO piconinfo;
	HPEN pen1, pen2, pen3, pen4;
//	COLORREF bkColor;
	int nSaveDC;
	TRIVERTEX vert[2] ;
	GRADIENT_RECT gRect;
//    HDC hDC;
	COLORREF bkColorStart = RGB( 220, 214, 194 );
	COLORREF bkColorEnd = RGB( 245, 244, 235 );
	COLORREF FaceColorStart = RGB( 255, 255, 255 );
	COLORREF FaceColorEnd = RGB( 226, 223, 214 );
	COLORREF TextColorStart = RGB( 252, 252, 251 );
	COLORREF TextColorEnd = RGB( 236, 235, 230 );
	// ��ȡ�ڴ�����豸����
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = FALSE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
    rc = Rect;
    pen1 = CreatePen( PS_SOLID, 0, RGB(226, 222, 203) );   // ����ߵ�һ������
	pen2 = CreatePen( PS_SOLID, 0, RGB(248, 247, 242) );	// ��ײ���һ������
	nSaveDC = SaveDC(Mdcxp.hMemDC);
	dwStyle = (DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if (pCxp->dwState & CXPS_DISABLED)
		{
			pen3= CreatePen( PS_SOLID, 0, RGB(216, 213, 199) );	// Բ�Ǿ���(4,4)
			pen4= CreatePen( PS_SOLID, 0, RGB(201, 199, 186) );		// Բ�Ǿ���(6,6)
		}
		else
		{
			pen3 = CreatePen( PS_SOLID, 0, RGB(122, 149, 168) );	// Բ�Ǿ���(4,4)
			pen4 = CreatePen( PS_SOLID, 0, RGB(0, 60, 116) );		// Բ�Ǿ���(6,6)
		}

//	bkColor = GetPixel(GetDC(pCxp->hWnd), rc.right-1, rc.top );
//	nSaveDC = SaveDC(Mdcxp.hMemDC);
//����ɫ���
	hBrush = CreateSolidBrush(g_crDialogbkColor);
	SelectObject(Mdcxp.hMemDC, hBrush);
	FillRect(Mdcxp.hMemDC, &rc, (HBRUSH)hBrush);
	DeleteObject(hBrush);
//�յı���ɫ
	SelectObject(Mdcxp.hMemDC, GetStockObject(NULL_BRUSH));


	// ������ߵ�һ�����ߺ���ײ���һ������
	if (!(pCxp->dwState & CXPS_DISABLED))
		{
			SelectObject(Mdcxp.hMemDC , pen1);
			MoveToEx(Mdcxp.hMemDC, rc.left, rc.top+1,NULL);
			LineTo(Mdcxp.hMemDC, rc.left, rc.bottom-1 );

			SelectObject(Mdcxp.hMemDC, pen2 );
			MoveToEx(Mdcxp.hMemDC, rc.left+2, rc.bottom-1, NULL);
			LineTo(Mdcxp.hMemDC, rc.right-1, rc.bottom-1 );
		}
	// ����ײ㱳��

		vert [0].y = Rect.top;
		vert [0].x = Rect.left+1;
		vert [0].Red    = ((COLOR16)GetRValue( bkColorStart )) << 8;
		vert [0].Green  = ((COLOR16)GetGValue( bkColorStart ))<< 8;
		vert [0].Blue   = ((COLOR16)GetBValue( bkColorStart )) << 8;
		vert [0].Alpha  = 0x0000;

		vert [1].y = Rect.bottom-1;
		vert [1].x = Rect.right;
		vert [1].Red    = ((COLOR16)GetRValue( bkColorEnd )) << 8;
		vert [1].Green  = ((COLOR16)GetGValue( bkColorEnd )) << 8;
		vert [1].Blue   = ((COLOR16)GetBValue( bkColorEnd )) << 8;
		vert [1].Alpha  = 0xFF00;

		gRect.UpperLeft  = 0;
		gRect.LowerRight = 1;
	   if (!(pCxp->dwState & CXPS_DISABLED))
			GradientFill(Mdcxp.hMemDC , vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V );

		// ����н���
		if ((pCxp->dwState & CXPS_FOCUS)|| (pCxp->dwState & CXPS_DEFAULT))
		{
			FaceColorStart = RGB(235, 160, 5 );
			FaceColorEnd = RGB( 251, 192, 73 );
//�����
			if(dwStyle & BS_FLAT)
			{
			TextColorStart = RGB( 251, 192, 73 );
			TextColorEnd = RGB(235, 160, 5 );
			}
			Rect = rc;
			Rect.left += 2;

		}
		// ����Ǹ���
		if (pCxp->dwState & CXPS_HOTLIGHT)
		{
            FaceColorStart = RGB( 255, 240, 207 );
			FaceColorEnd = RGB( 229, 151, 0 );
			Rect = rc;
			Rect.left += 2;
		}

		// ���������
		if (pCxp->dwState & CXPS_PRESSED)
		{
            FaceColorStart = RGB( 209, 204, 193 );
			FaceColorEnd = RGB( 242, 241, 238 );

			TextColorStart = RGB( 229, 228, 221 );
			TextColorEnd = RGB( 226, 226, 218 );

			Rect = rc;
			Rect.left += 2;
		}

		// �������ֹ
		if (pCxp->dwState & CXPS_DISABLED)
		{
            FaceColorStart = RGB( 245, 244, 234 );
			FaceColorEnd = FaceColorStart;

			TextColorStart = FaceColorStart;
			TextColorEnd = FaceColorStart;

			Rect = rc;
			Rect.left += 2;
		}

		// �� BUTTON �ڲ��������򱳾�
		vert [0].y = rc.top + 2;
		vert [0].x = rc.left + 2;
		vert [0].Red    = ((COLOR16)GetRValue( FaceColorStart )) << 8;
		vert [0].Green  = ((COLOR16) GetGValue( FaceColorStart)) << 8;
		vert [0].Blue   = ((COLOR16) GetBValue( FaceColorStart)) << 8;

		vert [1].y = rc.bottom - 2 ;
		vert [1].x = rc.right - 2;
		vert [1].Red    = ((COLOR16) GetRValue( FaceColorEnd ))  << 8;
		vert [1].Green  = ((COLOR16) GetGValue( FaceColorEnd ))  << 8;
		vert [1].Blue   = ((COLOR16) GetBValue( FaceColorEnd ))  << 8;
		GradientFill(Mdcxp.hMemDC , vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V );

		// �� BUTTON �ڲ���Ч���򱳾�
		vert [0].y = Rect.top + 4;
		vert [0].x = Rect.left + 2;
		vert [0].Red    = ((COLOR16) GetRValue( TextColorStart )) << 8;
		vert [0].Green  = ((COLOR16) GetGValue( TextColorStart )) << 8;
		vert [0].Blue   = ((COLOR16) GetBValue( TextColorStart )) << 8;

		vert [1].y = Rect.bottom - 4;
		vert [1].x = Rect.right - 4;
		vert [1].Red    = ((COLOR16) GetRValue( TextColorEnd )) << 8 ;
		vert [1].Green  = ((COLOR16) GetGValue( TextColorEnd )) << 8 ;
		vert [1].Blue   = ((COLOR16) GetBValue( TextColorEnd )) << 8 ;
		GradientFill(Mdcxp.hMemDC , vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V );
		
		// ����н���
       if (pCxp->dwState & CXPS_FOCUS)
		{	
			Rect = rc;
		    InflateRect(&Rect, -3, -3);
		    DrawFocusRect(Mdcxp.hMemDC, &Rect);
		}
		
		// ����Բ�����
		Rect = rc;
	    InflateRect(&Rect, -1, -1);
		//Rect.DeflateRect( 1, 1 );
		hHandle = SelectObject(Mdcxp.hMemDC, pen3);
		RoundRect(Mdcxp.hMemDC, Rect.left, Rect.top ,
			Rect.right , Rect.bottom , 4,4 );
		hHandle = SelectObject(Mdcxp.hMemDC, pen4);
		RoundRect(Mdcxp.hMemDC, Rect.left, Rect.top ,
			Rect.right , Rect.bottom , 6,6);

	// ȥ�����ϽǵĶ����
    SetPixel(Mdcxp.hMemDC, rc.right-1, rc.top, g_crDialogbkColor);
/*
	dwStyle = (DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE);
//������ͼ��
   if (pCxp->dwState & CXPS_DISABLED)
	   hIcon =  pCxp->hIconDisabled;
   else
	   hIcon =(HICON) SendMessage(pCxp->hWnd, WM_GETICON, ICON_SMALL, 0);
   rcText = rc;
   if (hIcon)//��ͼ��
   {
	    GetIconInfo(hIcon,&piconinfo); //ȡͼ����Ϣ
		rcIcon = rc;
        if (dwStyle & BS_TOP) //�����ö�
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = rc.bottom - piconinfo.yHotspot*2 - 4;
			rcText.bottom -= piconinfo.yHotspot*2 ;
		}
        else if (dwStyle & BS_VCENTER)//��������
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = (rc.bottom-rc.top)/2-piconinfo.yHotspot;
			//rcText.top += piconinfo.yHotspot*2 ;
		}
        else //if(dwStyle & BS_BOTTOM)//�����õ�
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = rc.top+4;
			rcText.top += piconinfo.yHotspot*2 + 4;
		}
       if (dwStyle & BS_RIGHT) //��������
		{
			rcIcon.left = 4;
			//rcIcon.top = Rect.top+2;
			rcText.left += piconinfo.yHotspot*2 + 2;
		}
	   else if(dwStyle & BS_LEFT)//��������
		{
			rcIcon.left = rc.right - (piconinfo.yHotspot*2 + 4);
			//rcIcon.top = Rect.top+2;
			rcText.right -= (piconinfo.yHotspot*2 + 2);
		}
	   else
	   {
			rcIcon.left = (rc.right - rc.left)/2-piconinfo.yHotspot + 2;
			//rcIcon.top = Rect.top+2;
			//rcText.right -= (piconinfo.yHotspot*2 + 2);
	   }
		DrawIcon(Mdcxp.hMemDC, rcIcon.left,rcIcon.top, hIcon);
   }
// ������
   uFormat = ButtonStyle2Format(dwStyle);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		if (pCxp->dwState & CXPS_PRESSED)
			OffsetRect(&Rect, 1, 1);
		SetTextColor(hDC,
			((pCxp->dwState & CXPS_INDETERMINATE) || (pCxp->dwState & CXPS_DISABLED)) ?
			0x0094A2A5: 0x00000000);
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		//DrawText(Mdcxp.hMemDC, szTemp, -1, &Rect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		DrawText(hDC, szTemp, -1, &rcText, uFormat);
		SelectObject(hDC, (HGDIOBJ) hHandle);
	}
*/
    ButtonDrawPushText(pCxp,Mdcxp.hMemDC,rc);



	RestoreDC(Mdcxp.hMemDC, nSaveDC );
	DeleteObject(pen1);
	DeleteObject(pen2);
	DeleteObject(pen3);
	DeleteObject(pen4);
	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
} // End of OnDrawBackground


////////////////////////////////////////////////////////////////////////////////////////////////////
// ���ư�ť�ı�
VOID WINAPI ButtonDrawPushText(PCLASSXP pCxp, HDC hDC, RECT rc)
{
	RECT rcIcon, rcText;
	HANDLE hHandle;
	char szTemp[256];
	HICON hIcon;
    DWORD dwStyle;//, pID = NULL;
    ICONINFO piconinfo;
	UINT uFormat;
	dwStyle = (DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE);
//������ͼ��
   if (pCxp->dwState & CXPS_DISABLED)
	   hIcon =  pCxp->hIconDisabled;
   else
	   hIcon =(HICON) SendMessage(pCxp->hWnd, WM_GETICON, ICON_SMALL, 0);
   rcText = rc;
   if (hIcon)//��ͼ��
   {
	    GetIconInfo(hIcon,&piconinfo); //ȡͼ����Ϣ
		rcIcon = rc;
        if (dwStyle & BS_TOP) //�����ö�
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = rc.bottom - piconinfo.yHotspot*2 - 4;
			rcText.bottom -= piconinfo.yHotspot*2 ;
		}
        else if (dwStyle & BS_VCENTER)//��������
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = (rc.bottom-rc.top)/2-piconinfo.yHotspot;
			//rcText.top += piconinfo.yHotspot*2 ;
		}
        else //if(dwStyle & BS_BOTTOM)//�����õ�
		{
			//rcIcon.left = rc.left + (rc.right - rc.left)/2 - piconinfo.xHotspot;
			rcIcon.top = rc.top+4;
			rcText.top += piconinfo.yHotspot*2 + 4;
		}
       if (dwStyle & BS_RIGHT) //��������
		{
			rcIcon.left = 4;
			//rcIcon.top = Rect.top+2;
			rcText.left += piconinfo.yHotspot*2 + 2;
		}
	   else if(dwStyle & BS_LEFT)//��������
		{
			rcIcon.left = rc.right - (piconinfo.yHotspot*2 + 4);
			//rcIcon.top = Rect.top+2;
			rcText.right -= (piconinfo.yHotspot*2 + 2);
		}
	   else
	   {
			rcIcon.left = (rc.right - rc.left)/2-piconinfo.yHotspot + 2;
			//rcIcon.top = Rect.top+2;
			//rcText.right -= (piconinfo.yHotspot*2 + 2);
	   }
		DrawIcon(hDC, rcIcon.left,rcIcon.top, hIcon);
   }
// ������
   uFormat = ButtonStyle2Format(dwStyle);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		if (pCxp->dwState & CXPS_PRESSED)
			OffsetRect(&rcText, 1, 1);
		SetTextColor(hDC,
			((pCxp->dwState & CXPS_INDETERMINATE) || (pCxp->dwState & CXPS_DISABLED)) ?
			0x0094A2A5: 0x00000000);
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		//DrawText(Mdcxp.hMemDC, szTemp, -1, &Rect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		DrawText(hDC, szTemp, -1, &rcText, uFormat);
		SelectObject(hDC, (HGDIOBJ) hHandle);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// ���ư�ť1
/*
VOID WINAPI ButtonDrawPushButtonXP(PCLASSXP pCxp)
{
	int i;
	RECT Rect, rc;
	MEMDCXP Mdcxp;
	HANDLE hHandle;
	COLORREF crColor;
	HDC hDC;
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00C1CCD1, 0x00C1CCD1, 0x00EEF1F2, 0xFFEEF1F2},
		{0x00CFF0FF, 0x00CFF0FF, 0x000097E5, 0xFF0097E5},
		{0x00BDCBD6, 0x00C6CFD6, 0x00EFF3F7, 0xFFEFF3F7},
		{0x00FFE7CE, 0x00FFE7CE, 0x00EE8269, 0xFFEE8269},
		{0x00FFFFFF, 0x00FFFFFF, 0x00D6DFE2, 0xFFD6DFE2},

		{0x00DEE3E7, 0x00E7E7E7, 0x00DEE3E7, 0xFFDEE3E7},
		{0x00FBFCFC, 0x00FBFCFC, 0x00E6EBEC, 0xFFE6EBEC},
	};

	// ��ȡ�ڴ�����豸����
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = FALSE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);
    hDC = Mdcxp.hMemDC;
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
	rc = Rect;
	// ��������Ŀ���ɫ��ϵͳ��ť��ɫһֱ
	hHandle = (HANDLE) CreateSolidBrush(g_crDialogbkColor);
	FrameRect(hDC, &Rect, (HBRUSH) hHandle);
	DeleteObject((HGDIOBJ) hHandle);

	// ����ڶ���߿�
	InflateRect(&Rect, -1, -1);
	hHandle = (HANDLE) CreateSolidBrush(
		(pCxp->dwState & CXPS_DISABLED) ? (g_crDialogbkColor - 0x00202020) : 0x00733C00);
	FrameRect(hDC, &Rect, (HBRUSH) hHandle);
	DeleteObject((HGDIOBJ) hHandle);

	// ���ȵ�򽥱䱳��
	InflateRect(&Rect, -1, -1);
	if (pCxp->dwState & CXPS_DISABLED)
	{
		i = -1;
		//hHandle = (HANDLE) CreateSolidBrush(0x00EAF4F5);
		hHandle = (HANDLE) CreateSolidBrush(g_crDialogbkColor);
		FillRect(hDC, &Rect, (HBRUSH) hHandle);
		DeleteObject((HGDIOBJ) hHandle);
	}
	else
	{
		if (pCxp->dwState & CXPS_PRESSED)
			i = 0;
		else if (pCxp->dwState & CXPS_HOTLIGHT)
			i = 1;
		else if ((pCxp->dwState & CXPS_CHECKED) || (pCxp->dwState & CXPS_INDETERMINATE))
			i = 2;
		else if ((pCxp->dwState & CXPS_FOCUS) || (pCxp->dwState & CXPS_DEFAULT))
			i = 3;
		else
			i = 4;
		GradientRectXP(hDC, &Rect, s_crGradientXP[i]);
	}

	// ���������򽥱䱳��
	InflateRect(&Rect, -2, -2);
	if ((pCxp->dwState & CXPS_PRESSED) ||
		(pCxp->dwState & CXPS_CHECKED) ||
		(pCxp->dwState & CXPS_INDETERMINATE))
		i = 5;
	else if (!(pCxp->dwState & CXPS_DISABLED))
		i = 6;
	if ((i == 5) || (i == 6))
		GradientRectXP(hDC, &Rect, s_crGradientXP[i]);


	// ����ϵͳ��ťһֱ����ɫ�ڶ���߿���Ľ�����
//	crColor = GetSysColor(COLOR_BTNFACE);
	crColor = g_crDialogbkColor;
	SetPixel(hDC, 1, 1, crColor);
	SetPixel(hDC, 1, Rect.bottom + 2, crColor);
	SetPixel(hDC, Rect.right + 2, Rect.bottom + 2, crColor);
	SetPixel(hDC, Rect.right + 2, 1, crColor);

	// ���ڶ���߿�Ĺս����أ�̫�����ˣ�ǧ�����ϸ������
//	crColor = (pCxp->dwState & CXPS_DISABLED) ?
//		(GetSysColor(COLOR_BTNFACE) - 0x00151515) : 0x00A57D52;
	crColor = (pCxp->dwState & CXPS_DISABLED) ?
		(g_crDialogbkColor - 0x00151515) : g_crDialogbkColor-0x00A57D52;

	SetPixel(hDC, 2, 2, crColor);
	SetPixel(hDC, 2, Rect.bottom + 1, crColor);
	SetPixel(hDC, Rect.right + 1, Rect.bottom + 1, crColor);
	SetPixel(hDC, Rect.right + 1, 2, crColor);
//	crColor = (pCxp->dwState & CXPS_DISABLED) ?
//		(GetSysColor(COLOR_BTNFACE) - 0x00111111) : 0x00AD967B;
	crColor = (pCxp->dwState & CXPS_DISABLED) ?
		(g_crDialogbkColor - 0x00111111) : g_crDialogbkColor-0x00AD967B;
	SetPixel(hDC, 1, 2, crColor);
	SetPixel(hDC, 2, 1, crColor);
	SetPixel(hDC, Rect.right + 1, 1, crColor);
	SetPixel(hDC, Rect.right + 2, 2, crColor);
	SetPixel(hDC, Rect.right + 1, Rect.bottom + 2, crColor);
	SetPixel(hDC, Rect.right + 2, Rect.bottom + 1, crColor);
	SetPixel(hDC, 2, Rect.bottom + 2, crColor);
	SetPixel(hDC, 1, Rect.bottom + 1, crColor);

	// ����н��㣬���������
	if (pCxp->dwState & CXPS_FOCUS)
	{
		InflateRect(&Rect, 1, 1);
		DrawFocusRect(hDC, &Rect);
	}

    ButtonDrawPushText(pCxp,hDC,rc);


	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////
// ���Ƹ�ѡ��
VOID WINAPI ButtonDrawCheckBoxXP(PCLASSXP pCxp)
{
	int i;
	RECT Rect, rcText;
	MEMDCXP Mdcxp;
	HANDLE hHandle;
	char szTemp[256];
	COLORREF crColor;
	DWORD dwStyle;
	HDC hDC;
//	UINT uFormat;
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00A5B2B5, 0x00CED7D6, 0x00CED7D6, 0x00DEEFF7},
		{0x00CEF3FF, 0x0063CBFF, 0x0063CBFF, 0x0031B2FF},
		{0x00D6DFDE, 0x00EFF3F7, 0x00EFF3F7, 0x00FFFFFF}
	};

	// ��ȡ�ڴ�����豸����
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = FALSE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);
    hDC = Mdcxp.hMemDC;
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;

	// ��䱳��
//	FillRect(Mdcxp.hMemDC, &Rect, GetSysColorBrush(COLOR_BTNFACE));
	FillRect(hDC, &Rect, GetSysColorBrush(g_crDialogbkColor));
//����ʾģʽ����
	dwStyle = GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if (dwStyle & BS_LEFTTEXT)
	{	
		rcText = Rect;
		rcText.right -= 18;
	    Rect.left = Rect.right - 13;
	    Rect.top = (Rect.bottom - 13) / 2;
	    Rect.bottom = Rect.top + 13;
	}
	else
	{
		rcText = Rect;
		rcText.left += 18;
	    Rect.left = 0;
	    Rect.right = 13;
	    Rect.top = (Rect.bottom - 13) / 2;
	    Rect.bottom = Rect.top + 13;
	}

	// ��������Ŀ�
	hHandle = (HANDLE) CreateSolidBrush(
		(pCxp->dwState & CXPS_DISABLED) ? (GetSysColor(COLOR_BTNFACE) - 0x00202020) : 0x00845118);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
	DeleteObject((HGDIOBJ) hHandle);

	// ���ȵ�򽥱䱳��
	InflateRect(&Rect, -1, -1);
	if (pCxp->dwState & CXPS_DISABLED)
		FillRect(hDC, &Rect, (HBRUSH)GetStockObject(WHITE_BRUSH));
	else
	{
		if (pCxp->dwState & CXPS_PRESSED)
			i = 0;
		else if (pCxp->dwState & CXPS_HOTLIGHT)
			i = 1;
		else
			i = 2;
		GradientRectXP(hDC, &Rect, s_crGradientXP[i]);
	}

	// ���ڿ�
	InflateRect(&Rect, -2, -2);
	if ((pCxp->dwState & CXPS_INDETERMINATE) ||
		((pCxp->dwState & CXPS_HOTLIGHT) && (!(pCxp->dwState & CXPS_PRESSED))))
	{
		if (pCxp->dwState & CXPS_INDETERMINATE)
		{
			if (pCxp->dwState & CXPS_DISABLED)
				crColor = 0x00BDCBCE;
			else if (pCxp->dwState & CXPS_PRESSED)
				crColor = 0x00188A18;
			else if (pCxp->dwState & CXPS_HOTLIGHT)
				crColor = 0x0021A221;
			else
				crColor = 0x0073C373;
		}
		else if (pCxp->dwState & CXPS_CHECKED)
			crColor = 0x00F7F7F7;
		else
			crColor = 0x00E7E7E7;

		hHandle = (HANDLE) CreateSolidBrush(crColor);
		FillRect(hDC, &Rect, (HBRUSH) hHandle);
		DeleteObject((HGDIOBJ) hHandle);
	}


	// ������ѡ�б�־
	if (pCxp->dwState & CXPS_CHECKED)
	{
		hHandle = (HANDLE) SelectObject(hDC,
			CreatePen(PS_SOLID, 1, (pCxp->dwState & CXPS_DISABLED) ? 0x000BDCBCE : 0x0021A221));
		for (i = 3; i < 10; i++)
		{
			MoveToEx(hDC, Rect.left+i-3, Rect.top + ((i < 6) ? i - 1 : (9 - i)), NULL);
			LineTo(hDC, Rect.left+i-3, Rect.top + ((i < 6) ? i + 2 : (12 - i)));
		}
		DeleteObject(SelectObject(hDC,(HGDIOBJ) hHandle));

  }

	// ������
//   uFormat = ButtonStyle2Format(dwStyle);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		SetTextColor(hDC, GetSysColor((pCxp->dwState & CXPS_DISABLED) ?  COLOR_GRAYTEXT: COLOR_BTNTEXT));
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));

		//Rect.left = 18;
		//Rect.top -= 2;
		rcText.bottom = rcText.top + 1 + DrawText(hDC, szTemp, -1, &rcText,
			DT_CALCRECT | DT_SINGLELINE | DT_VCENTER);
        
		DrawText(hDC, szTemp, -1, &rcText, DT_SINGLELINE | DT_VCENTER);
//		DrawText(Mdcxp.hMemDC, szTemp, -1, &rcText, uFormat);
		SelectObject(hDC, (HGDIOBJ) hHandle);

		// ����н��㣬���������
		if (pCxp->dwState & CXPS_FOCUS)
		{
			InflateRect(&rcText, 0, -1);
			DrawFocusRect(hDC, &rcText);
		}
	}
	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
}
////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////
// ���Ƶ�ѡ��
VOID WINAPI ButtonDrawRadioBoxXP(PCLASSXP pCxp)
{
	RECT Rect,rc, rcText;
	MEMDCXP Mdcxp;
	HANDLE hHandle, hPen;
	char szTemp[256];
	COLORREF crColor;
	DWORD dwStyle;
    UINT uFormat;
	HDC hDC;
    static COLORREF s_crGradientXP[][4] =
	{
		{0x00A5B2B5, 0x00CED7D6, 0x00CED7D6, 0x00DEEFF7},
		{0x00CEF3FF, 0x0063CBFF, 0x0063CBFF, 0x0031B2FF},
		{0x00D6DFDE, 0x00EFF3F7, 0x00EFF3F7, 0x00FFFFFF},
		{0x0021A221, 0x0021A221, 0x00187A18, 0x00187A18},
		{0x00FFEBE7, 0x00F7CBAD, 0x00FF350B, 0x00F7CBAD},
	};


	// ��ȡ�ڴ�����豸����
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = FALSE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);
    hDC = Mdcxp.hMemDC;
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
// ��䱳��
//	FillRect(Mdcxp.hMemDC, &Rect, GetSysColorBrush(COLOR_BTNFACE));
	FillRect(hDC, &Rect, GetSysColorBrush(g_crDialogbkColor));

//����ʾģʽ����
	dwStyle = GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if (dwStyle & BS_LEFTTEXT)
	{	
		rcText = Rect;
		rcText.right -= 15;
	    Rect.left = Rect.right-15; 
		Rect.top = (Rect.bottom -15)/2;
		Rect.bottom = Rect.top  + 15;
		rc = Rect;
	}
	else
	{
		rcText = Rect;
		rcText.left += 15;
	    Rect.right = 15; 
		Rect.top = (Rect.bottom -15)/2;
		Rect.bottom = Rect.top  + 15;
	    rc = Rect;
	}
 	// ���ȵ�򽥱䱳��
	if (pCxp->dwState & CXPS_DISABLED)
		FillRect(hDC, &rc,(HBRUSH)GetStockObject(WHITE_BRUSH));
	else
	{
		if (pCxp->dwState & CXPS_PRESSED)
		  GradientRectXP(hDC, &rc, s_crGradientXP[0]);
		else if (pCxp->dwState & CXPS_HOTLIGHT)
		  GradientRectXP(hDC, &rc, s_crGradientXP[1]);
	}

	// ���ڿ�
	InflateRect(&rc, -2, -2);
	if ((pCxp->dwState & CXPS_INDETERMINATE) ||
		((pCxp->dwState & CXPS_HOTLIGHT) && (!(pCxp->dwState & CXPS_PRESSED))))
	{
		if (pCxp->dwState & CXPS_INDETERMINATE)
		{
			if (pCxp->dwState & CXPS_DISABLED)
				crColor = 0x00BDCBCE;
			else if (pCxp->dwState & CXPS_PRESSED)
				crColor = 0x00188A18;
			else if (pCxp->dwState & CXPS_HOTLIGHT)
				crColor = 0x0021A221;
			else
				crColor = 0x0073C373;
		}
		else if (pCxp->dwState & CXPS_CHECKED)
			crColor = 0x00F7F7F7;
		else
			crColor = 0x00E7E7E7;

		hHandle = (HANDLE) CreateSolidBrush(crColor);
		FillRect(hDC, &rc, (HBRUSH) hHandle);
		DeleteObject((HGDIOBJ) hHandle);
	}

//�յı���ɫ
	hHandle = SelectObject(hDC, GetStockObject(NULL_BRUSH));
	// ������ѡ�б�־
	if (pCxp->dwState & CXPS_CHECKED)
	{
	  GradientRectXP(hDC, &rc, s_crGradientXP[3]);
	  hPen = SelectObject(hDC, CreatePen(PS_SOLID, 1, g_crDialogbkColor));
	  Ellipse(hDC, Rect.left+3, Rect.top+3,Rect.left+12,Rect.top+12);
	  Ellipse(hDC, Rect.left+4, Rect.top+4,Rect.left+11,Rect.top+11);
	  DeleteObject(SelectObject(hDC,hPen));
	}
//���Բ�α���ɫ
	if (!(pCxp->dwState & CXPS_HOTLIGHT))
	{
	  hPen = SelectObject(hDC,CreatePen(PS_SOLID, 3, g_crDialogbkColor));
	  Ellipse(hDC, Rect.left, Rect.top,Rect.left+14,Rect.top+14);
	  DeleteObject(SelectObject(hDC,hPen)); 
	}

//��Բ
	hPen = SelectObject(hDC, CreatePen(PS_SOLID, 1, (pCxp->dwState & CXPS_DISABLED) ? (GetSysColor(COLOR_BTNFACE) - 0x00202020) : 0x00845118));
    Ellipse(hDC, Rect.left+2, Rect.top+2,Rect.left+13,Rect.top+13);
    DeleteObject(SelectObject(hDC,hPen));
//�ָ�����ɫ
	SelectObject(hDC, hHandle);

// ������
    uFormat = ButtonStyle2Format(dwStyle);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		SetTextColor(hDC, GetSysColor((pCxp->dwState & CXPS_DISABLED) ?  COLOR_GRAYTEXT: COLOR_BTNTEXT));
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		DrawText(hDC, szTemp, -1, &rcText, uFormat);
		SelectObject(hDC, (HGDIOBJ) hHandle);
		// ����н��㣬���������
		if (pCxp->dwState & CXPS_FOCUS)
		{
			InflateRect(&rcText, -1, -1);
			DrawFocusRect(hDC, &rcText);
		}
	}
	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
}

////////////////////////////////////////////////
//������Ͽ�
VOID WINAPI ButtonDrawGroupBoxXP(PCLASSXP pCxp)
{
	RECT Rect;
	char szTemp[256];
	HANDLE hHandle,hBrush;
    DWORD dwStyle;
//    int nSaveDC;
	HDC hDC = GetWindowDC(pCxp->hWnd);
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
	// ��������Ŀ���ɫ��ϵͳ��ť��ɫһֱ
//�յı���ɫ
	hBrush = SelectObject(hDC, GetStockObject(NULL_BRUSH));
//	hHandle = SelectObject(hDC, CreateSolidBrush(RGB(0,0,0)));
//	hHandle = (HANDLE) CreateSolidBrush(RGB(0,0,0));
	RoundRect(hDC, Rect.left,Rect.top+6,Rect.right,Rect.bottom,
		      6,6);
	SelectObject(hDC, hBrush);

//	CPaintDC dc(this); // device context for painting

//	CRect groupClient;
//	CRect textRect;
//	CFont *poldFont;
//	CPen pen(PS_SOLID, m_LineWidth, m_Color[COLOR_LINECOLOR]);
/*
	poldFont=dc.SelectObject(this->GetFont());
	CPen *pOldPen=dc.SelectObject(&pen);
	GetClientRect(&groupClient);
	groupClient.DeflateRect(m_LineWidth/2,m_LineWidth/2,m_LineWidth/2,m_LineWidth/2);

	BOOL bDrawText=!m_Title.IsEmpty();

	if(bDrawText)
	{
		//��ȡҪ������ַ����Ŀ����(����)
		CSize  textSize;
		textSize=dc.GetOutputTextExtent(m_Title);
		
		//�趨�ַ�������ķ�Χ
		//�߶ȴ����ַ��߶�4,���ȴ�10
		textRect.top = groupClient.top;
		textRect.left = groupClient.left+5;
		textRect.bottom = textRect.top+textSize.cy+4+4; 
		if( (textSize.cx+8) > groupClient.Width())
			textRect.right = groupClient.right;
		else textRect.right = textRect.left+textSize.cx+10 ;

		//�õ�group�Ŀ������
		groupClient.top = groupClient.top + textRect.Height()/2;// �ϱ߿��Ӧ�ַ����в�
	}
	
	//������
	CBrush brush, *poldBrush;
	LOGBRUSH lbr;
	if ( this->m_bGroundColorNULL )
	{
		lbr.lbStyle=BS_NULL;
		brush.CreateBrushIndirect(&lbr);
	}
	else
	{
		lbr.lbStyle=BS_SOLID;
		lbr.lbColor=m_Color[COLOR_GROUND];
		lbr.lbHatch=HS_HORIZONTAL;
		brush.CreateBrushIndirect(&lbr);
	}
	poldBrush=dc.SelectObject(&brush);

// �������
//	dc.Rectangle(&groupClient);
// ����Բ�����
	dc.RoundRect(&groupClient, CPoint(12, 12) );
	if ( bDrawText )
	{
		//���ַ�Ҫд��Բ�ؿ�
		brush.DeleteObject();
		brush.CreateSolidBrush( m_Color[COLOR_TEXTBK] );
		dc.SelectObject(&brush);
		CPoint point;
		point.x=12;
		point.y=12;
		dc.RoundRect(&textRect,point);
		
		//���ַ���д��
		int oldTextColor=dc.SetTextColor(m_Color[COLOR_TEXT]);
		int oldBkMode=dc.SetBkMode(TRANSPARENT);
		dc.DrawText(m_Title, &textRect, DT_VCENTER | DT_CENTER | DT_SINGLELINE);

		dc.SetTextColor(oldTextColor);
		dc.SetBkMode(oldBkMode);
	}

	dc.SelectObject(pOldPen);
	dc.SelectObject(poldFont);
	dc.SelectObject(poldBrush);
*/	
// ������
	dwStyle = (DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		SetTextColor(hDC,
			((pCxp->dwState & CXPS_INDETERMINATE) || (pCxp->dwState & CXPS_DISABLED)) ?
			0x0094A2A5: 0x00000000);
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		//DrawText(Mdcxp.hMemDC, szTemp, -1, &Rect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		Rect.left+=5;
		DrawText(hDC, szTemp, -1, &Rect, DT_LEFT);
		SelectObject(hDC, (HGDIOBJ) hHandle);
	}

}
////////////////////////////////////////////////
//����˵����
VOID WINAPI ButtonDrawStateBoxXP(PCLASSXP pCxp)
{

	
	RECT Rect;
	char szTemp[256];
	HANDLE hHandle;
    DWORD dwStyle;
    int nSaveDC;
	HDC hDC = GetWindowDC(pCxp->hWnd);
	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
	Rect.right -= Rect.left;
	Rect.bottom -= Rect.top;
	Rect.left = Rect.top = 0;
	nSaveDC = SaveDC(hDC);
// ������
	dwStyle = (DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE);
	if (GetWindowText(pCxp->hWnd, szTemp, sizeof(szTemp)))
	{
		SetTextColor(hDC,
			((pCxp->dwState & CXPS_INDETERMINATE) || (pCxp->dwState & CXPS_DISABLED)) ?
			0x0094A2A5: 0x00000000);
		hHandle = (HANDLE) SelectObject(hDC,
			(HGDIOBJ) SendMessage(pCxp->hWnd, WM_GETFONT, 0, 0));
		//DrawText(Mdcxp.hMemDC, szTemp, -1, &Rect, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
		DrawText(hDC, szTemp, -1, &Rect, dwStyle);
		SelectObject(hDC, (HGDIOBJ) hHandle);
	}
	RestoreDC(hDC, nSaveDC );
	ReleaseDC(pCxp->hWnd, hDC);
} // End of OnDrawBackground

////////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT ButtonWindowProc(PCLASSXP pCxp, UINT message,WPARAM wParam, LPARAM lParam)
{
	LONG lReturn, lFound;
    TRACKMOUSEEVENT Tme;
	HWND hParent;

	typedef VOID (WINAPI *DRAWXP)(PCLASSXP);
	static DRAWXP s_DrawXP[] = 
	{
		ButtonDrawPushButtonXP,
		ButtonDrawCheckBoxXP,
		ButtonDrawRadioBoxXP,
		ButtonDrawGroupBoxXP,
		ButtonDrawStateBoxXP,
	};

	HWND hWnd = pCxp->hWnd;
	switch (message)
		{
	    case WM_SETICON:
 		     return ButtonOnSetIcon(pCxp, wParam,lParam);
		case BM_SETSTYLE:	// ��ť���ı�
			CXPM_SETSTATE(pCxp->dwState, CXPS_DEFAULT, wParam & BS_DEFPUSHBUTTON);
			s_DrawXP[pCxp->dwType](pCxp);
			break;
		case BM_SETSTATE:	// ���ð�ť״̬
			lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			CXPM_SETSTATE(pCxp->dwState, CXPS_PRESSED, wParam);
			s_DrawXP[pCxp->dwType](pCxp);
			return lReturn;
		case BM_SETCHECK:	// ����ѡ��״̬
			lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			CXPM_SETSTATE(pCxp->dwState, CXPS_CHECKED, (wParam == BST_CHECKED));
			CXPM_SETSTATE(pCxp->dwState, CXPS_INDETERMINATE, (wParam == BST_INDETERMINATE));
			s_DrawXP[pCxp->dwType](pCxp);
			return lReturn;
		case WM_SETTEXT:	// ���ô����ı�
			lReturn = (LONG) DefWindowProc(hWnd, message, wParam, lParam);
			s_DrawXP[pCxp->dwType](pCxp);
			return lReturn;
		case WM_PAINT:		// �����ػ�
//			if(pCxp->dwType == CXPT_STATEBOX || 
//				pCxp->dwType == CXPT_GROUPBOX)
				lReturn = DefWindowProc(pCxp->hWnd, message, wParam, lParam);
//			else
//	            lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			s_DrawXP[pCxp->dwType](pCxp);
			return lReturn;
		case WM_LBUTTONUP:
		if(pCxp->dwType == CXPT_PUSHBUTTON)
			{
	        ReleaseCapture();
	        hParent = GetParent(hWnd);
		    if(hParent != NULL) SendMessage(hParent,WM_COMMAND,MAKEWPARAM(GetDlgCtrlID(hWnd),BN_CLICKED),(LPARAM)hWnd);
			pCxp->dwState &= ~CXPS_PRESSED;
			s_DrawXP[pCxp->dwType](pCxp);
			return 0;
			}
			break;
		case WM_LBUTTONDOWN:
 		case WM_LBUTTONDBLCLK:
			if(pCxp->dwType == CXPT_PUSHBUTTON)
			{
			  SetFocus(hWnd);
			  pCxp->dwState |= CXPS_PRESSED;
			  s_DrawXP[pCxp->dwType](pCxp);
			  return 0;
			}
			break;
       case WM_ERASEBKGND: //��ֹcheck��radio��ť�����ػ�
			if(pCxp->dwType == CXPT_CHECKBOX)	return TRUE;
			if(pCxp->dwType == CXPT_RADIOBOX)	return TRUE;
			if(pCxp->dwType == CXPT_STATEBOX)	return TRUE;
			if(pCxp->dwType == CXPT_GROUPBOX)	return TRUE;
			break;
 	    case WM_MOUSELEAVE:		// ����Ƴ�
		     if (pCxp->dwState & CXPS_HOTLIGHT)
			 {
			      pCxp->dwState &= ~CXPS_HOTLIGHT;
			     //s_DrawXP[pCxp->dwType](pCxp);
			     lFound = 1;
			 }
		     if (pCxp->dwState & CXPS_PRESSED)
			 {
			      pCxp->dwState &= ~CXPS_PRESSED;
		        	lFound = 1;
			 }
 			s_DrawXP[pCxp->dwType](pCxp);
            return 0;
		}
    
// ����ԭ���Ļص�����
	lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);

	// �����д�����ͬ�Ĵ���
	switch (message)
	{
	case WM_MOUSEMOVE:		// �����ƶ�
		if (((pCxp->dwState & CXPS_HOTLIGHT) == 0) && ((wParam & MK_LBUTTON) == 0))
		{			
			pCxp->dwState |= CXPS_HOTLIGHT;
			s_DrawXP[pCxp->dwType](pCxp);

			// ׷������Ƴ���Ϣһ��
			Tme.cbSize = sizeof(TRACKMOUSEEVENT);
			Tme.dwFlags = TME_LEAVE;
			Tme.hwndTrack = hWnd;
			TrackMouseEvent(&Tme);
		}

		break;
/*	case WM_MOUSELEAVE:		// ����Ƴ�
		lFound = 0;
		if (pCxp->dwState & CXPS_HOTLIGHT)
		{
			pCxp->dwState &= ~CXPS_HOTLIGHT;
			lFound = 1;
		}
		if (pCxp->dwState & CXPS_PRESSED)
		{
			pCxp->dwState &= ~CXPS_PRESSED;
			lFound = 1;
		}
		if(lFound)	s_DrawXP[pCxp->dwType](pCxp);
		break;
*/
	case WM_ENABLE:			// ���ڱ�����Ϊ���û����
		CXPM_SETSTATE(pCxp->dwState, CXPS_DISABLED, !wParam);
		s_DrawXP[pCxp->dwType](pCxp);
		break;
	case WM_SETFOCUS:		// ��ý���
	    SendMessage((HWND)wParam, WM_KILLFOCUS,0,0);
		pCxp->dwState |= CXPS_FOCUS;
		s_DrawXP[pCxp->dwType](pCxp);
		break;
	case WM_KILLFOCUS:		// ��ʧ����
		pCxp->dwState &= ~CXPS_FOCUS;
		s_DrawXP[pCxp->dwType](pCxp);
		break;
	case WM_DESTROY:		// ��������
		DeleteClassXP(hWnd);
	}
	return lReturn;
}

/**************�������ñ��������ÿ��������**********************/
////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif // __cplusplus
////////////////////////////////////////////////////////////////////////////////////////////////////
/*****************************************************************/
