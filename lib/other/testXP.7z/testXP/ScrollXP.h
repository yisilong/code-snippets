// ScrollXP.h: interface for the ScrollXP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCROLLXP_H__237AD521_275B_11D9_AF5C_0050BAB04A6A__INCLUDED_)
#define AFX_SCROLLXP_H__237AD521_275B_11D9_AF5C_0050BAB04A6A__INCLUDED_
#include "ClassXP.H"

LRESULT ScrollWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);


#endif // !defined(AFX_SCROLLXP_H__237AD521_275B_11D9_AF5C_0050BAB04A6A__INCLUDED_)
