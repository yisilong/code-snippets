// ListXP.cpp: implementation of the CListXP class.
//
//////////////////////////////////////////////////////////////////////
/**************�������ñ��������ÿ��������**********************/
//ͷ��
////////////////////////////////////////////////////////////////////////////////////////////////////
// ����Ԥ����
#if _WIN32_WINNT < 0x0400
#define _WIN32_WINNT 0x0400
#endif
// ǿ��ʹ�� C ���Է�ʽ����
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
#include "EditXP.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// ȫ�ֱ���
extern HHOOK g_hPrevHookXP ;		// ������Ϣ HOOK ���
extern PCLASSXP g_pClassXP ;		// ���ڵ� CLASSXP �ṹָ��
extern COLORREF g_crDialogbkColor;  // ���ڱ�����ɫ
//////////////////////////////////////////////////////////////
/****************************************************************/
////////////////////////////////////////////////////////////////////////////////////////////////////
// �������

VOID WINAPI ListDrawListBoxXP(PCLASSXP pCxp)
{
	// ��ȡ�ڴ�����豸����
//	int i;
	RECT Rect;
	MEMDCXP Mdcxp;
	HANDLE hHandle;
//	COLORREF crColor;
	static COLORREF s_crGradientXP[][4] =
	{
		{0x00A5B2B5, 0x00CED7D6, 0x00CED7D6, 0x00DEEFF7},
		{0x00CEF3FF, 0x0063CBFF, 0x0063CBFF, 0x0031B2FF},
		{0x00D6DFDE, 0x00EFF3F7, 0x00EFF3F7, 0x00FFFFFF}
	};
	Mdcxp.hWnd = pCxp->hWnd;
	Mdcxp.bTransfer = TRUE;
	Mdcxp.hBitmap = NULL;
	GetMemDCXP(&Mdcxp);

	// ��ȡ���ڴ�С
	GetWindowRect(pCxp->hWnd, &Rect);
//	Rect.right -= Rect.left;
//	Rect.bottom -= Rect.top;
//	Rect.top = Rect.left = 0;
 //   AdjustWindowRect(&Rect,(DWORD)GetWindowLong(pCxp->hWnd, GWL_STYLE),FALSE);
/*

	// �������
	hHandle = (HANDLE) CreateSolidBrush(
		(pCxp->dwState & CXPS_DISABLED) ? (GetSysColor(COLOR_BTNFACE) - 0x00202020) : 0x00BD9E7B);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
	DeleteObject((HGDIOBJ) hHandle);

	// �����ڿ�
	InflateRect(&Rect, -1, -1);
//	hHandle = (HANDLE) GetSysColorBrush((pCxp->dwState & CXPS_DISABLED) ? COLOR_BTNFACE : COLOR_WINDOW);
	if (pCxp->dwState & CXPS_DISABLED) 
  	  hHandle = (HANDLE) GetSysColorBrush(g_crDialogbkColor);
	else
	  hHandle = (HANDLE) GetSysColorBrush(COLOR_WINDOW);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);

	InflateRect(&Rect, -1, -1);
	Rect.left = Rect.right - GetSystemMetrics(SM_CYVTHUMB);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
	Rect.left++;
     
	if (pCxp->dwState & CXPS_DISABLED)
		i = 0;
	else if (pCxp->dwState & CXPS_PRESSED)
		i = 1;
	else if (pCxp->dwState & CXPS_HOTLIGHT)
		i = 2;
	else
		i = 3;
	DeleteObject(SelectObject(Mdcxp.hMemDC, (HGDIOBJ) hHandle));
// ��������
	RectOld = Rect;
	Rect.left = Rect.right - 17;
	Rect.bottom = Rect.top+17;
	Rect.right--;
	Rect.top++;
	hHandle = (HANDLE) CreateSolidBrush(
		(pCxp->dwState & CXPS_DISABLED) ? (GetSysColor(COLOR_BTNFACE) - 0x00202020) : 0x00BD9E7B);
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
*/
/*	Rect.left = Rect.right - 16;
	Rect.bottom = Rect.top+16;
	Rect.right--;
	Rect.top++;
	FrameRect(Mdcxp.hMemDC, &Rect, (HBRUSH) hHandle);
*/	
	DeleteObject((HGDIOBJ) hHandle);

/*	RectOld = Rect;
	Rect.left = Rect.right - 18;
	GradientRectXP(Mdcxp.hMemDC, &Rect, s_crGradientXP[i]);
// ����������־
	Rect.left += (Rect.right - Rect.left) / 2;
	Rect.top +=  10 ;
	hHandle = (HANDLE) SelectObject(Mdcxp.hMemDC,
	CreatePen(PS_SOLID, 1, (pCxp->dwState & CXPS_DISABLED) ? 0x00C6CBCE : 0x0084614A));
	MoveToEx(Mdcxp.hMemDC, Rect.left - 4, Rect.top + 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left , Rect.top-2 );
	LineTo(Mdcxp.hMemDC, Rect.left + 5, Rect.top + 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top + 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top - 1);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top + 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top + 3, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top + 4);

// ����������־
	Rect.left = RectOld.left + (RectOld.right - RectOld.left) / 2;
	Rect.top = RectOld.bottom  - 10 ;
//	hHandle = (HANDLE) SelectObject(Mdcxp.hMemDC,
//		CreatePen(PS_SOLID, 1, (pCxp->dwState & CXPS_DISABLED) ? 0x00C6CBCE : 0x0084614A));
	MoveToEx(Mdcxp.hMemDC, Rect.left - 4, Rect.top - 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top + 2);
	LineTo(Mdcxp.hMemDC, Rect.left + 5, Rect.top - 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top - 2, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top + 1);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top - 3);
	MoveToEx(Mdcxp.hMemDC, Rect.left - 3, Rect.top - 3, NULL);
	LineTo(Mdcxp.hMemDC, Rect.left, Rect.top);
	LineTo(Mdcxp.hMemDC, Rect.left + 4, Rect.top - 4);

	DeleteObject(SelectObject(Mdcxp.hMemDC, (HGDIOBJ) hHandle));
*/
	// ��ԭ���ͷ��ڴ��豸����
	Mdcxp.bTransfer = TRUE;
	ReleaseMemDCXP(&Mdcxp);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT ListWindowProc(PCLASSXP pCxp, UINT message,WPARAM wParam, LPARAM lParam)
{
	LONG lReturn;
	HWND hWnd = pCxp->hWnd;
	switch (message)
		{
		case LB_SETHORIZONTALEXTENT:
			return 0;
		case WM_VSCROLL:
			lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			ListDrawListBoxXP(pCxp);
			return lReturn;
			break;
		case WM_PAINT:
		case WM_NCPAINT:
			pCxp->dwState |= CXPS_NOPAINT;
			lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
			ListDrawListBoxXP(pCxp);
			return lReturn;
		}
// ����ԭ���Ļص�����
	lReturn = (LONG) CallWindowProc(pCxp->wpPrev, hWnd, message, wParam, lParam);
	switch (message)
	{
	case WM_DESTROY:		// ��������
		DeleteClassXP(hWnd);
	}
	return lReturn;
}


/**************�������ñ��������ÿ��������**********************/
//β��
#ifdef __cplusplus
}
#endif // __cplusplus
/*****************************************************************/
