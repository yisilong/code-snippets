// ButtonXP.h: interface for the CButtonXP class.
//
//////////////////////////////////////////////////////////////////////
#include "ClassXP.H"

#if !defined(AFX_BUTTONXP_H__1EF7F226_1308_49E6_B2E0_CE2B85D47422__INCLUDED_)
#define AFX_BUTTONXP_H__1EF7F226_1308_49E6_B2E0_CE2B85D47422__INCLUDED_

LRESULT ButtonWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);
VOID WINAPI DrawPushButtonXP(PCLASSXP pCxp);
VOID WINAPI DrawPushGroupBoxXP(PCLASSXP pCxp);
VOID WINAPI DrawPushStateBoxXP(PCLASSXP pCxp);
VOID WINAPI ButtonDrawPushText(PCLASSXP pCxp, HDC hDC, RECT rc);




#endif // !defined(AFX_BUTTONXP_H__1EF7F226_1308_49E6_B2E0_CE2B85D47422__INCLUDED_)
