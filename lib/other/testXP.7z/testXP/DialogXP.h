// DialogXP.h: interface for the CDialogXP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIALOGXP_H__F89F6F21_1CEF_11D9_AF5C_0050BAB04A6A__INCLUDED_)
#define AFX_DIALOGXP_H__F89F6F21_1CEF_11D9_AF5C_0050BAB04A6A__INCLUDED_
/*
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDialogXP  
{
public:
	CDialogXP();
	virtual ~CDialogXP();

};
*/
#include "ClassXP.H"
// ǿ��ʹ�� C ���Է�ʽ����
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus
////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////
// DIALOGXP �ṹ�����еĴ��붼��Χ������ṹ����д��

typedef struct tagDIALOGXP
{
	BOOL m_ExitButtonState;
	BOOL m_MinimizeButtonState;
	BOOL m_MaximizeButtonState;
	BOOL m_NcMouseState;
	BOOL m_SelTitleButton;
}
DIALOGXP, * PDIALOGXP;


LRESULT DlgWindowProc(PCLASSXP pCxp, UINT message, WPARAM wParam, LPARAM lParam);

LRESULT DlgOnNcPaint(PCLASSXP pCxp, WPARAM wParam);
BOOL DlgDrawTitleBar(PCLASSXP pCxp, WPARAM wParam);
BOOL DlgDrawFrameBorder(PCLASSXP pCxp, WPARAM wParam, HRGN hRgn);
LRESULT DlgOnEraseBackGround(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam);
LRESULT DlgOnNcMouseMove(PCLASSXP pCxp,WPARAM wParam, LPARAM lParam);
/*
LRESULT DlgOnActive(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam);
LRESULT DlgOnNcActive(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam);
LRESULT DlgOnActiveApp(PCLASSXP pCxp, WPARAM wParam,LPARAM lParam);
LRESULT DlgOnNodify(PCLASSXP pCxp,WPARAM wParam, LPARAM lParam);
LRESULT DlgOnSetText(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam);
LRESULT DlgOnSetIcon(PCLASSXP pCxp, WPARAM wParam, LPARAM lParam);
*/

//NcMouseState
#define MouseStateDown 1
#define MouseStateNormal 0
//SelTitleButton
#define NoneButton 0
#define MinimizeButton 1
#define MaximizeButton 2
#define ExitButton 3
//xxxButtonState
#define StateNormal 0
#define StateDown 1
#define StateFocus 2


#ifdef __cplusplus
}
#endif // __cplusplus
////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_DIALOGXP_H__F89F6F21_1CEF_11D9_AF5C_0050BAB04A6A__INCLUDED_)
