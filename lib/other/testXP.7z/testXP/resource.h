//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_SCROLLBAR1                  1011
#define IDC_LIST1                       1012
#define IDC_COMBO1                      1013
#define IDC_RADIO1                      1014
#define IDC_CHECK1                      1015
#define IDC_BUTTON1                     1016
#define IDC_BUTTON2                     1017
#define IDC_EDIT1                       1018
#define IDC_RADIO2                      1019
#define IDC_EDIT2                       1020
#define IDC_COMBO2                      1021
#define IDC_CANCEL                      1022
#define IDC_RADIO3                      1023
#define IDC_CHECK2                      1028
#define IDC_CHECK3                      1034
#define IDC_SCROLLBAR2                  1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
