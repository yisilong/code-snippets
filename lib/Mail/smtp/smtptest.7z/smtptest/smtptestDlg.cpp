/*
	������Ϊ�����ʼ��������ʾ����

	����:��ë
	QQ:510784518
	���ͣ�http://hi.baidu.com/suruiqiang
*/

// smtptestDlg.cpp : implementation file
// ������Դ�밮���ߣ� http://www.codefans.net

#include "stdafx.h"
#include "smtptest.h"
#include "smtptestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSmtptestDlg dialog

CSmtptestDlg::CSmtptestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSmtptestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSmtptestDlg)
	m_server = _T("");
	m_msgbody = _T("");
	m_mailfrom = _T("");
	m_mailto = _T("");
	m_password = _T("");
	m_subject = _T("");
	m_user = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSmtptestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSmtptestDlg)
	DDX_CBString(pDX, IDC_COMBO_SMTP, m_server);
	DDX_Text(pDX, IDC_EDIT_BODY, m_msgbody);
	DDX_Text(pDX, IDC_EDIT_MAILFROM, m_mailfrom);
	DDX_Text(pDX, IDC_EDIT_MAILTO, m_mailto);
	DDX_Text(pDX, IDC_EDIT_PASS, m_password);
	DDX_Text(pDX, IDC_EDIT_SUBJECT, m_subject);
	DDX_Text(pDX, IDC_EDIT_USER, m_user);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSmtptestDlg, CDialog)
	//{{AFX_MSG_MAP(CSmtptestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_SEND, OnBtnSend)
	ON_EN_CHANGE(IDC_EDIT_USER, OnChangeEditUser)
	ON_CBN_EDITCHANGE(IDC_COMBO_SMTP, OnEditchangeComboSmtp)
	ON_CBN_SELCHANGE(IDC_COMBO_SMTP, OnSelchangeComboSmtp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSmtptestDlg message handlers

BOOL CSmtptestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	((CComboBox*)GetDlgItem(IDC_COMBO_SMTP))->SetCurSel(0);
	UpdateData(TRUE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSmtptestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSmtptestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSmtptestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSmtptestDlg::OnBtnSend() 
{
	UpdateData();
	
	if(SendMail(m_server,m_user,m_password,m_mailfrom,m_mailto,m_subject,m_msgbody))
	{
		MessageBox("�ʼ����ͳɹ�!","�ɹ�",64);
	}
	else
	{
		char strerrmsg[100];

		GetSmtpError(strerrmsg);
		
		MessageBox(strerrmsg,"ʧ��",MB_ICONEXCLAMATION | MB_ICONWARNING);
	}
}

void CSmtptestDlg::OnChangeEditUser() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	UpdateData(TRUE);
	m_mailfrom=m_user+"@";
	if("smtp."==m_server.Left(5))
	{
		m_mailfrom+=m_server.Mid(5);
	}
	else
	{
		m_mailfrom+=m_server;
	}
	UpdateData(FALSE);
	// TODO: Add your control notification handler code here
	
}

void CSmtptestDlg::OnEditchangeComboSmtp() 
{
	UpdateData(TRUE);
	m_mailfrom=m_user+"@";
	if("smtp."==m_server.Left(5))
	{
		m_mailfrom+=m_server.Mid(5);
	}
	else
	{
		m_mailfrom+=m_server;
	}
	//UpdateData(FALSE);
	SetDlgItemText(IDC_EDIT_MAILFROM,m_mailfrom);
}

void CSmtptestDlg::OnSelchangeComboSmtp() 
{
/*	UpdateData(TRUE);
	m_mailfrom=m_user+"@";
	if("smtp."==m_server.Left(5))
	{
		m_mailfrom+=m_server.Mid(5);
	}
	else
	{
		m_mailfrom+=m_server;
	}
	UpdateData(FALSE);
*/
	((CComboBox*)GetDlgItem(IDC_COMBO_SMTP))->GetLBText(((CComboBox*)GetDlgItem(IDC_COMBO_SMTP))->GetCurSel(),m_server);
	m_mailfrom=m_user+"@";
	if("smtp."==m_server.Left(5))
	{
		m_mailfrom+=m_server.Mid(5);
	}
	else
	{
		m_mailfrom+=m_server;
	}
	SetDlgItemText(IDC_EDIT_MAILFROM,m_mailfrom);
}

void CSmtptestDlg::OnOK() 
{	
	//CDialog::OnOK();
}
