//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pop3Monitor.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_POP3MONITOR_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_EDT_MSG                     1000
#define IDC_EDIT2                       1001
#define IDC_EDT_SERVER                  1001
#define IDC_EDIT3                       1002
#define IDC_EDT_USER                    1002
#define IDC_EDIT4                       1003
#define IDC_EDT_PASSWORD                1003
#define IDC_BTN_CONNECT                 1004
#define IDC_BTN_LIST                    1005
#define IDC_BTN_CREATE                  1006
#define IDC_BTN_CLOSE                   1007
#define IDC_BTN_GETHEADER               1008
#define IDC_EDT_NUM                     1009
#define IDC_BTN_GET                     1010
#define IDC_BTN_STAT                    1011
#define IDC_BTN_SIZE                    1012
#define IDC_BTN_SUBJECT                 1014
#define IDC_BTN_SENDER                  1015
#define IDC_BTN_RECEIVER                1016
#define IDC_BTN_DATE                    1017
#define IDC_BTN_DELETE                  1018
#define IDC_BTN_RESET                   1019
#define IDC_CHK_APOP                    1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
