// stdafx.cpp : source file that includes just the standard includes
//	CatchScreen.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
// Download by http://www.codefans.net
#include "stdafx.h"



